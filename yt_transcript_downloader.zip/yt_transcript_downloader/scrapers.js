// Page-injected scrapers for the YouTube transcript queue.
//
// These functions are consumed by `chrome.scripting.executeScript({func: ...})`,
// which serializes the function source and re-evaluates it in the target tab's
// MAIN world. They MUST be self-contained: no closures over module state, no
// external references besides standard browser globals (document, window,
// fetch, URL, URLSearchParams, setTimeout, etc.).
//
// Loaded into the service worker via `importScripts('scrapers.js')`, which
// exposes each top-level `function` declaration as a global.

// Runs in the page's MAIN world. Scrolls the videos grid until no new items
// load, then scrapes title + /watch href from each ytd-rich-item-renderer.
async function grabChannelVideos() {
  try {
    // Authoritative source first — channelMetadataRenderer.title belongs to
    // the page's channel, never to sidebar subscriptions or unrelated DOM.
    // DOM fallbacks are scoped to the channel-header renderer to avoid
    // picking up #text ids that live elsewhere on the page.
    const channelDisplayName =
      window.ytInitialData?.metadata?.channelMetadataRenderer?.title ||
      window.ytInitialData?.header?.c4TabbedHeaderRenderer?.title ||
      window.ytInitialData?.header?.pageHeaderRenderer?.pageTitle ||
      document.querySelector("ytd-c4-tabbed-header-renderer ytd-channel-name #text")?.textContent?.trim() ||
      document.querySelector("#channel-header ytd-channel-name #text")?.textContent?.trim() ||
      document.querySelector("ytd-channel-name #text")?.textContent?.trim() ||
      document.title.replace(/ - YouTube$/, "") ||
      "channel";
    // Handle is the URL slug without the leading @ (e.g. "joincolossus").
    // Falls back to channel/UC.../c/... slugs if no @handle is present.
    const pathMatch = location.pathname.match(
      /^\/(?:@([^/]+)|channel\/([^/]+)|c\/([^/]+)|user\/([^/]+))/
    );
    const channelHandle =
      (pathMatch && (pathMatch[1] || pathMatch[2] || pathMatch[3] || pathMatch[4])) || "";

    const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

    // Shared state so the SW can poll progress + signal a user-initiated stop.
    window.__ytcxScrape = { count: 0, stop: false };
    let prev = 0;
    let stable = 0;
    for (let i = 0; i < 120; i++) {
      window.scrollTo(0, document.documentElement.scrollHeight);
      await sleep(900);
      const count = document.querySelectorAll("ytd-rich-item-renderer").length;
      window.__ytcxScrape.count = count;
      if (window.__ytcxScrape.stop) break;
      if (count === prev) {
        stable++;
        if (stable >= 5) break;
      } else {
        stable = 0;
        prev = count;
      }
    }

    // Parse a YouTube duration badge text ("0:58", "12:34", "1:23:45") into
    // total seconds. Returns null for anything we can't confidently parse —
    // callers treat null as "unknown" and don't filter on it (conservative).
    function parseDurationText(raw) {
      const s = String(raw || "").trim();
      if (!s) return null;
      // Strip surrounding whitespace + zero-width / accessibility suffixes.
      // Match "H:MM:SS", "M:SS", or "S" (rare). Reject anything else.
      const m = s.match(/^(?:(\d{1,2}):)?(\d{1,2}):(\d{2})$/);
      if (!m) return null;
      const h = m[1] ? Number(m[1]) : 0;
      const mm = Number(m[2]);
      const ss = Number(m[3]);
      if (!Number.isFinite(h) || !Number.isFinite(mm) || !Number.isFinite(ss)) return null;
      return h * 3600 + mm * 60 + ss;
    }

    // Shorts filter: YouTube tags short-form uploads with a duration badge
    // under ~60s on the Videos tab. We match the backend's 125s threshold so
    // the client never enqueues a video the server would reject as a short.
    const SHORT_THRESHOLD_SECONDS = 125;

    const items = document.querySelectorAll("ytd-rich-item-renderer");
    const videos = [];
    let shortsSkipped = 0;
    let unknownDuration = 0;
    const seen = new Set();
    for (const el of items) {
      const a =
        el.querySelector("a#video-title-link") ||
        el.querySelector("a#thumbnail");
      let href = a?.getAttribute("href") || "";
      if (!href || !/\/watch\?v=/.test(href)) continue;
      const id = new URLSearchParams(href.split("?")[1] || "").get("v");
      if (!id || seen.has(id)) continue;
      seen.add(id);
      const title =
        el.querySelector("#video-title")?.textContent?.trim() ||
        el.querySelector("yt-formatted-string#video-title")?.textContent?.trim() ||
        "";
      const meta = [...el.querySelectorAll("#metadata-line span, .inline-metadata-item")]
        .map((s) => s.textContent.trim())
        .filter(Boolean)
        .join(" • ");

      // Duration badge lives in a thumbnail-overlay. Selector list covers the
      // legacy Polymer renderer and the newer badge-shape Lit component; first
      // match wins. Also fall back to the accessibility aria-label ("X minutes
      // Y seconds") if both rendered-text paths are empty.
      const durText =
        el.querySelector("ytd-thumbnail-overlay-time-status-renderer #text")?.textContent?.trim() ||
        el.querySelector("ytd-thumbnail-overlay-time-status-renderer .badge-shape-wiz__text")?.textContent?.trim() ||
        el.querySelector(".badge-shape-wiz__text")?.textContent?.trim() ||
        el.querySelector("ytd-thumbnail-overlay-time-status-renderer span")?.textContent?.trim() ||
        "";
      const durationSeconds = parseDurationText(durText);
      if (durationSeconds != null && durationSeconds < SHORT_THRESHOLD_SECONDS) {
        shortsSkipped++;
        continue;
      }
      if (durationSeconds == null) unknownDuration++;

      videos.push({
        id,
        url: `https://www.youtube.com/watch?v=${id}`,
        title,
        meta,
        durationSeconds,
      });
    }

    // Emit both keys: callers consume `channelDisplayName` going forward, but
    // legacy `channel` is kept for back-compat with older background.js paths.
    return {
      channel: channelDisplayName,
      channelDisplayName,
      channelHandle,
      pageUrl: location.href,
      videos,
      shortsSkipped,
      unknownDuration,
    };
  } catch (e) {
    return { error: String(e?.message || e) };
  }
}

// Runs in the page's MAIN world — has access to ytcfg, ytInitialData,
// ytInitialPlayerResponse, and the page's cookie/session for authenticated
// InnerTube calls.
async function grabTranscript(preferredLang, includeTimestamps) {
  try {
    // Channel handle from ytInitialPlayerResponse — used by the SW to prefix
    // the saved filename (e.g. "joincolossus_My Video Title.txt").
    const pr0 = window.ytInitialPlayerResponse;
    const ownerUrl =
      pr0?.microformat?.playerMicroformatRenderer?.ownerProfileUrl ||
      pr0?.videoDetails?.channelUrl ||
      "";
    const handleMatch = ownerUrl.match(/\/@([^/?#]+)/);
    const channelHandle = handleMatch ? handleMatch[1] : "";
    const channelDisplayName =
      pr0?.videoDetails?.author ||
      pr0?.microformat?.playerMicroformatRenderer?.ownerChannelName ||
      "";

    // Upload date + view count + duration: snapshot at scrape time. Views
    // grow over time; a re-scrape's upsert updates the value to latest.
    const mf = pr0?.microformat?.playerMicroformatRenderer;
    const vd = pr0?.videoDetails;
    // YouTube returns publishDate either as "YYYY-MM-DD" or a full
    // "YYYY-MM-DDTHH:mm:ssZZ". Forward the full string; slicing here loses
    // the timezone offset and flips late-evening-Pacific uploads off-by-one
    // against UTC. The API now accepts either shape and stores TIMESTAMP.
    const rawPub = mf?.publishDate || mf?.uploadDate || "";
    const publishDate = /^\d{4}-\d{2}-\d{2}/.test(rawPub) ? rawPub : null;
    const vc = Number(vd?.viewCount);
    const viewCount = Number.isFinite(vc) ? vc : null;
    const ls = Number(vd?.lengthSeconds);
    const lengthSeconds = Number.isFinite(ls) ? ls : null;
    const description =
      vd?.shortDescription ||
      mf?.description?.simpleText ||
      "";
    const category = mf?.category || "";
    const keywords = Array.isArray(vd?.keywords) ? vd.keywords.slice() : [];
    const channelId = vd?.channelId || "";
    const hasCaptions = !!(pr0?.captions?.playerCaptionsTracklistRenderer?.captionTracks?.length);
    const publishDateTimestamp = rawPub || null;  // same full ISO as publishDate; named for BQ TIMESTAMP column
    const meta = { publishDate, publishDateTimestamp, viewCount, lengthSeconds, description, category, keywords, channelId, hasCaptions };

    // 1) Drive YouTube's own UI: open the transcript panel and scrape rendered
    //    segments. Reliable across 2025–2026 anti-abuse changes that broke both
    //    /youtubei/v1/get_transcript (FAILED_PRECONDITION) and /api/timedtext
    //    (200 empty body) for non-player callers.
    const dom = await tryDom(includeTimestamps);
    if (dom?.text?.trim()) return { ...dom, channelHandle, channelDisplayName, ...meta };

    // 2) InnerTube get_transcript API — kept as a fallback for environments
    //    where the DOM path is blocked (panel missing, no description button).
    const innertube = await tryInnerTube(includeTimestamps);
    if (innertube?.text?.trim()) return { ...innertube, channelHandle, channelDisplayName, ...meta };

    // 3) Legacy /api/timedtext baseUrl.
    const legacy = await tryBaseUrl(preferredLang, includeTimestamps);
    if (legacy?.text?.trim()) return { ...legacy, channelHandle, channelDisplayName, ...meta };

    return {
      error:
        "YouTube returned no transcript data. Ensure captions exist for this video and you're signed in.",
    };
  } catch (e) {
    return { error: String(e?.message || e) };
  }

  // --- DOM path: click "Show transcript", wait for panel, scrape segments ---
  async function tryDom(includeTimestamps) {
    const panelSel =
      'ytd-engagement-panel-section-list-renderer[target-id="engagement-panel-searchable-transcript"]';

    if (!document.querySelector(panelSel)) return null;

    async function waitFor(pred, ms) {
      const t0 = Date.now();
      while (Date.now() - t0 < ms) {
        const v = pred();
        if (v) return v;
        await new Promise((r) => setTimeout(r, 150));
      }
      return null;
    }

    let panel = document.querySelector(panelSel);
    const isExpanded = (p) =>
      /EXPANDED/.test(p?.getAttribute("visibility") || "");

    const rowSel = "ytd-transcript-segment-renderer, transcript-segment-view-model";

    // Primary path: silently flip the panel attribute. YouTube loads the
    // transcript continuation on the next render — no click, no scrolling.
    if (!isExpanded(panel)) {
      panel.setAttribute("visibility", "ENGAGEMENT_PANEL_VISIBILITY_EXPANDED");
    }

    let rows = await waitFor(() => {
      const r = panel?.querySelectorAll(rowSel);
      return r && r.length ? r : null;
    }, 5000);

    // Fallback: on rare videos the attribute flip doesn't trigger the fetch.
    // Fall back to the scroll/click path that worked before this shortcut.
    if (!rows) {
      window.scrollTo(0, Math.max(window.scrollY, 800));
      const expand = document.querySelector("tp-yt-paper-button#expand, #expand");
      if (expand) { expand.click(); await new Promise((r) => setTimeout(r, 400)); }
      const btn =
        document.querySelector("ytd-video-description-transcript-section-renderer button") ||
        document.querySelector('button[aria-label="Show transcript"]') ||
        [...document.querySelectorAll("button")].find((b) =>
          /ranscript/.test(b.getAttribute("aria-label") || "")
        );
      if (btn) {
        btn.scrollIntoView({ block: "center" });
        await new Promise((r) => setTimeout(r, 300));
        btn.click();
      }
      rows = await waitFor(() => {
        panel = document.querySelector(panelSel);
        const r = panel?.querySelectorAll(rowSel);
        return r && r.length ? r : null;
      }, 6000);
    }
    if (!rows) return null;

    const lines = [];
    for (const r of rows) {
      const ts =
        r
          .querySelector(
            ".segment-timestamp, .ytwTranscriptSegmentViewModelTimestamp"
          )
          ?.textContent?.trim() || "";
      const text =
        r
          .querySelector(
            "yt-formatted-string.segment-text, .segment-text, .yt-core-attributed-string"
          )
          ?.textContent?.replace(/\s+/g, " ")
          .trim() || "";
      if (!text) continue;
      lines.push(includeTimestamps && ts ? `[${ts}] ${text}` : text);
    }
    if (!lines.length) return null;

    const pr = window.ytInitialPlayerResponse;
    return {
      text: lines.join("\n"),
      lang:
        pr?.captions?.playerCaptionsTracklistRenderer?.captionTracks?.[0]
          ?.languageCode || "en",
      title: pr?.videoDetails?.title || "transcript",
      source: "dom",
    };
  }

  // --- InnerTube path ---
  async function tryInnerTube(includeTimestamps) {
    const cfg = window.ytcfg?.data_ || {};
    const ctx = cfg.INNERTUBE_CONTEXT;
    if (!ctx) return null;

    const panels = window.ytInitialData?.engagementPanels || [];
    const tp = panels.find(
      (p) =>
        p.engagementPanelSectionListRenderer?.targetId ===
        "engagement-panel-searchable-transcript"
    );
    if (!tp) return null;

    let params = null;
    const walk = (o) => {
      if (!o || typeof o !== "object") return;
      if (o.getTranscriptEndpoint?.params) {
        params = o.getTranscriptEndpoint.params;
        return;
      }
      for (const k of Object.keys(o)) walk(o[k]);
    };
    walk(tp);
    if (!params) return null;

    const resp = await fetch("/youtubei/v1/get_transcript?prettyPrint=false", {
      method: "POST",
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
        "X-YouTube-Client-Name": String(cfg.INNERTUBE_CONTEXT_CLIENT_NAME || 1),
        "X-YouTube-Client-Version": cfg.INNERTUBE_CLIENT_VERSION || "",
        "X-Goog-Visitor-Id": ctx?.client?.visitorData || "",
      },
      body: JSON.stringify({ context: ctx, params: decodeURIComponent(params) }),
    });
    if (!resp.ok) return null;
    const j = await resp.json();
    const segs =
      j?.actions?.[0]?.updateEngagementPanelAction?.content?.transcriptRenderer
        ?.content?.transcriptSearchPanelRenderer?.body
        ?.transcriptSegmentListRenderer?.initialSegments || [];
    if (!segs.length) return null;

    const lines = [];
    for (const g of segs) {
      const r = g.transcriptSegmentRenderer;
      if (!r) continue;
      const text = (r.snippet?.runs || [])
        .map((x) => x.text || "")
        .join("")
        .replace(/\s+/g, " ")
        .trim();
      if (!text) continue;
      if (includeTimestamps) {
        const start = Number(r.startMs || 0) / 1000;
        lines.push(`[${formatTime(start)}] ${text}`);
      } else {
        lines.push(text);
      }
    }
    const pr = window.ytInitialPlayerResponse;
    return {
      text: lines.join("\n"),
      lang: pr?.captions?.playerCaptionsTracklistRenderer?.captionTracks?.[0]
        ?.languageCode || "en",
      title: pr?.videoDetails?.title || "transcript",
      source: "innertube",
    };
  }

  // --- Legacy baseUrl path (retained as fallback) ---
  async function tryBaseUrl(preferredLang, includeTimestamps) {
    const pr = window.ytInitialPlayerResponse;
    const tracks =
      pr?.captions?.playerCaptionsTracklistRenderer?.captionTracks || [];
    if (!tracks.length) return null;
    const chosen =
      tracks.find((t) => t.languageCode === preferredLang && t.kind !== "asr") ||
      tracks.find((t) => t.languageCode === preferredLang) ||
      tracks.find((t) => t.kind !== "asr") ||
      tracks[0];

    for (const fmt of ["json3", "srv1"]) {
      const u = new URL(chosen.baseUrl);
      u.searchParams.set("fmt", fmt);
      const body = await (await fetch(u.toString())).text();
      if (!body) continue;
      if (fmt === "json3") {
        try {
          const data = JSON.parse(body);
          const events = data.events || [];
          const out = [];
          for (const ev of events) {
            if (!ev.segs) continue;
            const text = ev.segs
              .map((s) => s.utf8 || "")
              .join("")
              .replace(/\s+/g, " ")
              .trim();
            if (!text) continue;
            if (includeTimestamps) {
              const start = (ev.tStartMs || 0) / 1000;
              out.push(`[${formatTime(start)}] ${text}`);
            } else {
              out.push(text);
            }
          }
          if (out.length)
            return {
              text: out.join("\n"),
              lang: chosen.languageCode,
              title: pr?.videoDetails?.title || "transcript",
              source: "timedtext:json3",
            };
        } catch {}
      } else {
        // srv1 XML — parse via regex to avoid TrustedTypes DOMParser restriction
        const matches = [
          ...body.matchAll(
            /<text\s+start="([\d.]+)"[^>]*>([\s\S]*?)<\/text>/g
          ),
        ];
        const out = [];
        for (const m of matches) {
          const text = decodeEntities(m[2])
            .replace(/<[^>]+>/g, "")
            .replace(/\s+/g, " ")
            .trim();
          if (!text) continue;
          if (includeTimestamps)
            out.push(`[${formatTime(Number(m[1]))}] ${text}`);
          else out.push(text);
        }
        if (out.length)
          return {
            text: out.join("\n"),
            lang: chosen.languageCode,
            title: pr?.videoDetails?.title || "transcript",
            source: "timedtext:srv1",
          };
      }
    }
    return null;
  }

  function decodeEntities(s) {
    return s
      .replace(/&amp;/g, "&")
      .replace(/&lt;/g, "<")
      .replace(/&gt;/g, ">")
      .replace(/&quot;/g, '"')
      .replace(/&#39;/g, "'")
      .replace(/&#(\d+);/g, (_, n) => String.fromCharCode(Number(n)));
  }

  function formatTime(secs) {
    const h = Math.floor(secs / 3600);
    const m = Math.floor((secs % 3600) / 60);
    const s = Math.floor(secs % 60);
    const pad = (n) => String(n).padStart(2, "0");
    return h > 0 ? `${h}:${pad(m)}:${pad(s)}` : `${m}:${pad(s)}`;
  }
}

// Page-injected. Extract channel identity from a YouTube channel page so we
// can later hit the public RSS feed (which requires the UC... id, not the
// @handle). Runs in MAIN world to read ytInitialData.
function grabChannelMeta() {
  try {
    const UC_RE = /^UC[A-Za-z0-9_-]{22}$/;
    const pickUc = (v) => (v && UC_RE.test(v) ? v : "");
    const md = window.ytInitialData?.metadata?.channelMetadataRenderer || {};
    const header = window.ytInitialData?.header || {};
    // Every candidate is filtered through pickUc so the function can NEVER
    // return a non-UC id (e.g. a featured-video itemprop on the page).
    let channelId =
      pickUc(md.externalId) ||
      pickUc(header.c4TabbedHeaderRenderer?.channelId) ||
      pickUc(header.pageHeaderRenderer?.channelId) ||
      pickUc(document.querySelector('meta[itemprop="channelId"]')?.content) ||
      pickUc(document.querySelector('meta[itemprop="identifier"]')?.content) ||
      document.querySelector('link[rel="canonical"]')?.href?.match(/\/channel\/(UC[\w-]{22})/)?.[1] ||
      document.querySelector('meta[property="og:url"]')?.content?.match(/\/channel\/(UC[\w-]{22})/)?.[1] ||
      "";
    // Last-resort sweep: channelId shows up in many places within ytInitialData
    // depending on the page layout (handle pages vs /channel/UC..., home vs
    // /videos, legacy vs new header). Stringify + regex as a catch-all.
    if (!channelId && window.ytInitialData) {
      try {
        const m = JSON.stringify(window.ytInitialData).match(/"(?:channelId|externalId|browseId)":"(UC[\w-]{22})"/);
        if (m) channelId = m[1];
      } catch {}
    }
    const handle =
      md.vanityChannelUrl?.match(/@([^/]+)/)?.[1] ||
      location.pathname.match(/^\/@([^/?#]+)/)?.[1] ||
      "";
    const title = md.title || document.title.replace(/ - YouTube$/, "") || "";
    const url = md.channelUrl || (handle ? `https://www.youtube.com/@${handle}` : location.href);
    if (!channelId) return { error: "no channelId on this page" };
    // SPA nav leaves window.ytInitialData pointing at the prior channel, so
    // cross-check the extracted identity against the current URL before trusting it.
    const pathHandle = location.pathname.match(/^\/@([^/?#]+)/)?.[1];
    if (pathHandle && handle && pathHandle.toLowerCase() !== handle.toLowerCase()) {
      return { error: "stale page data (SPA nav) — reload the channel page and retry" };
    }
    const pathChannelId = location.pathname.match(/^\/channel\/(UC[\w-]{22})/)?.[1];
    if (pathChannelId && channelId !== pathChannelId) {
      return { error: "stale page data (SPA nav) — reload the channel page and retry" };
    }
    return { channelId, handle, title, url };
  } catch (e) {
    return { error: String(e?.message || e) };
  }
}

// Runs in the page's MAIN world on a /watch page. Reads the embedded player
// response for the authoritative duration — much more reliable than scraping
// the DOM. Used by "Add current video" to block shorts before enqueue.
//
// Returns {lengthSeconds, isShortUrl, title} — lengthSeconds is null if the
// player data isn't available yet (e.g. page still loading). The background
// worker treats null as "don't block" (conservative — let the normal add
// succeed and backend will filter on its side).
function grabCurrentVideoInfo() {
  try {
    const path = location.pathname || "";
    const isShortUrl = /^\/shorts\//.test(path);
    const vd = window.ytInitialPlayerResponse?.videoDetails;
    const ls = Number(vd?.lengthSeconds);
    const lengthSeconds = Number.isFinite(ls) ? ls : null;
    const title = vd?.title || document.title.replace(/ - YouTube$/, "") || "";
    return { lengthSeconds, isShortUrl, title };
  } catch (e) {
    return { error: String(e?.message || e) };
  }
}

// Safe-filename helper shared between the popup and the SW queue loop.
function sanitize(name) {
  return name.replace(/[\\/:*?"<>|]/g, "_").replace(/\s+/g, " ").slice(0, 120);
}
