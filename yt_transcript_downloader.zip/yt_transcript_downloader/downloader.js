// Download helpers used by the SW queue loop.
//
// Loaded via `importScripts('downloader.js')` in the MV3 service worker, which
// exposes each top-level `function` declaration as a global. We pull in JSZip
// here (same technique) so `JSZip` is available for `downloadZip`.

importScripts("vendor/jszip.min.js");

// Strip any leading path separator from an already-sanitized filename. The
// caller (SW queue loop) is expected to run `sanitize()` on the user-visible
// name; this is just a belt-and-braces check so we never pass an absolute
// path to `chrome.downloads.download`.
function _safeName(name) {
  return String(name || "").replace(/^[\\/]+/, "");
}

// Trigger one chrome.downloads.download per item. Each `item` must have
// `{filename, text}`; `videoId` is accepted but unused.
// Returns `{ok:N, failed:[{filename,error}]}`.
async function downloadIndividual(items) {
  let ok = 0;
  const failed = [];
  for (const item of items || []) {
    const filename = _safeName(item.filename);
    try {
      const dataUrl =
        "data:text/plain;charset=utf-8," + encodeURIComponent(item.text || "");
      await chrome.downloads.download({
        url: dataUrl,
        filename,
        saveAs: false,
        conflictAction: "uniquify",
      });
      ok++;
    } catch (e) {
      failed.push({ filename, error: String(e?.message || e) });
    }
  }
  return { ok, failed };
}

// Bundle all items into a single .zip and trigger one download.
// Returns `{ok:true, size}` on success.
//
// MV3 service workers don't expose URL.createObjectURL, so we ask JSZip for a
// base64 string and build a data: URL that chrome.downloads.download can fetch.
async function downloadZip(items, zipName) {
  const zip = new JSZip();
  for (const item of items || []) {
    zip.file(_safeName(item.filename), item.text || "");
  }
  const base64 = await zip.generateAsync({
    type: "base64",
    compression: "DEFLATE",
    compressionOptions: { level: 6 },
  });
  const url = `data:application/zip;base64,${base64}`;
  await chrome.downloads.download({
    url,
    filename: _safeName(zipName),
    saveAs: false,
    conflictAction: "uniquify",
  });
  return { ok: true, size: base64.length };
}
