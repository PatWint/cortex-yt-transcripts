# YouTube Transcript Downloader

Chrome / Edge extension (Manifest V3) that batch-scrapes YouTube transcripts, syncs them to a BigQuery-backed cloud store, and coordinates a shared work queue + watchlist across multiple users. Companion to the FastAPI service under [`ingestion-api/youtube/`](../../../ingestion-api/youtube).

## Install (unpacked)

1. Open `chrome://extensions` (or `edge://extensions`).
2. Enable **Developer mode** (top right).
3. Click **Load unpacked** and select this folder.
4. Open the popup → **Settings → Cloud** and fill in:
   - **API URL** (e.g. `https://yt-transcript-api.alphacortex.dev` — `https://` auto-added if omitted)
   - **API key** (your personal key; see "Managing API keys" in `ingestion-api/youtube/README.md`)
5. Pin the extension to the toolbar.

The popup also has a **pin** button (top-right) to move the UI into Chrome's side panel.

## UI

Four top-level tabs:

| Tab | What it does |
|---|---|
| **Capture** | Add the current video / whole channel / pasted URL to the local queue. Shows the download queue with Active / Failed / Unsynced / Cloud Queue sub-tabs. Run / pause the batch. |
| **Auto-Feeds** | Shared cross-user channel watchlist. Watch the current channel, refresh with ↻, open a formatted RSS feed viewer per row, check for new videos across all watched channels. |
| **Library** | Browse transcripts already in BigQuery. Search (title / channel / body), filter by channel, sort, date range. Channel filter auto-loads all pages. Download any row as `.txt` with metadata header. |
| **Settings** | General (language, timestamps, delay between videos, overlay toggle) and Cloud (sync toggles, API URL, API key, maintenance). |

## Key flows

### Batch-scrape a video / channel

1. Visit a YouTube page.
2. **Capture** tab → **Add current video** / **Add channel's videos** / paste-URL.
3. Click **Start**. The batch opens each video in a pinned background tab, extracts captions, writes to the local queue, and (if Auto-sync is on) pushes to the cloud store.

### Auto-Feeds (watchlist)

Watchlist lives in BigQuery (`cortex.yt_transcript_watchlist`) and is shared by all users. The plugin keeps **no local copy** — it re-fetches on tab click (60s in-memory cache), on ↻ refresh, and after any add/remove.

- **Watch current channel** — must be on a `/@handle` or `/channel/UC…` page.
- **📄 button** — opens `feed-viewer.html?channel_id=…` in a new tab, which fetches the Atom RSS and renders it as a video list (thumbnail, title, date, views, likes, description).
- **× button** — removes the row from the shared watchlist (deletes the BQ row).
- **Check N channels for new videos** — walks every watched channel's RSS feed, queues any net-new `videoId` into the local queue (and, if sync is on, into the cloud queue).

### Cloud Queue (shared work pool)

With **Sync download queue with cloud** on, every local add is mirrored into `cortex.yt_transcript_queue`. The plugin atomically claims items from the pool via a server-generated `claim_token` — no two users ever scrape the same video. Scraping a cloud-sourced item uploads the transcript + deletes the queue row. Failed scrapes `release` the row (fail_count tracked; hidden after 3 fails).

### Library

Everything already synced to `cortex.yt_transcript_items`. Supports:
- **Search** across title / channel / body (case-insensitive LIKE on the server).
- **Channel filter** — dropdown populated from `/transcripts/channels`. When active, all pages auto-load (no "Load more").
- **Sort** by synced / published / views / length / channel.
- **Date range** on `published_at`.
- **Download button** per row (writes a `.txt` with `# Title / URL / Channel / ...` metadata header followed by body text).

## Raw-feed URL auto-redirect

A `declarativeNetRequest` dynamic rule intercepts top-level navigations to `https://www.youtube.com/feeds/videos.xml?channel_id=…` and redirects to the bundled formatted viewer. Background fetches / XHRs still see the raw XML so RSS readers and scripts keep working.

## File layout

| File | Purpose |
|---|---|
| `manifest.json` | MV3 manifest. Permissions: `activeTab, scripting, downloads, tabs, storage, unlimitedStorage, sidePanel, declarativeNetRequestWithHostAccess`. Host permissions include `<all_urls>` for the cloud API. |
| `background.js` | Service worker — queue engine, message router, cloud sync, claim loop, watchlist client, feed-redirect rule registration. |
| `popup.html` / `popup.css` / `popup.js` | Main UI (tabs, queue list, watchlist, library, settings). |
| `scrapers.js` | Page-injected MAIN-world helpers: `grabTranscript`, `grabChannelVideos`, `grabChannelMeta` (all UC-validated), `sanitize`. |
| `downloader.js` | Turns transcripts into `.txt` files via `chrome.downloads.download`. |
| `content.js` / `content.css` | On-page overlay (toggleable via `show-overlay` setting). |
| `probe.js` | Injected on all pages so out-of-band tools (e.g. `podcasts/update_plugin_settings.py`, `podcasts/browser_inspect.py queue`) can read/patch `chrome.storage.local` via `postMessage`. |
| `feed-viewer.html` / `.js` / `.css` | Formatted RSS feed viewer (thumbnail list). |
| `icons/` | Red/gray icon variants (red on youtube.com tabs, gray elsewhere). |

## Plugin → API wire protocol

- `X-API-Key` — the shared secret, resolved against `cortex.yt_transcript_api_keys`.
- `X-Plugin-Version` — sent on every request; server responds with `X-Min-Plugin-Version`, and 426s if below (currently `0.8.0`). Bump `manifest.json` version alongside any wire break.
- All URLs go through `apiBase(settings)` which auto-prepends `https://` if the stored `apiUrl` is missing a scheme.

## Storage keys (local)

- `queue` — batch queue (pending / running / done / failed / skipped items). Deduped by `videoId` at the storage layer.
- `settings` — user preferences (lang, delayMs, apiUrl, apiKey, `autoSyncCloud`, `syncDownloadQueue`, etc.).
- `batch` — `{state, currentId}` — running / paused / idle.
- `transcript:<item.id>` — per-item transcript body (not in the queue array to keep the queue small).

Two legacy keys (`channels`, `removedVideoIds`) are purged on service-worker startup — the watchlist is cloud-hosted and local tombstones were removed (they corrupted `fail_count` on the shared cloud queue).

## Limits

- Only works on videos with captions (manual or auto-generated). Live streams without captions / age-gated / members-only videos fail gracefully (`release`'d back to the pool).
- Chrome 136+ blocks `--remote-debugging-port` on the Default profile. Automation sessions (see `helpers/youtube/md/BROWSER_AGENT.md`) use a dedicated copy of the profile at `podcasts/chrome_profile/`.

## Testing & debugging

- `chrome://extensions` → click **Inspect views: service worker** to see background.js logs.
- Popup has its own devtools: right-click anywhere in the popup → **Inspect**.
- `/whoami` is a useful auth smoke test: `curl -H "X-API-Key: ..." $API/whoami` should echo your human name.
- `podcasts/browser_inspect.py queue` dumps the popup's view of `chrome.storage.local` without opening the UI.
