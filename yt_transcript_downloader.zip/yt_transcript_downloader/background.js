// MV3 service worker: queue engine for batch YouTube transcript extraction.
// Sibling files expose globals grabTranscript/grabChannelVideos (scrapers.js)
// and downloadIndividual/downloadZip (downloader.js).
importScripts("scrapers.js", "downloader.js");

// Version from manifest — sent on every outbound API request as
// `X-Plugin-Version`. The API's version-check middleware 426s us if we're
// below its minimum. Exposed so auth/queue helpers can include it uniformly.
const PLUGIN_VERSION = chrome.runtime.getManifest().version;

// Set while grabChannelVideos is in flight so a "scrape-stop" message knows
// which tab to toggle the stop flag on. Null otherwise.
let activeScrapeTabId = null;

function authHeaders(settings) {
  return {
    "Content-Type": "application/json",
    "X-API-Key": settings.apiKey,
    "X-Plugin-Version": PLUGIN_VERSION,
  };
}

// Normalize the user-supplied API URL: tolerate a missing scheme (store
// allowed "yt-transcript-api.alphacortex.dev"), strip trailing slash.
// Without this, fetch() treats a schemeless string as relative to
// chrome-extension:// and throws "Failed to fetch".
function apiBase(settings) {
  const raw = (settings?.apiUrl || "").trim();
  if (!raw) return "";
  const withScheme = /^https?:\/\//i.test(raw) ? raw : `https://${raw}`;
  return withScheme.replace(/\/+$/, "");
}

// Swap the toolbar icon per-tab: red when on youtube.com, gray everywhere else.
const ICON_RED = { 16: "icons/icon16.png", 32: "icons/icon32.png", 48: "icons/icon48.png", 128: "icons/icon128.png" };
const ICON_GRAY = { 16: "icons/icon16_gray.png", 32: "icons/icon32_gray.png", 48: "icons/icon48_gray.png", 128: "icons/icon128_gray.png" };
function applyIconForUrl(tabId, url) {
  const onYT = /^https?:\/\/(www\.|m\.)?youtube\.com\//.test(url || "");
  chrome.action.setIcon({ tabId, path: onYT ? ICON_RED : ICON_GRAY }).catch(() => {});
}
chrome.tabs.onActivated.addListener(async ({ tabId }) => {
  try { const t = await chrome.tabs.get(tabId); applyIconForUrl(tabId, t.url); } catch {}
});
chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (info.url || info.status === "loading") applyIconForUrl(tabId, info.url || tab.url);
});

// Toolbar icon always opens the side panel instead of the transient popup.
// Side-panel content is the same popup.html (launched with ?panel=1 via the
// manifest's side_panel.default_path). Set openPanelOnActionClick=true
// overrides the popup, so no chrome.action.setPopup is needed.
chrome.sidePanel
  .setPanelBehavior({ openPanelOnActionClick: true })
  .catch((e) => console.warn("[yt-transcript] setPanelBehavior failed:", String(e)));

// Redirect raw YouTube channel-feed URLs to our formatted viewer. A user
// typing the feed URL directly (or clicking any link to it) lands on
// feed-viewer.html?channel_id=... instead of the raw XML.
//
// Only top-level navigations — RSS-reader fetches and XMLHttpRequests keep
// getting the real XML so downstream tooling isn't disrupted.
async function registerFeedRedirectRule() {
  const feedViewerUrl = chrome.runtime.getURL("feed-viewer.html");
  const rule = {
    id: 1001,
    priority: 1,
    action: {
      type: "redirect",
      redirect: {
        regexSubstitution: `${feedViewerUrl}?channel_id=\\1`,
      },
    },
    condition: {
      regexFilter: "^https://www\\.youtube\\.com/feeds/videos\\.xml\\?.*channel_id=([A-Za-z0-9_-]+)",
      resourceTypes: ["main_frame"],
    },
  };
  try {
    await chrome.declarativeNetRequest.updateDynamicRules({
      addRules: [rule],
      removeRuleIds: [1001],
    });
  } catch (e) {
    console.warn("[yt-transcript] feed-redirect rule install failed:", String(e));
  }
}
chrome.runtime.onInstalled.addListener(() => { registerFeedRedirectRule(); });
chrome.runtime.onStartup.addListener(() => { registerFeedRedirectRule(); });
// Also register on module load so the rule comes back if the SW is woken up.
registerFeedRedirectRule();

const DEFAULT_SETTINGS = {
  lang: "en",
  includeTimestamps: false,
  downloadMode: "individual",
  delayMs: 4000,
  apiUrl: "",
  apiKey: "",
  autoSyncCloud: false,
  syncDownloadQueue: false,
};
const DEFAULT_BATCH = { state: "idle", currentId: null };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// Local 2-strike policy: after two consecutive scrape failures an item stays
// in `failed` permanently and retry paths must skip it. Decoupled from the
// server's own fail_count on shared-pool rows.
const LOCAL_FAIL_LIMIT = 2;
const isPermanentlyFailed = (it) =>
  it?.status === "failed" && (it.failCount || 0) >= LOCAL_FAIL_LIMIT;

function videoIdFromUrl(url) {
  try { return new URL(url).searchParams.get("v") || null; } catch { return null; }
}

async function getState() {
  const s = await chrome.storage.local.get(["queue", "settings", "batch"]);
  return {
    queue: s.queue || [],
    settings: { ...DEFAULT_SETTINGS, ...(s.settings || {}) },
    batch: { ...DEFAULT_BATCH, ...(s.batch || {}) },
  };
}

// videoId is effectively a primary key for queue entries. Enforce uniqueness
// at the storage layer so a concurrent add-race can never persist duplicates.
function dedupeQueueByVideoId(queue) {
  if (!Array.isArray(queue)) return queue;
  const seen = new Set();
  return queue.filter((q) => {
    if (!q?.videoId) return true;
    if (seen.has(q.videoId)) return false;
    seen.add(q.videoId);
    return true;
  });
}

const setState = (patch) => {
  if (patch.queue) patch = { ...patch, queue: dedupeQueueByVideoId(patch.queue) };
  return chrome.storage.local.set(patch);
};

// Watchlist is cloud-hosted (cortex.yt_transcript_watchlist). No local copy
// — the plugin fetches on Auto-Feeds tab click and on manual refresh. A
// short in-memory cache keeps rapid re-opens snappy without stale reads.
const WATCHLIST_CACHE_TTL_MS = 60 * 1000;
let _watchlistCache = { items: null, fetchedAt: 0 };

// One-time cleanup of the legacy local watchlist key. Safe to keep forever.
chrome.storage.local.remove("channels").catch(() => {});

async function fetchCloudWatchlist(settings) {
  if (!settings.apiUrl || !settings.apiKey) {
    throw new Error("Cloud not configured");
  }
  const url = apiBase(settings) + "/watchlist";
  const resp = await fetch(url, { headers: authHeaders(settings) });
  if (!resp.ok) {
    const body = await resp.text().catch(() => "");
    throw new Error(`HTTP ${resp.status}${body ? `: ${body.slice(0, 160)}` : ""}`);
  }
  const data = await resp.json();
  return (data.items || []).map((r) => ({
    channelId: r.channel_id,
    handle: r.handle || "",
    displayName: r.display_name || r.handle || r.channel_id,
    url: r.url || `https://www.youtube.com/channel/${r.channel_id}`,
    addedAt: r.added_at || null,
  }));
}

async function getWatchlist({ forceRefresh = false } = {}) {
  const now = Date.now();
  if (!forceRefresh && _watchlistCache.items && now - _watchlistCache.fetchedAt < WATCHLIST_CACHE_TTL_MS) {
    return _watchlistCache.items;
  }
  const { settings } = await getState();
  const items = await fetchCloudWatchlist(settings);
  _watchlistCache = { items, fetchedAt: Date.now() };
  return items;
}

function invalidateWatchlistCache() {
  _watchlistCache = { items: null, fetchedAt: 0 };
}

async function postWatchlistAdd(meta) {
  const { settings } = await getState();
  if (!settings.apiUrl || !settings.apiKey) throw new Error("Cloud not configured");
  const url = apiBase(settings) + "/watchlist";
  const resp = await fetch(url, {
    method: "POST",
    headers: authHeaders(settings),
    body: JSON.stringify({
      channel_id: meta.channelId,
      handle: meta.handle || null,
      display_name: meta.title || meta.handle || meta.channelId,
      url: meta.url || `https://www.youtube.com/channel/${meta.channelId}`,
    }),
  });
  if (!resp.ok) {
    const body = await resp.text().catch(() => "");
    throw new Error(`HTTP ${resp.status}${body ? `: ${body.slice(0, 160)}` : ""}`);
  }
  invalidateWatchlistCache();
  return await resp.json();  // {added, deduped}
}

async function deleteWatchlist(channelId) {
  const { settings } = await getState();
  if (!settings.apiUrl || !settings.apiKey) throw new Error("Cloud not configured");
  const url = apiBase(settings) + "/watchlist/" + encodeURIComponent(channelId);
  const resp = await fetch(url, { method: "DELETE", headers: authHeaders(settings) });
  if (!resp.ok && resp.status !== 404) {
    const body = await resp.text().catch(() => "");
    throw new Error(`HTTP ${resp.status}${body ? `: ${body.slice(0, 160)}` : ""}`);
  }
  invalidateWatchlistCache();
}

// Drop the legacy tombstone key if it's still hanging around from older
// installs. Removing it costs nothing if already absent.
chrome.storage.local.remove("removedVideoIds").catch(() => {});

// Recover from SW restart mid-run: any 'running' item is orphaned (its tab is
// gone, its loop context is dead). Mark them 'pending' and reset batch to idle.
// Also dedupe the queue by videoId — clears any stale duplicates from before
// the setState-level guard was added.
(async () => {
  const { queue, batch } = await getState();
  let dirty = false;
  for (const it of queue) if (it.status === "running") { it.status = "pending"; dirty = true; }
  const deduped = dedupeQueueByVideoId(queue);
  if (deduped.length !== queue.length) dirty = true;
  if (dirty || batch.state === "running") {
    await setState({ queue: deduped, batch: { state: "idle", currentId: null } });
  }
  // Stale scraper tab reference from a prior SW lifetime — drop it (the tab
  // itself might still exist but we'll create a fresh one on next run).
  await chrome.storage.local.remove("scraperTabId");
})();

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    try {
      switch (msg?.type) {
        case "get-queue-state": {
          const s = await chrome.storage.local.get(["queue", "batch", "settings"]);
          return sendResponse(s);
        }
        case "add-video": {
          // Shorts filter (client-side). Two-tier check:
          //   1) URL says /shorts/<id> → definitely a short, block immediately.
          //   2) /watch?v=<id> → inject into the tab, read
          //      ytInitialPlayerResponse.videoDetails.lengthSeconds. If < 125s,
          //      block. If unavailable (player data not hydrated), let it pass
          //      — backend has its own shorts filter as a safety net.
          if (msg.url && /youtube\.com\/shorts\//.test(msg.url)) {
            return sendResponse({ ok: false, isShort: true, error: "shorts are skipped" });
          }
          if (msg.tabId != null) {
            try {
              const [{ result }] = await chrome.scripting.executeScript({
                target: { tabId: msg.tabId }, world: "MAIN",
                func: grabCurrentVideoInfo,
              });
              if (result?.isShortUrl) {
                return sendResponse({ ok: false, isShort: true, error: "shorts are skipped" });
              }
              if (result && typeof result.lengthSeconds === "number" && result.lengthSeconds < 125) {
                return sendResponse({ ok: false, isShort: true, error: "shorts are skipped" });
              }
            } catch (e) {
              // executeScript failures (e.g. restricted page) fall through to
              // normal add — backend filter is the backstop.
              console.warn("[yt-transcript] shorts-check skipped:", String(e));
            }
          }
          const id = videoIdFromUrl(msg.url);
          if (!id) return sendResponse({ ok: false, error: "Bad URL" });
          const { queue, settings } = await getState();
          if (queue.some((q) => q.videoId === id)) return sendResponse({ ok: true, deduped: true });
          const newItem = {
            id: `${id}-${Date.now()}`, videoId: id, url: msg.url,
            title: msg.title || "", channel: "", channelHandle: "", channelDisplayName: "",
            status: "pending", addedAt: Date.now(),
          };
          queue.push(newItem);
          await setState({ queue });
          // Single-video add: await cloud response so the status line can
          // distinguish "new in cloud" from "already in cloud". Safe to
          // await because it's one HTTP round trip (~300ms).
          let cloudResult = null;
          if (settings.syncDownloadQueue && settings.apiUrl && settings.apiKey) {
            try {
              cloudResult = await pushToCloudQueue([newItem], settings);
            } catch (e) {
              console.warn("[yt-transcript] cloud push failed:", String(e));
              cloudResult = { error: String(e.message || e) };
            }
          }
          return sendResponse({ ok: true, added: 1, cloud: cloudResult });
        }
        case "add-channel": {
          const { queue, settings } = await getState();
          const seen = new Set(queue.map((q) => q.videoId));
          const newItems = [];
          for (const v of msg.videos || []) {
            if (!v.id || seen.has(v.id)) continue;
            seen.add(v.id);
            const it = {
              id: `${v.id}-${Date.now()}-${newItems.length}`, videoId: v.id, url: v.url,
              title: v.title || "", channel: v.meta || "", channelHandle: "", channelDisplayName: "",
              status: "pending", addedAt: Date.now(),
            };
            queue.push(it);
            newItems.push(it);
          }
          await setState({ queue });
          maybePushToCloudQueue(newItems, settings);
          return sendResponse({ ok: true, added: newItems.length });
        }
        case "scrape-and-add-channel": {
          // grabChannelVideos only finds items on the /videos tab. If the
          // user clicked "Add channel" from the channel Home (e.g.
          // /@joincolossus), navigate to /videos first.
          const tab = await chrome.tabs.get(msg.tabId);
          const u = new URL(tab.url);
          const m = u.pathname.match(
            /^\/(@[^/]+|channel\/[^/]+|c\/[^/]+|user\/[^/]+)(?:\/([^/]+))?\/?$/
          );
          if (m && m[2] !== "videos") {
            const videosUrl = `${u.origin}/${m[1]}/videos`;
            await chrome.tabs.update(msg.tabId, { url: videosUrl });
            await waitForTabComplete(msg.tabId);
          }
          // Track the scraping tab so "scrape-stop" and "get-scrape-progress"
          // know which page to read from. Cleared when the scrape resolves.
          activeScrapeTabId = msg.tabId;
          let execResult;
          try {
            [execResult] = await chrome.scripting.executeScript({
              target: { tabId: msg.tabId }, world: "MAIN",
              func: grabChannelVideos,
            });
          } finally {
            activeScrapeTabId = null;
          }
          const result = execResult?.result;
          if (!result || result.error) return sendResponse({ ok: false, error: result?.error || "scrape failed" });
          const { queue, settings } = await getState();
          const seen = new Set(queue.map((q) => q.videoId));
          const newItems = [];
          for (const v of result.videos || []) {
            if (!v.id || seen.has(v.id)) continue;
            seen.add(v.id);
            const it = {
              id: `${v.id}-${Date.now()}-${newItems.length}`, videoId: v.id, url: v.url,
              title: v.title || "",
              channel: result.channelDisplayName || result.channel || "",
              channelHandle: result.channelHandle || "",
              channelDisplayName: result.channelDisplayName || result.channel || "",
              status: "pending", addedAt: Date.now(),
            };
            queue.push(it);
            newItems.push(it);
          }
          await setState({ queue });
          // Batch cloud push: single POST regardless of item count. Await so
          // the popup status can report how many were new vs already-in-cloud.
          let cloudResult = null;
          if (newItems.length && settings.syncDownloadQueue && settings.apiUrl && settings.apiKey) {
            try {
              cloudResult = await pushToCloudQueue(newItems, settings);
            } catch (e) {
              console.warn("[yt-transcript] batch cloud push failed:", String(e));
              cloudResult = { error: String(e.message || e) };
            }
          }
          return sendResponse({
            ok: true,
            added: newItems.length,
            channel: result.channelDisplayName || result.channel,
            cloud: cloudResult,
            // Shorts filter summary: scraper drops videos <125s at scrape time;
            // count flows through to popup status line.
            shortsSkipped: result.shortsSkipped || 0,
          });
        }
        case "scrape-stop": {
          if (activeScrapeTabId == null) return sendResponse({ ok: false, error: "no active scrape" });
          try {
            await chrome.scripting.executeScript({
              target: { tabId: activeScrapeTabId }, world: "MAIN",
              func: () => { if (window.__ytcxScrape) window.__ytcxScrape.stop = true; },
            });
            return sendResponse({ ok: true });
          } catch (e) {
            return sendResponse({ ok: false, error: String(e?.message || e) });
          }
        }
        case "get-scrape-progress": {
          if (activeScrapeTabId == null) return sendResponse({ count: null });
          try {
            const [{ result }] = await chrome.scripting.executeScript({
              target: { tabId: activeScrapeTabId }, world: "MAIN",
              func: () => Number(window.__ytcxScrape?.count || 0),
            });
            return sendResponse({ count: result });
          } catch {
            return sendResponse({ count: null });
          }
        }
        case "start":
        case "resume": {
          await setState({ batch: { state: "running", currentId: null } });
          // Pull from cloud immediately when starting — ensures the batch has
          // work even if local queue was empty.
          const { settings: s } = await getState();
          cloudQueueClaim(s).catch(() => {});
          runLoop();
          return sendResponse({ ok: true });
        }
        case "pause": {
          const { batch } = await getState();
          await setState({ batch: { ...batch, state: "paused" } });
          return sendResponse({ ok: true });
        }
        case "clear": {
          const { batch } = await getState();
          if (batch.state === "running") return sendResponse({ ok: false, reason: "running" });
          const all = await chrome.storage.local.get(null);
          const tKeys = Object.keys(all).filter((k) => k.startsWith("transcript:"));
          if (tKeys.length) await chrome.storage.local.remove(tKeys);
          await setState({ queue: [], batch: { state: "idle", currentId: null } });
          await closeScraperTab();
          return sendResponse({ ok: true });
        }
        case "remove": {
          // Purely local. We NEVER delete from the cloud queue here — the
          // cloud is the shared source of truth. If a future RSS/claim
          // pass re-surfaces this video, the user can × it again; no
          // shared tombstone (that model corrupted fail_count for other
          // users on the shared queue).
          const { queue } = await getState();
          await chrome.storage.local.remove(`transcript:${msg.id}`);
          await setState({ queue: queue.filter((q) => q.id !== msg.id) });
          return sendResponse({ ok: true });
        }
        case "retry": {
          const { queue } = await getState();
          const it = queue.find((q) => q.id === msg.id);
          if (!it) return sendResponse({ ok: false, error: "not found" });
          if (it.status !== "failed") return sendResponse({ ok: false, error: "not failed" });
          if (isPermanentlyFailed(it)) return sendResponse({ ok: false, error: "permanently failed" });
          it.status = "pending"; it.error = undefined;
          await setState({ queue });
          return sendResponse({ ok: true });
        }
        case "retry-all-and-start": {
          const { queue } = await getState();
          let reset = 0;
          for (const it of queue) {
            if (isPermanentlyFailed(it)) continue;
            if (it.status === "failed" || it.status === "skipped") {
              it.status = "pending"; it.error = undefined; reset++;
            }
          }
          await setState({ queue, batch: { state: "running", currentId: null } });
          runLoop();
          return sendResponse({ ok: true, reset });
        }
        case "start-from": {
          const { queue } = await getState();
          const idx = queue.findIndex((q) => q.id === msg.id);
          if (idx < 0) return sendResponse({ ok: false, error: "not found" });
          // Items before: any pending/failed become skipped. Leave done alone.
          for (let i = 0; i < idx; i++) {
            const s = queue[i].status;
            if (s === "pending" || s === "failed") {
              queue[i].status = "skipped";
              queue[i].error = undefined;
            }
          }
          // Clicked item: reset so it runs next.
          const it = queue[idx];
          if (it.status === "done") await chrome.storage.local.remove(`transcript:${it.id}`);
          it.status = "pending"; it.error = undefined; it.textLen = undefined; it.completedAt = undefined;
          await setState({ queue, batch: { state: "running", currentId: null } });
          runLoop();
          return sendResponse({ ok: true });
        }
        case "update-settings": {
          const { settings } = await getState();
          const next = { ...settings, ...(msg.settings || {}) };
          await setState({ settings: next });
          // Toggle-on (syncDownloadQueue): one-shot backfill of pending
          // items to the cloud pool so existing local work shows up for
          // other installs.
          const wasSDQ = !!settings.syncDownloadQueue;
          const nowSDQ = !!next.syncDownloadQueue;
          if (!wasSDQ && nowSDQ && next.apiUrl && next.apiKey) {
            backfillPendingToCloud(next).catch(() => {});
          }
          // Toggle-on (autoSyncCloud): one-shot push of every currently-
          // unsynced transcript. Behaves like clicking "Sync all to cloud"
          // immediately on enabling auto-sync.
          const wasASC = !!settings.autoSyncCloud;
          const nowASC = !!next.autoSyncCloud;
          if (!wasASC && nowASC && next.apiUrl && next.apiKey) {
            backfillUnsyncedTranscripts(next).catch(() => {});
          }
          return sendResponse({ ok: true });
        }
        case "download-results": {
          const { queue, settings } = await getState();
          const items = [];
          for (const q of queue.filter((x) => x.status === "done")) {
            const key = `transcript:${q.id}`;
            const text = (await chrome.storage.local.get(key))[key];
            if (text) items.push({ filename: `${transcriptFilename(q)}.txt`, text: withHeader(q, text) });
          }
          if (!items.length) return sendResponse({ ok: false, error: "nothing done" });
          const mode = msg.mode || settings.downloadMode;
          if (mode === "zip") await downloadZip(items, `transcripts-${Date.now()}.zip`);
          else await downloadIndividual(items);
          return sendResponse({ ok: true, count: items.length, mode });
        }
        case "download-one": {
          const { queue } = await getState();
          const it = queue.find((q) => q.id === msg.id);
          if (!it || it.status !== "done") return sendResponse({ ok: false, error: "not ready" });
          const key = `transcript:${it.id}`;
          const text = (await chrome.storage.local.get(key))[key];
          if (!text) return sendResponse({ ok: false, error: "no transcript" });
          await downloadIndividual([{ filename: `${transcriptFilename(it)}.txt`, text: withHeader(it, text) }]);
          return sendResponse({ ok: true });
        }
        case "sync-one": {
          const { queue, settings } = await getState();
          const it = queue.find((q) => q.id === msg.id);
          if (!it || it.status !== "done") return sendResponse({ ok: false, error: "not ready" });
          try {
            await syncItems([it], settings);
            return sendResponse({ ok: true });
          } catch (e) {
            return sendResponse({ ok: false, error: String(e?.message || e) });
          }
        }
        case "sync-all": {
          const { queue, settings } = await getState();
          const todo = queue.filter((q) => q.status === "done" && !q.syncedAt);
          if (!todo.length) return sendResponse({ ok: true, synced: 0 });
          try {
            const n = await syncItems(todo, settings);
            return sendResponse({ ok: true, synced: n });
          } catch (e) {
            return sendResponse({ ok: false, error: String(e?.message || e) });
          }
        }
        case "admin-delete-queue": {
          const { settings } = await getState();
          if (!settings.apiUrl || !settings.apiKey) {
            return sendResponse({ ok: false, error: "not configured" });
          }
          try {
            const url = apiBase(settings) + "/admin/queue/delete";
            const resp = await fetch(url, {
              method: "POST",
              headers: authHeaders(settings),
              body: JSON.stringify({ video_ids: msg.videoIds || [] }),
            });
            if (!resp.ok) {
              const body = await resp.text().catch(() => "");
              throw new Error(`HTTP ${resp.status}${body ? `: ${body.slice(0, 160)}` : ""}`);
            }
            const data = await resp.json();
            return sendResponse({ ok: true, deleted: data.deleted || 0 });
          } catch (e) {
            return sendResponse({ ok: false, error: String(e?.message || e) });
          }
        }
        case "whoami": {
          const { settings } = await getState();
          if (!settings.apiUrl || !settings.apiKey) {
            return sendResponse({ ok: false, error: "not configured" });
          }
          try {
            const resp = await fetch(apiBase(settings) + "/whoami", { headers: authHeaders(settings) });
            if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
            const data = await resp.json();
            return sendResponse({ ok: true, name: data.name || "" });
          } catch (e) {
            return sendResponse({ ok: false, error: String(e?.message || e) });
          }
        }
        case "list-watchlist": {
          try {
            const channels = await getWatchlist({ forceRefresh: !!msg.forceRefresh });
            return sendResponse({ ok: true, channels });
          } catch (e) {
            return sendResponse({ ok: false, error: String(e?.message || e) });
          }
        }
        case "check-missing": {
          // Admin → Auto-Update → "Check missing videos" for one channel.
          // Hits GET /missing?channel=<handle>&limit=<n> on the ingestion API.
          try {
            const { settings } = await chrome.storage.local.get("settings");
            if (!settings?.apiUrl || !settings?.apiKey) {
              return sendResponse({ ok: false, error: "Cloud not configured" });
            }
            const handle = (msg.handle || "").trim();
            if (!handle) return sendResponse({ ok: false, error: "missing handle" });
            const limit = Math.max(1, Math.min(5000, parseInt(msg.limit, 10) || 50));
            const url = `${apiBase(settings)}/missing?channel=${encodeURIComponent(handle)}&limit=${limit}`;
            const resp = await fetch(url, { headers: authHeaders(settings) });
            if (!resp.ok) {
              const body = await resp.text().catch(() => "");
              return sendResponse({
                ok: false,
                error: `HTTP ${resp.status}${body ? `: ${body.slice(0, 160)}` : ""}`,
              });
            }
            const data = await resp.json();
            return sendResponse({ ok: true, items: data.items || [] });
          } catch (e) {
            return sendResponse({ ok: false, error: String(e?.message || e) });
          }
        }
        case "fetch-yt-api-usage": {
          // Admin → YT API → Cloud Monitoring-backed usage stats
          try {
            const { settings } = await chrome.storage.local.get("settings");
            if (!settings?.apiUrl || !settings?.apiKey) {
              return sendResponse({ ok: false, error: "Cloud not configured" });
            }
            const url = `${apiBase(settings)}/yt_api_usage`;
            const resp = await fetch(url, { headers: authHeaders(settings) });
            if (!resp.ok) {
              const body = await resp.text().catch(() => "");
              return sendResponse({
                ok: false,
                error: `HTTP ${resp.status}${body ? `: ${body.slice(0, 160)}` : ""}`,
              });
            }
            const data = await resp.json();
            return sendResponse({ ok: true, data });
          } catch (e) {
            return sendResponse({ ok: false, error: String(e?.message || e) });
          }
        }
        case "queue-add-missing": {
          // Admin → Auto-Update → "Add all to queue" — POST /queue/add
          try {
            const { settings } = await chrome.storage.local.get("settings");
            if (!settings?.apiUrl || !settings?.apiKey) {
              return sendResponse({ ok: false, error: "Cloud not configured" });
            }
            const items = Array.isArray(msg.items) ? msg.items : [];
            if (items.length === 0) {
              return sendResponse({ ok: false, error: "no items to queue" });
            }
            const handle = (msg.handle || "").trim();
            // Shape items as QueueItem (see /queue/add in main.py):
            // {video_id, title?, url, channel?, from_watchlist?}
            const payload = items.map((v) => ({
              video_id: v.video_id,
              title: v.title || null,
              url: v.url,
              channel: v.channel_handle || handle || null,
              from_watchlist: v.channel_handle || handle || null,
            }));
            const url = `${apiBase(settings)}/queue/add`;
            const resp = await fetch(url, {
              method: "POST",
              headers: authHeaders(settings),
              body: JSON.stringify(payload),
            });
            if (!resp.ok) {
              const body = await resp.text().catch(() => "");
              return sendResponse({
                ok: false,
                error: `HTTP ${resp.status}${body ? `: ${body.slice(0, 160)}` : ""}`,
              });
            }
            const data = await resp.json();
            return sendResponse({
              ok: true,
              added: data.added || 0,
              deduped: data.deduped || 0,
            });
          } catch (e) {
            return sendResponse({ ok: false, error: String(e?.message || e) });
          }
        }
        case "add-watched-from-tab": {
          // Current tab must be a channel page — extract {channelId, handle,
          // title, url} via ytInitialData in MAIN world, then register.
          try {
            const [{ result }] = await chrome.scripting.executeScript({
              target: { tabId: msg.tabId }, world: "MAIN", func: grabChannelMeta,
            });
            if (!result || result.error || !result.channelId) {
              return sendResponse({ ok: false, error: result?.error || "no channel id" });
            }
            const added = await addWatchedChannel(result);
            return sendResponse({ ok: true, ...added });
          } catch (e) {
            return sendResponse({ ok: false, error: String(e?.message || e) });
          }
        }
        case "add-watched-from-url": {
          // Paste-flow: open a hidden tab on the channel URL, extract meta,
          // close tab. Handles @handle, /channel/UC..., /c/ and /user/ forms.
          const url = normalizeChannelUrl(msg.url || "");
          if (!url) return sendResponse({ ok: false, error: "unrecognized URL" });
          let tab = null;
          try {
            tab = await chrome.tabs.create({ url, active: false, pinned: true });
            await waitForTabComplete(tab.id, 20000);
            const [{ result }] = await chrome.scripting.executeScript({
              target: { tabId: tab.id }, world: "MAIN", func: grabChannelMeta,
            });
            if (!result || result.error || !result.channelId) {
              return sendResponse({ ok: false, error: result?.error || "no channel id" });
            }
            const added = await addWatchedChannel(result);
            return sendResponse({ ok: true, ...added });
          } catch (e) {
            return sendResponse({ ok: false, error: String(e?.message || e) });
          } finally {
            if (tab?.id) { try { await chrome.tabs.remove(tab.id); } catch {} }
          }
        }
        case "remove-watched": {
          try {
            await deleteWatchlist(msg.channelId);
            return sendResponse({ ok: true });
          } catch (e) {
            return sendResponse({ ok: false, error: String(e?.message || e) });
          }
        }
        case "check-watchlist": {
          try {
            const result = await checkWatchlist();
            return sendResponse({ ok: true, ...result });
          } catch (e) {
            return sendResponse({ ok: false, error: String(e?.message || e) });
          }
        }
        case "claim-from-cloud": {
          const { settings } = await getState();
          try {
            const [claim, stats] = await Promise.all([
              cloudQueueClaim(settings),
              cloudQueueStats(settings).catch(() => null),
            ]);
            return sendResponse({ ok: true, ...claim, stats });
          } catch (e) {
            return sendResponse({ ok: false, error: String(e?.message || e) });
          }
        }
        case "list-library": {
          const { settings } = await getState();
          if (!settings.apiUrl || !settings.apiKey) {
            return sendResponse({ ok: false, error: "not configured" });
          }
          try {
            const p = new URLSearchParams();
            p.set("limit", String(msg.limit ?? 100));
            p.set("offset", String(msg.offset ?? 0));
            if (msg.search)    p.set("search", msg.search);
            if (msg.channel)   p.set("channel", msg.channel);
            if (msg.sort)      p.set("sort", msg.sort);
            if (msg.order)     p.set("order", msg.order);
            if (msg.dateFrom)  p.set("date_from", msg.dateFrom);
            if (msg.dateTo)    p.set("date_to", msg.dateTo);
            const url = `${apiBase(settings)}/transcripts?${p.toString()}`;
            const resp = await fetch(url, {
              headers: { "X-API-Key": settings.apiKey, "X-Plugin-Version": PLUGIN_VERSION },
            });
            if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
            const data = await resp.json();
            return sendResponse({ ok: true, items: data.items || [] });
          } catch (e) {
            return sendResponse({ ok: false, error: String(e?.message || e) });
          }
        }
        case "list-library-channels": {
          const { settings } = await getState();
          if (!settings.apiUrl || !settings.apiKey) {
            return sendResponse({ ok: false, error: "not configured" });
          }
          try {
            const resp = await fetch(
              apiBase(settings) + "/transcripts/channels",
              { headers: { "X-API-Key": settings.apiKey, "X-Plugin-Version": PLUGIN_VERSION } }
            );
            if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
            const data = await resp.json();
            return sendResponse({ ok: true, items: data.items || [] });
          } catch (e) {
            return sendResponse({ ok: false, error: String(e?.message || e) });
          }
        }
        case "fetch-transcript": {
          const { settings } = await getState();
          if (!settings.apiUrl || !settings.apiKey) {
            return sendResponse({ ok: false, error: "not configured" });
          }
          try {
            const resp = await fetch(
              `${apiBase(settings)}/transcripts/${encodeURIComponent(msg.video_id)}`,
              { headers: { "X-API-Key": settings.apiKey, "X-Plugin-Version": PLUGIN_VERSION } }
            );
            if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
            const item = await resp.json();
            return sendResponse({ ok: true, item });
          } catch (e) {
            return sendResponse({ ok: false, error: String(e?.message || e) });
          }
        }
        case "download-library-transcript": {
          const { settings } = await getState();
          if (!settings.apiUrl || !settings.apiKey) {
            return sendResponse({ ok: false, error: "not configured" });
          }
          try {
            const resp = await fetch(
              `${apiBase(settings)}/transcripts/${encodeURIComponent(msg.video_id)}`,
              { headers: { "X-API-Key": settings.apiKey, "X-Plugin-Version": PLUGIN_VERSION } }
            );
            if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
            const r = await resp.json();
            if (!r?.body) throw new Error("no transcript body");
            // Map API fields (snake_case) → the local item shape that
            // transcriptFilename() + withHeader() already know how to handle.
            const item = {
              videoId: r.video_id,
              url: r.url || `https://www.youtube.com/watch?v=${r.video_id}`,
              title: r.title || "",
              channel: r.channel_display_name || r.channel || "",
              channelHandle: r.channel_handle || "",
              channelDisplayName: r.channel_display_name || "",
              lang: r.lang || "",
              source: r.source || "",
              hasTimestamps: !!r.has_timestamps,
              textLen: r.char_count ?? r.body.length,
              completedAt: r.scraped_at ? Date.parse(r.scraped_at) : (r.synced_at ? Date.parse(r.synced_at) : null),
              publishedAt: r.published_at || "",
              viewCount: r.view_count ?? null,
              durationSeconds: r.duration_seconds ?? null,
            };
            await downloadIndividual([{
              filename: `${transcriptFilename(item)}.txt`,
              text: withHeader(item, r.body),
            }]);
            return sendResponse({ ok: true });
          } catch (e) {
            return sendResponse({ ok: false, error: String(e?.message || e) });
          }
        }
        case "list-cloud-queue": {
          const { settings } = await getState();
          if (!settings.apiUrl || !settings.apiKey) {
            return sendResponse({ ok: false, error: "not configured" });
          }
          try {
            // Paginate through the full cloud queue. The server caps each
            // response at 500 items; we loop until we get a short page.
            // Safety cap of 10000 rows to avoid runaway loops.
            const base = apiBase(settings) + "/queue";
            const headers = { "X-API-Key": settings.apiKey, "X-Plugin-Version": PLUGIN_VERSION };
            const extra = [];
            if (msg.statusFilter) extra.push(`status_filter=${encodeURIComponent(msg.statusFilter)}`);
            if (msg.includeFailed) extra.push("include_failed=1");
            const suffix = extra.length ? `&${extra.join("&")}` : "";
            const all = [];
            const pageSize = 500;
            let offset = 0;
            while (all.length < 10000) {
              const resp = await fetch(`${base}?limit=${pageSize}&offset=${offset}${suffix}`, { headers });
              if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
              const data = await resp.json();
              const items = data.items || [];
              all.push(...items);
              if (items.length < pageSize) break;
              offset += pageSize;
            }
            return sendResponse({ ok: true, items: all });
          } catch (e) {
            return sendResponse({ ok: false, error: String(e?.message || e) });
          }
        }
        default:
          return sendResponse({ ok: false, error: "unknown type" });
      }
    } catch (e) {
      sendResponse({ ok: false, error: String(e?.message || e) });
    }
  })();
  return true; // keep channel open for async sendResponse
});

// Wait for a tab to reach 'complete', or time out.
function waitForTabComplete(tabId, ms = 30000) {
  return new Promise((resolve) => {
    const finish = () => { chrome.tabs.onUpdated.removeListener(h); clearTimeout(t); resolve(); };
    const h = (id, info) => { if (id === tabId && info.status === "complete") finish(); };
    chrome.tabs.onUpdated.addListener(h);
    const t = setTimeout(finish, ms);
  });
}

async function extractInTab(tabId, settings) {
  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId }, world: "MAIN",
    args: [settings.lang, settings.includeTimestamps],
    func: grabTranscript,
  });
  return result || { error: "no result" };
}

// Reuse a single pinned "scraper" tab across the whole batch. ID persists in
// storage so pause/resume doesn't waste a fresh create. Caller closes it when
// the queue drains or is cleared.
async function navigateScraperTab(url) {
  const { scraperTabId } = await chrome.storage.local.get("scraperTabId");
  let tab = null;
  if (scraperTabId) {
    try { tab = await chrome.tabs.get(scraperTabId); } catch { tab = null; }
  }
  if (!tab) {
    tab = await chrome.tabs.create({ url, active: false, pinned: true });
    await chrome.storage.local.set({ scraperTabId: tab.id });
    await waitForTabComplete(tab.id);
    return tab;
  }
  const p = waitForTabComplete(tab.id, 45000);
  await chrome.tabs.update(tab.id, { url, active: false });
  await p;
  return tab;
}

async function closeScraperTab() {
  const { scraperTabId } = await chrome.storage.local.get("scraperTabId");
  if (scraperTabId) {
    try { await chrome.tabs.remove(scraperTabId); } catch {}
    await chrome.storage.local.remove("scraperTabId");
  }
}

async function processItem(item, settings) {
  const tab = await navigateScraperTab(item.url);
  await sleep(2000); // let YouTube hydrate lazy UI
  let result = await extractInTab(tab.id, settings);

  // Hidden-tab retry: transcript button sometimes lazy-renders only when
  // visible. Activate briefly, retry, then push back behind — no tab close.
  if (result?.error && /no btn|transcript/i.test(result.error)) {
    await chrome.tabs.update(tab.id, { active: true });
    await sleep(1500);
    result = await extractInTab(tab.id, settings);
    try { await chrome.tabs.update(tab.id, { active: false }); } catch {}
  }

  if (result?.error) throw new Error(result.error);
  if (!result?.text?.trim()) throw new Error("empty transcript");
  return result;
}

let looping = false;
async function runLoop() {
  if (looping) return;
  looping = true;
  try {
    while (true) {
      const { queue, settings, batch } = await getState();
      if (batch.state !== "running") break;
      let next = queue.find((q) => q.status === "pending");
      if (!next) {
        // Local queue drained. If sync is on, try to pull more work from
        // the cloud pool before giving up.
        if (settings.syncDownloadQueue && settings.apiUrl && settings.apiKey) {
          const r = await cloudQueueClaim(settings).catch(() => null);
          if (r?.claimed > 0) continue; // new items landed; loop and try again
        }
        await setState({ batch: { state: "idle", currentId: null } });
        await closeScraperTab();
        break;
      }
      next.status = "running";
      await setState({ queue, batch: { state: "running", currentId: next.id } });

      try {
        const result = await processItem(next, settings);
        await chrome.storage.local.set({ [`transcript:${next.id}`]: result.text });
        // Re-read queue: user may have removed/edited items mid-run.
        const s2 = await getState();
        const it = s2.queue.find((q) => q.id === next.id);
        if (it) {
          it.status = "done";
          it.textLen = result.text.length;
          it.completedAt = Date.now();
          if (result.title && !it.title) it.title = result.title;
          if (result.channelHandle && !it.channelHandle) it.channelHandle = result.channelHandle;
          if (result.channelDisplayName && !it.channelDisplayName) it.channelDisplayName = result.channelDisplayName;
          if (result.lang) it.lang = result.lang;
          if (result.source) it.source = result.source;
          if (result.publishDate) it.publishedAt = result.publishDate;
          if (result.viewCount != null) it.viewCount = result.viewCount;
          if (result.lengthSeconds != null) it.durationSeconds = result.lengthSeconds;
          if (result.description != null) it.description = result.description;
          if (result.category != null) it.category = result.category;
          if (Array.isArray(result.keywords)) it.keywords = result.keywords;
          if (result.channelId != null) it.channel_id = result.channelId;
          if (result.hasCaptions != null) it.has_captions = result.hasCaptions;
          if (result.publishDateTimestamp != null) it.published_at_timestamp = result.publishDateTimestamp;
          it.hasTimestamps = !!settings.includeTimestamps;
          await setState({ queue: s2.queue });

          // Sync transcript whenever the item belongs in the cloud — either
          // claimed from the pool, or locally added with queue-sync enabled,
          // or the user just wants auto-transcript-sync. The server-side
          // /transcripts/sync handler atomically cleans up any cloud queue
          // row this user owns for that video_id, so the plugin doesn't
          // need to chain a separate /queue/complete call.
          const shouldSync =
            it.source === "cloud" ||
            settings.syncDownloadQueue ||
            settings.autoSyncCloud;
          if (shouldSync && settings.apiUrl && settings.apiKey) {
            syncItems([it], settings).catch((e) =>
              console.warn("[yt-transcript] transcript sync failed:", String(e))
            );
          }
        }
      } catch (e) {
        const s2 = await getState();
        const it = s2.queue.find((q) => q.id === next.id);
        if (it) {
          it.status = "failed";
          it.error = String(e?.message || e);
          it.failCount = (it.failCount || 0) + 1;
          await setState({ queue: s2.queue });
          // Cloud-sourced failures: release the claim so another install
          // can retry. Fire-and-forget — a cloud error doesn't change the
          // local failure state.
          if (it.source === "cloud" && settings.apiUrl && settings.apiKey) {
            cloudQueueRelease(it.videoId, settings).catch(
              (err) => console.warn("[yt-transcript] /queue/release failed:", String(err))
            );
          }
        }
      }

      const s3 = await getState();
      if (s3.batch.state === "paused") {
        await setState({ batch: { state: "paused", currentId: null } });
        break;
      }
      await sleep(settings.delayMs);
    }
  } finally {
    looping = false;
  }
}

function sanitize(name) {
  return (name || "transcript").replace(/[\\/:*?"<>|]/g, "_").replace(/\s+/g, " ").slice(0, 120);
}

// Filename for one transcript: "<handle>_<title>" when channel handle is
// known, otherwise just "<title>". Each part is sanitized independently so
// a slash in the title can't collide with the separator.
function transcriptFilename(item) {
  const body = sanitize(item.title || item.videoId);
  const handle = (item.channelHandle || "").trim();
  return handle ? `${sanitize(handle)}_${body}` : body;
}

// YAML-safe double-quoted scalar: escape \ and ", wrap in quotes. Covers
// titles with colons, hashes, leading dashes, etc. without needing a YAML lib.
// Newlines are escaped as \n so multi-line values (e.g. description) remain
// valid double-quoted scalars.
function yamlStr(v) {
  const s = String(v == null ? "" : v)
    .replace(/\\/g, "\\\\")
    .replace(/"/g, '\\"')
    .replace(/\r\n/g, "\\n")
    .replace(/\n/g, "\\n")
    .replace(/\r/g, "\\n");
  return `"${s}"`;
}

// ---------- channel watchlist ---------------------------------------------

// Normalize any pasted form into a canonical channel URL we can open and
// scrape. Accepts @handle, youtube.com/@handle, /channel/UC..., /c/name,
// /user/name. Returns null if unrecognizable.
function normalizeChannelUrl(raw) {
  const s = (raw || "").trim();
  if (!s) return null;
  if (s.startsWith("@")) return `https://www.youtube.com/${s}`;
  if (/^UC[\w-]{10,}/.test(s)) return `https://www.youtube.com/channel/${s}`;
  try {
    const u = new URL(s.includes("://") ? s : `https://${s}`);
    if (!/youtube\.com$/.test(u.hostname.replace(/^www\./, "").replace(/^m\./, ""))) return null;
    const m = u.pathname.match(/^\/(@[^/]+|channel\/[^/]+|c\/[^/]+|user\/[^/]+)/);
    return m ? `https://www.youtube.com${m[0]}` : null;
  } catch { return null; }
}

async function addWatchedChannel(meta) {
  const r = await postWatchlistAdd(meta);
  return r.deduped
    ? { deduped: true, handle: meta.handle, displayName: meta.title }
    : { added: 1, handle: meta.handle, displayName: meta.title };
}

// YouTube's public RSS feed — last ~15 videos per channel, single request,
// no auth, no throttling risk. Regex-parsed because DOMParser isn't in SW.
async function fetchChannelRssVideos(channelId) {
  const resp = await fetch(`https://www.youtube.com/feeds/videos.xml?channel_id=${channelId}`);
  if (!resp.ok) throw new Error(`RSS HTTP ${resp.status}`);
  const xml = await resp.text();
  const videos = [];
  for (const m of xml.matchAll(/<entry>([\s\S]*?)<\/entry>/g)) {
    const block = m[1];
    const videoId = block.match(/<yt:videoId>([^<]+)<\/yt:videoId>/)?.[1];
    if (!videoId) continue;
    const title = decodeRssEntities(block.match(/<title>([^<]*)<\/title>/)?.[1] || "");
    const publishedAt = block.match(/<published>([^<]+)<\/published>/)?.[1] || "";
    videos.push({
      videoId, title, publishedAt,
      url: `https://www.youtube.com/watch?v=${videoId}`,
    });
  }
  return videos;  // newest first, per Atom ordering
}

function decodeRssEntities(s) {
  return s
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&apos;/g, "'");
}

// Walk every watched channel, diff RSS vs queue, enqueue net-new videos.
// Returns counts + per-channel errors so the UI can surface problems.
// Watchlist itself lives in the cloud — we fetch fresh each time so
// concurrent additions on other users show up.
async function checkWatchlist() {
  const channels = await getWatchlist({ forceRefresh: true });
  if (!channels.length) return { added: 0, checked: 0, errors: [] };

  const { queue, settings } = await getState();
  const existing = new Set(queue.map((q) => q.videoId));
  const errors = [];
  const newItems = [];

  for (const ch of channels) {
    try {
      const vids = await fetchChannelRssVideos(ch.channelId);
      for (const v of vids) {
        if (existing.has(v.videoId)) continue;
        const it = {
          id: `${v.videoId}-${Date.now()}-${newItems.length}`,
          videoId: v.videoId,
          url: v.url,
          title: v.title || "",
          channel: ch.displayName || "",
          channelHandle: ch.handle || "",
          channelDisplayName: ch.displayName || "",
          status: "pending",
          addedAt: Date.now(),
          fromWatchlist: ch.handle || ch.channelId,
        };
        queue.push(it);
        newItems.push(it);
        existing.add(v.videoId);
      }
    } catch (e) {
      errors.push({ handle: ch.handle || ch.channelId, error: String(e?.message || e) });
    }
  }

  await setState({ queue });
  // Batch cloud push — single POST for all RSS-discovered videos.
  let cloud = null;
  if (newItems.length && settings.syncDownloadQueue && settings.apiUrl && settings.apiKey) {
    try {
      cloud = await pushToCloudQueue(newItems, settings);
    } catch (e) {
      console.warn("[yt-transcript] watchlist cloud push failed:", String(e));
      cloud = { error: String(e.message || e) };
    }
  }
  return { added: newItems.length, checked: channels.length, errors, cloud };
}

// ---------- cloud sync ----------------------------------------------------

// Forward the full ISO publish string to the API. Accepts either a plain
// "YYYY-MM-DD" (older plugins / legacy queue entries — BQ coerces these to
// midnight UTC on INSERT into a TIMESTAMP column) or a full
// "YYYY-MM-DDTHH:MM:SSZZ". Returns null for anything else.
function toIsoOrNull(v) {
  if (!v) return null;
  const s = String(v);
  return /^\d{4}-\d{2}-\d{2}/.test(s) ? s : null;
}

// Derive the YYYY-MM-DD that goes into the saved .txt frontmatter. Keeps the
// downloaded header format stable even though the wire value is now a full
// ISO timestamp. Silently drops unparseable inputs.
function toFrontmatterDate(v) {
  if (!v) return "";
  try {
    const d = new Date(v);
    if (Number.isNaN(d.getTime())) return "";
    return d.toISOString().slice(0, 10);
  } catch {
    return "";
  }
}

// ---------- cloud work queue (shared pool) --------------------------------

// Convert a local queue item into the API's /queue/add payload shape.
// `channel` stays populated (prefers display name, falls back to handle) so
// older server deploys still work during rollout; new deploys read the
// separated fields.
function toQueuePayload(item) {
  return {
    video_id: item.videoId,
    title: item.title || "",
    url: item.url || (item.videoId ? `https://www.youtube.com/watch?v=${item.videoId}` : ""),
    channel: item.channelDisplayName || item.channelHandle || item.channel || null,
    channel_handle: item.channelHandle || null,
    channel_display_name: item.channelDisplayName || null,
    from_watchlist: item.fromWatchlist || null,
  };
}

// POST a batch of newly-added items to the shared cloud queue. Called
// fire-and-forget from every local add path when settings.syncDownloadQueue
// is on. Failures are logged but never block the local add from succeeding.
async function pushToCloudQueue(items, settings) {
  if (!settings.apiUrl || !settings.apiKey) throw new Error("Cloud not configured");
  if (!items.length) return { added: 0, deduped: 0 };
  const url = apiBase(settings) + "/queue/add";
  const resp = await fetch(url, {
    method: "POST",
    headers: authHeaders(settings),
    body: JSON.stringify(items.map(toQueuePayload)),
  });
  if (!resp.ok) {
    const body = await resp.text().catch(() => "");
    throw new Error(`HTTP ${resp.status}: ${body.slice(0, 200) || resp.statusText}`);
  }
  return await resp.json();
}

// Fire-and-forget wrapper: silently swallows errors so the caller's success
// path is never blocked by a cloud-queue hiccup.
function maybePushToCloudQueue(items, settings) {
  if (!settings?.syncDownloadQueue) return;
  if (!settings.apiUrl || !settings.apiKey) return;
  if (!items?.length) return;
  pushToCloudQueue(items, settings).catch((e) => {
    console.warn("[yt-transcript] cloud queue push failed:", String(e));
  });
}

// One-shot sync triggered when the user toggles "Auto sync transcripts
// to cloud" ON. Pushes every currently-unsynced done transcript to the
// cloud API using the existing batch sync path. Sets a storage flag so
// the popup can render a spinner next to the checkbox.
async function backfillUnsyncedTranscripts(settings) {
  const { queue } = await getState();
  const unsynced = queue.filter((q) => q.status === "done" && !q.syncedAt);
  if (!unsynced.length) return;
  await chrome.storage.local.set({ transcriptBackfillInProgress: true });
  try {
    const n = await syncItems(unsynced, settings);
    console.log(`[yt-transcript] auto-sync backfill: ${n} transcripts pushed`);
  } catch (e) {
    console.warn("[yt-transcript] auto-sync backfill failed:", String(e));
  } finally {
    await chrome.storage.local.set({ transcriptBackfillInProgress: false });
  }
}

// One-shot backfill triggered when the user toggles "Sync download queue
// with cloud" ON. Pushes every currently-pending local item to the pool.
async function backfillPendingToCloud(settings) {
  const { queue } = await getState();
  const pending = queue.filter((q) => q.status === "pending");
  if (!pending.length) return;
  // Signal in-flight to any open popup so it can render a spinner next to
  // the "Sync download queue with cloud" checkbox. Cleared in `finally`.
  await chrome.storage.local.set({ cloudQueueBackfillInProgress: true });
  try {
    const r = await pushToCloudQueue(pending, settings);
    console.log(`[yt-transcript] cloud backfill: ${r.added} added, ${r.deduped} deduped`);
  } catch (e) {
    console.warn("[yt-transcript] cloud backfill failed:", String(e));
  } finally {
    await chrome.storage.local.set({ cloudQueueBackfillInProgress: false });
  }
}

// Claim policy:
//   - refill when local (pending + running) drops below REFILL_BELOW
//   - pull CLAIM_BATCH items on each refill
const CLOUD_REFILL_BELOW = 6;
const CLOUD_CLAIM_BATCH = 25;

// Rate-limit: prevent concurrent /queue/claim storms from overlapping triggers
// (popup poll + batch start + runLoop drain all firing at once).
let _claimInFlight = false;

// Atomically claim up to (threshold − current pending/running) items from
// the cloud pool, inject into local queue tagged source:"cloud". Returns
// a summary for logging/UI feedback. No-op and returns {claimed: 0} if:
//   - sync disabled, creds missing, another claim already running, or
//   - local queue has no room.
async function cloudQueueClaim(settings) {
  if (!settings?.syncDownloadQueue) return { claimed: 0, skipped: "disabled" };
  if (!settings.apiUrl || !settings.apiKey) return { claimed: 0, skipped: "no-creds" };
  if (_claimInFlight) return { claimed: 0, skipped: "in-flight" };
  _claimInFlight = true;
  try {
    const { queue } = await getState();
    const active = queue.filter((q) => q.status === "pending" || q.status === "running").length;
    if (active >= CLOUD_REFILL_BELOW) return { claimed: 0, skipped: "full" };
    const want = CLOUD_CLAIM_BATCH;

    const url = apiBase(settings) + "/queue/claim";
    const resp = await fetch(url, {
      method: "POST",
      headers: authHeaders(settings),
      body: JSON.stringify({ limit: want }),
    });
    if (!resp.ok) {
      const body = await resp.text().catch(() => "");
      throw new Error(`HTTP ${resp.status}: ${body.slice(0, 200) || resp.statusText}`);
    }
    const data = await resp.json();
    if (!data.claimed) return { claimed: 0 };

    // Re-read queue to avoid races with other writers; dedup by videoId.
    const { queue: latest } = await getState();
    const seen = new Set(latest.map((q) => q.videoId));
    let injected = 0;
    for (const row of data.items) {
      if (seen.has(row.video_id)) continue;
      seen.add(row.video_id);
      latest.push({
        id: `${row.video_id}-${Date.now()}-${injected}`,
        videoId: row.video_id,
        url: row.url,
        title: row.title || "",
        channel: row.channel_display_name || row.channel_handle || row.channel || "",
        channelHandle: row.channel_handle || "",
        channelDisplayName: row.channel_display_name || "",
        status: "pending",
        addedAt: Date.now(),
        fromWatchlist: row.from_watchlist || undefined,
        source: "cloud",
        // Privacy: never store or display who added this — audit-only.
        cloudClaimedAt: Date.now(),
      });
      injected++;
    }
    await setState({ queue: latest });
    return { claimed: injected };
  } finally {
    _claimInFlight = false;
  }
}

async function cloudQueuePost(settings, path, body) {
  if (!settings.apiUrl || !settings.apiKey) throw new Error("Cloud not configured");
  const resp = await fetch(apiBase(settings) + path, {
    method: "POST",
    headers: authHeaders(settings),
    body: JSON.stringify(body),
  });
  if (!resp.ok) {
    const t = await resp.text().catch(() => "");
    throw new Error(`HTTP ${resp.status}: ${t.slice(0, 200) || resp.statusText}`);
  }
  return resp.json();
}

const cloudQueueComplete = (videoId, settings) =>
  cloudQueuePost(settings, "/queue/complete", { video_id: videoId });
const cloudQueueRelease = (videoId, settings) =>
  cloudQueuePost(settings, "/queue/release", { video_id: videoId });

async function cloudQueueStats(settings) {
  if (!settings.apiUrl || !settings.apiKey) return null;
  const resp = await fetch(apiBase(settings) + "/queue/stats", {
    headers: { "X-API-Key": settings.apiKey, "X-Plugin-Version": PLUGIN_VERSION },
  });
  if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
  return resp.json();
}

// Build the JSON payload the ingestion API expects for one item. Uses the
// raw transcript text (no frontmatter) — the DB stores metadata in columns.
function toSyncPayload(item, text) {
  return {
    video_id: item.videoId,
    title: item.title || "",
    url: item.url || (item.videoId ? `https://www.youtube.com/watch?v=${item.videoId}` : ""),
    channel: item.channelDisplayName || item.channelHandle || item.channel || null,
    channel_handle: item.channelHandle || null,
    channel_display_name: item.channelDisplayName || null,
    lang: item.lang || null,
    source: item.source || null,
    scraped_at: item.completedAt ? new Date(item.completedAt).toISOString() : null,
    has_timestamps: !!item.hasTimestamps,
    char_count: item.textLen ?? text.length,
    published_at: toIsoOrNull(item.publishedAt),
    view_count: item.viewCount ?? null,
    duration_seconds: item.durationSeconds ?? null,
    description: item.description ?? null,
    category: item.category ?? null,
    keywords: Array.isArray(item.keywords) ? item.keywords : [],
    channel_id: item.channel_id ?? null,
    has_captions: item.has_captions ?? null,
    published_at_timestamp: item.published_at_timestamp ?? null,
    body: text,
  };
}

// POST a batch of done items to the ingestion API and stamp syncedAt /
// syncError on each queue entry. Returns the number of successfully synced
// items. Raises if the whole request fails (caller can show the error).
async function syncItems(items, settings) {
  if (!settings.apiUrl) throw new Error("API URL not configured");
  if (!settings.apiKey) throw new Error("API key not configured");
  if (!items.length) return 0;

  const payload = [];
  for (const it of items) {
    const text = (await chrome.storage.local.get(`transcript:${it.id}`))[`transcript:${it.id}`];
    if (!text) continue; // transcript evicted; skip
    payload.push(toSyncPayload(it, text));
  }
  if (!payload.length) throw new Error("no transcript bodies to sync");

  const url = apiBase(settings) + "/transcripts/sync";
  const resp = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-API-Key": settings.apiKey,
    },
    body: JSON.stringify(payload),
  });
  if (!resp.ok) {
    const body = await resp.text().catch(() => "");
    const err = `HTTP ${resp.status}: ${body.slice(0, 200) || resp.statusText}`;
    // Stamp the error on every queued item so the UI shows what went wrong.
    const { queue } = await getState();
    const ids = new Set(items.map((i) => i.id));
    for (const q of queue) if (ids.has(q.id)) q.syncError = err;
    await setState({ queue });
    throw new Error(err);
  }

  // Success: clear syncError, set syncedAt. Re-read queue so we don't stomp
  // on in-flight changes made while the request was out.
  const { queue } = await getState();
  const ids = new Set(items.map((i) => i.id));
  const now = Date.now();
  for (const q of queue) {
    if (!ids.has(q.id)) continue;
    q.syncedAt = now;
    q.syncError = undefined;
  }
  await setState({ queue });
  return payload.length;
}

// Prepend YAML frontmatter to the raw transcript so downstream ingestion
// (DB, RAG, etc.) can parse metadata with any standard frontmatter reader.
function withHeader(item, text) {
  const url = item.url || (item.videoId ? `https://www.youtube.com/watch?v=${item.videoId}` : "");
  const scrapedAt = item.completedAt ? new Date(item.completedAt).toISOString() : "";
  // Raw (unquoted) fields are booleans and integers; quoted fields are strings.
  const rawKeys = new Set(["has_timestamps", "char_count", "view_count", "duration_seconds"]);
  const fields = [
    ["title", item.title || ""],
    ["url", url],
    ["video_id", item.videoId || ""],
    ["channel", item.channelDisplayName || item.channelHandle || item.channel || ""],
    ["channel_handle", item.channelHandle || ""],
    ["channel_display_name", item.channelDisplayName || ""],
    ["lang", item.lang || ""],
    ["source", item.source || ""],
    ["published_at", toFrontmatterDate(item.publishedAt)],
    ["scraped_at", scrapedAt],
    ["has_timestamps", item.hasTimestamps ? "true" : "false"],
    ["char_count", String(item.textLen ?? text.length)],
    ["view_count", item.viewCount != null ? String(item.viewCount) : "null"],
    ["duration_seconds", item.durationSeconds != null ? String(item.durationSeconds) : "null"],
    ["category", item.category || ""],
    ["keywords", Array.isArray(item.keywords) ? item.keywords.join(", ") : ""],
    ["description", item.description || ""],
    ["channel_id", item.channel_id || ""],
    ["has_captions", item.has_captions == null ? "" : (item.has_captions ? "true" : "false")],
    ["published_at_timestamp", item.published_at_timestamp || ""],
  ];
  const body = fields
    .map(([k, v]) => `${k}: ${rawKeys.has(k) ? v : yamlStr(v)}`)
    .join("\n");
  return `---\n${body}\n---\n\n${text}`;
}
