// Extension-page viewer that replaces the raw XML at
// https://www.youtube.com/feeds/videos.xml?channel_id=... with a formatted
// list of videos (thumbnail, title, date, views, likes, description).
//
// Opened as chrome-extension://<id>/feed-viewer.html?channel_id=UC...
// (the Channel Watchlist rows link here via the 📄 button).

(async function main() {
  const els = {
    title: document.getElementById("fv-title"),
    channel: document.getElementById("fv-channel"),
    count: document.getElementById("fv-count"),
    status: document.getElementById("fv-status"),
    list: document.getElementById("fv-list"),
  };

  const params = new URLSearchParams(location.search);
  const channelId = (params.get("channel_id") || "").trim();
  if (!channelId) {
    setError("Missing ?channel_id=… in the URL");
    return;
  }

  document.title = `Feed — ${channelId}`;
  els.status.textContent = "Loading feed…";

  const feedUrl = `https://www.youtube.com/feeds/videos.xml?channel_id=${encodeURIComponent(channelId)}`;
  let xml;
  try {
    const resp = await fetch(feedUrl);
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
    xml = await resp.text();
  } catch (e) {
    setError(`Fetch failed — ${e.message || e}`);
    return;
  }

  let doc;
  try {
    doc = new DOMParser().parseFromString(xml, "text/xml");
    if (doc.querySelector("parsererror")) throw new Error("XML parse error");
  } catch (e) {
    setError(`Parse failed — ${e.message || e}`);
    return;
  }

  const feedTitle =
    doc.querySelector("feed > title")?.textContent?.trim() ||
    `Channel ${channelId}`;
  const feedAuthor =
    doc.querySelector("feed > author > name")?.textContent?.trim() || "";
  const feedLink =
    doc.querySelector('feed > link[rel="alternate"]')?.getAttribute("href") ||
    `https://www.youtube.com/channel/${channelId}`;

  els.title.textContent = feedTitle;
  document.title = `Feed — ${feedTitle}`;
  els.channel.textContent = feedAuthor || feedTitle;
  els.channel.href = feedLink;

  const entries = Array.from(doc.querySelectorAll("feed > entry"));
  els.count.textContent = `${entries.length} video${entries.length === 1 ? "" : "s"}`;
  els.status.textContent = "";

  if (!entries.length) {
    setError("Feed is empty");
    return;
  }

  for (const entry of entries) {
    els.list.appendChild(renderEntry(entry));
  }

  function renderEntry(entry) {
    const videoId = firstText(entry, "*", "videoId");
    const title = firstText(entry, null, "title");
    const published = firstText(entry, null, "published");
    const link =
      entry.querySelector('link[rel="alternate"]')?.getAttribute("href") ||
      (videoId ? `https://www.youtube.com/watch?v=${videoId}` : "");

    // media:group contents — thumbnail, description, statistics, starRating
    const group = entry.getElementsByTagNameNS("*", "group")[0] || entry;
    const thumbUrl =
      group.getElementsByTagNameNS("*", "thumbnail")[0]?.getAttribute("url") ||
      (videoId ? `https://i.ytimg.com/vi/${videoId}/mqdefault.jpg` : "");
    const description = firstText(group, "*", "description");
    const views =
      group.getElementsByTagNameNS("*", "statistics")[0]?.getAttribute("views") || "";
    const starCount =
      group.getElementsByTagNameNS("*", "starRating")[0]?.getAttribute("count") || "";
    const starAvg =
      group.getElementsByTagNameNS("*", "starRating")[0]?.getAttribute("average") || "";

    const item = document.createElement("article");
    item.className = "fv-item";

    const thumb = document.createElement("a");
    thumb.className = "fv-thumb";
    thumb.href = link;
    thumb.target = "_blank";
    thumb.rel = "noopener";
    const img = document.createElement("img");
    img.src = thumbUrl;
    img.alt = "";
    img.loading = "lazy";
    thumb.appendChild(img);

    const body = document.createElement("div");
    body.className = "fv-body";

    const titleEl = document.createElement("a");
    titleEl.className = "fv-title";
    titleEl.href = link;
    titleEl.target = "_blank";
    titleEl.rel = "noopener";
    titleEl.textContent = title;

    const meta = document.createElement("div");
    meta.className = "fv-meta";
    const metaBits = [];
    if (published) metaBits.push(formatDate(published));
    if (views) metaBits.push(`${formatInt(views)} views`);
    if (starCount) metaBits.push(`${formatInt(starCount)} likes`);
    if (starAvg) metaBits.push(`${Number(starAvg).toFixed(2)}★`);
    meta.textContent = metaBits.join(" · ");

    body.appendChild(titleEl);
    body.appendChild(meta);

    if (description) {
      const desc = document.createElement("p");
      desc.className = "fv-desc";
      desc.textContent = description;
      body.appendChild(desc);
    }

    if (videoId) {
      const idLine = document.createElement("div");
      idLine.className = "fv-id";
      idLine.textContent = videoId;
      body.appendChild(idLine);
    }

    item.appendChild(thumb);
    item.appendChild(body);
    return item;
  }

  function firstText(root, ns, tag) {
    if (!root) return "";
    if (ns) {
      const n = root.getElementsByTagNameNS(ns, tag)[0];
      return (n?.textContent || "").trim();
    }
    const n = root.querySelector(tag);
    return (n?.textContent || "").trim();
  }

  function formatDate(iso) {
    const d = new Date(iso);
    if (isNaN(d.getTime())) return iso;
    return d.toLocaleDateString(undefined, {
      year: "numeric", month: "short", day: "numeric",
    });
  }

  function formatInt(s) {
    const n = parseInt(s, 10);
    return isNaN(n) ? s : n.toLocaleString();
  }

  function setError(msg) {
    els.status.textContent = msg;
    els.status.classList.add("err");
  }
})();
