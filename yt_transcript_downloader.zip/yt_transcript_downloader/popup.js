// New message type added to protocol (coordinate with Worker A):
//   {type:'scrape-and-add-channel', tabId}
// SW injects scrapers.js, invokes grabChannelVideos(), dedupes, enqueues.

const WATCH_RE = /youtube\.com\/watch\?v=/;
const CHANNEL_RE = /youtube\.com\/(@[^/]+|channel\/[^/]+|c\/[^/]+|user\/[^/]+)(\/videos)?\/?/;
const VIDEO_ID_RE = /^[A-Za-z0-9_-]{11}$/;

function parseVideoId(input) {
  const s = (input || "").trim();
  if (!s) return null;
  if (VIDEO_ID_RE.test(s)) return s;
  let u;
  try {
    u = new URL(s.includes("://") ? s : `https://${s}`);
  } catch {
    return null;
  }
  const host = u.hostname.replace(/^www\./, "");
  if (host === "youtu.be") {
    const id = u.pathname.slice(1).split("/")[0];
    return VIDEO_ID_RE.test(id) ? id : null;
  }
  if (host === "youtube.com" || host === "m.youtube.com") {
    if (u.pathname === "/watch") {
      const id = u.searchParams.get("v");
      return id && VIDEO_ID_RE.test(id) ? id : null;
    }
    const m = u.pathname.match(/^\/(?:shorts|embed|v|live)\/([^/]+)/);
    if (m && VIDEO_ID_RE.test(m[1])) return m[1];
  }
  return null;
}

const els = {
  detach: document.getElementById("detach"),
  addVideo: document.getElementById("add-video"),
  addChannel: document.getElementById("add-channel"),
  addUrl: document.getElementById("add-url"),
  addUrlBtn: document.getElementById("add-url-btn"),
  addStatus: document.getElementById("add-status"),
  stopScrape: document.getElementById("stop-scrape"),
  tabActive: document.getElementById("tab-active"),
  tabUnsynced: document.getElementById("tab-unsynced"),
  tabFailed: document.getElementById("tab-failed"),
  tabCloud: document.getElementById("tab-cloud"),
  queueHeader: document.getElementById("queue-header"),
  refreshCloud: document.getElementById("refresh-cloud"),
  queueSearch: document.getElementById("queue-search"),
  queueSearchWrap: document.getElementById("queue-search-wrap"),
  queueSearchCount: document.getElementById("queue-search-count"),
  syncStatus: document.getElementById("sync-status"),
  hideCompleted: document.getElementById("hide-completed"),
  hideCompletedRow: document.getElementById("hide-completed-row"),
  queueList: document.getElementById("queue-list"),
  start: document.getElementById("start"),
  tabAction: document.getElementById("tab-action"),
  clear: document.getElementById("clear"),
  downloadZip: document.getElementById("download-zip"),
  overflowToggle: document.getElementById("overflow-toggle"),
  overflowMenu: document.getElementById("overflow-menu"),
  menuRetryFailed: document.getElementById("menu-retry-failed"),
  lang: document.getElementById("lang"),
  timestamps: document.getElementById("timestamps"),
  delay: document.getElementById("delay"),
  delayVal: document.getElementById("delay-val"),
  showOverlay: document.getElementById("show-overlay"),
  apiUrl: document.getElementById("api-url"),
  apiKey: document.getElementById("api-key"),
  autoSync: document.getElementById("auto-sync"),
  syncDownloadQueue: document.getElementById("sync-download-queue"),
  watchCurrent: document.getElementById("watch-current"),
  watchlist: document.getElementById("watchlist"),
  watchlistStatus: document.getElementById("watchlist-status"),
  checkWatchlist: document.getElementById("check-watchlist"),
  refreshWatchlist: document.getElementById("refresh-watchlist"),
  settingsTabGeneral: document.getElementById("settings-tab-general"),
  settingsTabCloud: document.getElementById("settings-tab-cloud"),
  settingsPanelGeneral: document.getElementById("settings-panel-general"),
  settingsPanelCloud: document.getElementById("settings-panel-cloud"),
  syncDlSpinner: document.getElementById("sync-dl-spinner"),
  autoSyncSpinner: document.getElementById("auto-sync-spinner"),
  librarySearch: document.getElementById("library-search"),
  librarySearchCount: document.getElementById("library-search-count"),
  libraryChannel: document.getElementById("library-channel"),
  librarySort: document.getElementById("library-sort"),
  libraryDateFrom: document.getElementById("library-date-from"),
  libraryDateTo: document.getElementById("library-date-to"),
  libraryHeader: document.getElementById("library-header"),
  libraryList: document.getElementById("library-list"),
  libraryMore: document.getElementById("library-more"),
  refreshLibrary: document.getElementById("refresh-library"),
  adminQueueSearch: document.getElementById("admin-queue-search"),
  adminQueueSearchCount: document.getElementById("admin-queue-search-count"),
  adminQueueHeader: document.getElementById("admin-queue-header"),
  adminQueueList: document.getElementById("admin-queue-list"),
  adminDeleteFiltered: document.getElementById("admin-delete-filtered"),
  adminQueueStatus: document.getElementById("admin-queue-status"),
  refreshAdminQueue: document.getElementById("refresh-admin-queue"),
  adminFailedSearch: document.getElementById("admin-failed-search"),
  adminFailedSearchCount: document.getElementById("admin-failed-search-count"),
  adminFailedHeader: document.getElementById("admin-failed-header"),
  adminFailedList: document.getElementById("admin-failed-list"),
  adminDeleteFailedFiltered: document.getElementById("admin-delete-failed-filtered"),
  adminFailedStatus: document.getElementById("admin-failed-status"),
  refreshAdminFailed: document.getElementById("refresh-admin-failed"),
  adminSubtabQueue: document.getElementById("admin-subtab-queue"),
  adminSubtabAutoupdate: document.getElementById("admin-subtab-autoupdate"),
  adminSubtabYtapi: document.getElementById("admin-subtab-ytapi"),
  adminSubpanelQueue: document.getElementById("admin-subpanel-queue"),
  adminSubpanelAutoupdate: document.getElementById("admin-subpanel-autoupdate"),
  adminSubpanelYtapi: document.getElementById("admin-subpanel-ytapi"),
  autoupdateChannel: document.getElementById("autoupdate-channel"),
  autoupdateLimit: document.getElementById("autoupdate-limit"),
  autoupdateRun: document.getElementById("autoupdate-run"),
  autoupdateRefreshChannels: document.getElementById("autoupdate-refresh-channels"),
  autoupdateHeader: document.getElementById("autoupdate-header"),
  autoupdateList: document.getElementById("autoupdate-list"),
  autoupdateQueueAll: document.getElementById("autoupdate-queue-all"),
  autoupdateStatus: document.getElementById("autoupdate-status"),
  ytapiRefresh: document.getElementById("ytapi-refresh"),
  ytapiUsed: document.getElementById("ytapi-used"),
  ytapiRemaining: document.getElementById("ytapi-remaining"),
  ytapiQuota: document.getElementById("ytapi-quota"),
  ytapiBar: document.getElementById("ytapi-bar"),
  ytapiWindow: document.getElementById("ytapi-window"),
  ytapiStatus: document.getElementById("ytapi-status"),
  topTabTranscripts: document.getElementById("top-tab-transcripts"),
  topTabWatched: document.getElementById("top-tab-watched"),
  topTabLibrary: document.getElementById("top-tab-library"),
  topTabAdmin: document.getElementById("top-tab-admin"),
  topTabSettings: document.getElementById("top-tab-settings"),
  topPanelTranscripts: document.getElementById("top-panel-transcripts"),
  topPanelWatched: document.getElementById("top-panel-watched"),
  topPanelLibrary: document.getElementById("top-panel-library"),
  topPanelAdmin: document.getElementById("top-panel-admin"),
  topPanelSettings: document.getElementById("top-panel-settings"),
  detailModal: document.getElementById("detail-modal"),
  detailTitle: document.getElementById("detail-title"),
  detailBody: document.getElementById("detail-body"),
  detailClose: document.getElementById("detail-close"),
};

let watchlist = [];
let cloudStats = null;   // {available, claimed, total} or null; updated by claim-poll
let syncAllInFlight = false;

let state = { queue: [], settings: defaultSettings(), batch: { state: "idle", currentId: null } };
let activeTab = null;
let renderPending = false;
let currentTab = "active"; // "active" | "unsynced" | "failed" | "cloud"
let cloudItems = null;     // cached items from GET /queue when on Cloud tab
let cloudLastFetch = 0;

function defaultSettings() {
  return {
    lang: "en",
    includeTimestamps: false,
    downloadMode: "individual",
    delayMs: 4000,
    apiUrl: "",
    apiKey: "",
    autoSyncCloud: false,
    syncDownloadQueue: false,
  };
}

function send(msg) {
  return chrome.runtime.sendMessage(msg).catch((e) => console.warn("sendMessage", msg, e));
}

async function init() {
  const stored = await chrome.storage.local.get(["queue", "settings", "batch", "uiHidden", "hideCompleted", "cloudQueueBackfillInProgress", "transcriptBackfillInProgress"]);
  state.queue = stored.queue || [];
  state.settings = { ...defaultSettings(), ...(stored.settings || {}) };
  state.batch = stored.batch || { state: "idle", currentId: null };
  applyBackfillSpinner(!!stored.cloudQueueBackfillInProgress);
  applyAutoSyncSpinner(!!stored.transcriptBackfillInProgress);
  els.showOverlay.checked = !stored.uiHidden;
  els.hideCompleted.checked = !!stored.hideCompleted;
  applySettingsToUi();

  // The pin button only makes sense in the transient toolbar popup —
  // hide it when we're already running inside the side panel.
  const inPanel = new URLSearchParams(location.search).get("panel") === "1";
  if (inPanel) els.detach.classList.add("hidden");

  await refreshActiveTab();
  syncCloudPollToBatch();  // pick up any batch that was already running
  scheduleRender();

  // Keep activeTab in sync when the user switches tabs in the main window,
  // since this UI may live in a detached popup window.
  chrome.tabs.onActivated.addListener(refreshActiveTab);
  chrome.tabs.onUpdated.addListener((_id, info) => { if (info.url) refreshActiveTab(); });
  chrome.windows.onFocusChanged.addListener(refreshActiveTab);

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes.queue) state.queue = changes.queue.newValue || [];
    if (changes.settings) state.settings = { ...defaultSettings(), ...(changes.settings.newValue || {}) };
    if (changes.batch) {
      state.batch = changes.batch.newValue || { state: "idle", currentId: null };
      syncCloudPollToBatch();  // start/stop 30s poll when batch starts/stops
    }
    if (changes.uiHidden) els.showOverlay.checked = !changes.uiHidden.newValue;
    if (changes.hideCompleted) els.hideCompleted.checked = !!changes.hideCompleted.newValue;
    if (changes.cloudQueueBackfillInProgress) {
      applyBackfillSpinner(!!changes.cloudQueueBackfillInProgress.newValue);
    }
    if (changes.transcriptBackfillInProgress) {
      applyAutoSyncSpinner(!!changes.transcriptBackfillInProgress.newValue);
    }
    if (changes.settings) {
      applySettingsToUi();
      refreshAdminVisibility();  // re-check whoami when apiKey/apiUrl change
    }
    scheduleRender();
  });
}

function applyBackfillSpinner(on) {
  els.syncDlSpinner.classList.toggle("hidden", !on);
}

function applyAutoSyncSpinner(on) {
  els.autoSyncSpinner.classList.toggle("hidden", !on);
}

function updateAddButtons() {
  const url = activeTab?.url || "";
  els.addVideo.disabled = !WATCH_RE.test(url);
  els.addChannel.disabled = !CHANNEL_RE.test(url);
  els.watchCurrent.disabled = !CHANNEL_RE.test(url);
}

async function refreshActiveTab() {
  // Prefer the active tab in the CURRENT window (the one hosting this
  // popup / side panel) over any-window scans — otherwise with multiple
  // Chrome windows open we'd pick an arbitrary one and the add-channel
  // button would stay disabled when the user is actually on a channel page.
  let tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  let tab = tabs.find((t) => t.url && !t.url.startsWith(chrome.runtime.getURL("")));
  if (!tab) {
    // Fallback: last-focused normal window (handles the case where the
    // popup itself is the "current" window, e.g. side panel opened from
    // a non-browser context).
    tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    tab = tabs.find((t) => t.url && !t.url.startsWith(chrome.runtime.getURL("")));
  }
  activeTab = tab || null;
  updateAddButtons();
}

function applySettingsToUi() {
  const s = state.settings;
  els.lang.value = s.lang ?? "en";
  els.timestamps.checked = !!s.includeTimestamps;
  const secs = Math.max(2, Math.min(20, Math.round((s.delayMs ?? 4000) / 1000)));
  els.delay.value = String(secs);
  els.delayVal.textContent = String(secs);
  els.apiUrl.value = s.apiUrl ?? "";
  els.apiKey.value = s.apiKey ?? "";
  els.autoSync.checked = !!s.autoSyncCloud;
  els.syncDownloadQueue.checked = !!s.syncDownloadQueue;
}

function scheduleRender() {
  if (renderPending) return;
  renderPending = true;
  setTimeout(() => { renderPending = false; render(); }, 80);
}

function counts() {
  const c = { pending: 0, running: 0, done: 0, failed: 0, skipped: 0 };
  for (const it of state.queue) if (c[it.status] != null) c[it.status]++;
  return c;
}

function render() {
  const c = counts();
  const unsyncedCount = state.queue.filter(
    (it) => it.status === "done" && !it.syncedAt
  ).length;

  // Tab chrome: reflect which tab is selected + label counts (Bootstrap
  // nav-tabs uses `.active` on the `.nav-link`).
  els.tabActive.classList.toggle("active", currentTab === "active");
  els.tabUnsynced.classList.toggle("active", currentTab === "unsynced");
  els.tabFailed.classList.toggle("active", currentTab === "failed");
  els.tabCloud.classList.toggle("active", currentTab === "cloud");
  els.tabActive.textContent = "Active";
  els.tabUnsynced.textContent = unsyncedCount > 0 ? `Unsynced (${unsyncedCount})` : "Unsynced";
  els.tabFailed.textContent = c.failed > 0 ? `Failed (${c.failed})` : "Failed";
  const cloudTotal = cloudStats?.total ?? null;
  els.tabCloud.textContent = cloudTotal != null ? `Cloud Queue (${cloudTotal})` : "Cloud Queue";

  // If user lands on Unsynced but cloud sync isn't configured, show a hint
  // in the tab via its title. (Tab itself stays visible as a navigation aid.)
  const cloudReady = !!(state.settings.apiUrl && state.settings.apiKey);
  els.tabUnsynced.title = cloudReady
    ? "Transcripts done locally but not yet posted to the cloud API"
    : "Configure API URL + key in Settings to enable cloud sync";

  // Refresh button is only meaningful on the Cloud Queue tab. Hide by
  // default; the cloud branch re-shows it below.
  els.refreshCloud.classList.add("hidden");
  // Search field shows on Active and Cloud Queue tabs (the two list views).
  // Wrapper is what we hide so the absolutely-positioned count badge
  // disappears with it.
  const searchable = currentTab === "active" || currentTab === "cloud";
  els.queueSearchWrap.classList.toggle("hidden", !searchable);

  // Header + list contents depend on the selected tab.
  els.queueList.innerHTML = "";
  let visible;
  if (currentTab === "failed") {
    els.hideCompletedRow.classList.add("hidden");
    visible = state.queue.filter((it) => it.status === "failed");
    els.queueHeader.textContent = visible.length
      ? `Failed: ${visible.length} item${visible.length === 1 ? "" : "s"}`
      : "Failed: none";
  } else if (currentTab === "unsynced") {
    els.hideCompletedRow.classList.add("hidden");
    visible = state.queue.filter((it) => it.status === "done" && !it.syncedAt);
    els.queueHeader.textContent = visible.length
      ? `Unsynced: ${visible.length} item${visible.length === 1 ? "" : "s"}` +
        (cloudReady ? "" : " — cloud sync not configured")
      : "Unsynced: none — all done items have been synced";
  } else if (currentTab === "cloud") {
    els.hideCompletedRow.classList.add("hidden");
    els.refreshCloud.classList.remove("hidden");
    if (!cloudReady) {
      els.queueList.innerHTML = "";
      els.queueHeader.textContent = "Cloud Queue — configure API URL + key in Settings";
      renderWatchlist();
      return;
    }
    els.queueList.innerHTML = "";
    if (!cloudItems) {
      els.queueHeader.textContent = "Cloud Queue — loading…";
      fetchCloudItems();
      renderWatchlist();
      return;
    }
    const a = cloudStats?.available ?? 0, cl = cloudStats?.claimed ?? 0;
    els.queueHeader.textContent = `Cloud Queue: ${a} available · ${cl} claimed`;
    // Apply the shared search filter to cloud rows, matching title /
    // channel / from_watchlist. Badge count is set below the main render.
    const qCloud = (els.queueSearch.value || "").trim().toLowerCase();
    const cloudVisible = qCloud
      ? cloudItems.filter((it) =>
          (it.title || "").toLowerCase().includes(qCloud)
          || (it.channel || "").toLowerCase().includes(qCloud)
          || (it.from_watchlist || "").toLowerCase().includes(qCloud)
        )
      : cloudItems;
    for (const it of cloudVisible) els.queueList.appendChild(renderCloudRow(it));
    if (qCloud) {
      els.queueSearchCount.textContent = String(cloudVisible.length);
      els.queueSearchCount.classList.remove("hidden");
    } else {
      els.queueSearchCount.classList.add("hidden");
    }
    renderWatchlist();
    return;
  } else {
    els.hideCompletedRow.classList.remove("hidden");
    const parts = [`${c.pending} pending`, `${c.running} running`, `${c.done} done`];
    if (c.skipped) parts.push(`${c.skipped} skipped`);
    if (state.settings.syncDownloadQueue && cloudStats?.available != null) {
      parts.push(`${cloudStats.available} in cloud`);
    }
    els.queueHeader.textContent = `Queue: ${parts.join(" · ")}`;
    // Match count rendered as a badge inside the search input. Counts
    // items that would actually be visible — so when "Hide completed" is
    // on, done items don't inflate the count.
    const qNow = (els.queueSearch.value || "").trim();
    if (qNow) {
      const hideDone = els.hideCompleted.checked;
      const matchCount = state.queue.filter((it) => {
        if (it.status === "failed") return false;
        if (hideDone && it.status === "done") return false;
        const needle = qNow.toLowerCase();
        return (it.title || "").toLowerCase().includes(needle)
          || (it.channel || "").toLowerCase().includes(needle)
          || (it.channelHandle || "").toLowerCase().includes(needle);
      }).length;
      els.queueSearchCount.textContent = String(matchCount);
      els.queueSearchCount.classList.remove("hidden");
    } else {
      els.queueSearchCount.classList.add("hidden");
    }

    // Active tab excludes failed items (they live in the Failed tab).
    // Sort by addedAt ascending so cloud-claimed and local-added items
    // interleave in predictable FIFO order regardless of source.
    const q = (els.queueSearch.value || "").trim().toLowerCase();
    const matchesSearch = (it) => {
      if (!q) return true;
      return (it.title || "").toLowerCase().includes(q)
        || (it.channel || "").toLowerCase().includes(q)
        || (it.channelHandle || "").toLowerCase().includes(q);
    };
    const base = state.queue
      .filter((it) => it.status !== "failed")
      .filter(matchesSearch)
      .slice()
      .sort((a, b) => (a.addedAt ?? 0) - (b.addedAt ?? 0));
    if (els.hideCompleted.checked) {
      const notDone = base.filter((it) => it.status !== "done");
      const running = notDone.filter((it) => it.status === "running");
      const rest = notDone.filter((it) => it.status !== "running");
      // When the queue is fully drained (no pending/running), drop the
      // last-done row too so the list ends up empty instead of leaving
      // a stale "just completed" item hanging around.
      if (notDone.length === 0) {
        visible = [];
      } else {
        const done = base.filter((it) => it.status === "done");
        const lastDone = done.reduce(
          (a, b) => (a && (a.completedAt ?? 0) >= (b.completedAt ?? 0) ? a : b),
          null
        );
        visible = lastDone ? [lastDone, ...running, ...rest] : [...running, ...rest];
      }
    } else {
      visible = base;
    }
  }
  for (const it of visible) els.queueList.appendChild(renderRow(it));

  const bs = state.batch.state;
  if (bs === "running") {
    els.start.textContent = "Pause";
    els.start.classList.add("paused");
    els.start.disabled = false;
  } else if (bs === "paused") {
    els.start.textContent = "Resume";
    els.start.classList.add("paused");
    els.start.disabled = false;
  } else {
    els.start.classList.remove("paused");
    const retryable = c.failed + c.skipped;
    if (c.pending > 0) {
      els.start.textContent = "Start";
      els.start.disabled = false;
      els.start.dataset.action = "start";
    } else if (retryable > 0) {
      els.start.textContent = `Retry failed / skipped (${retryable})`;
      els.start.disabled = false;
      els.start.dataset.action = "retry-all-and-start";
    } else {
      els.start.textContent = "Start";
      els.start.disabled = true;
      els.start.dataset.action = "start";
    }
  }
  els.clear.disabled = bs === "running" || state.queue.length === 0;

  // Start/Pause/Resume only makes sense on the Active tab — the other tabs
  // have their own tab-action button (Retry failed, Sync all to cloud).
  els.start.classList.toggle("hidden", currentTab !== "active");

  // Download only belongs on the Active tab. Failed has nothing downloadable;
  // Unsynced's action is to push to the cloud, not save locally.
  if (c.done > 0 && currentTab === "active") {
    els.downloadZip.classList.remove("hidden");
    els.downloadZip.textContent = `Download transcripts (${c.done})`;
  } else {
    els.downloadZip.classList.add("hidden");
  }

  // Overflow menu item: "Retry failed & resume" is only useful on the Active
  // tab (Failed tab already has it as the primary tab-action). Hide otherwise.
  const retryableCount = c.failed + c.skipped;
  if (currentTab === "active" && retryableCount > 0) {
    els.menuRetryFailed.classList.remove("hidden");
    els.menuRetryFailed.textContent = `Retry failed & resume (${retryableCount})`;
  } else {
    els.menuRetryFailed.classList.add("hidden");
  }

  // Contextual action button — its label + handler depend on the active tab.
  // Active: nothing (Start is already the primary action).
  // Failed: retry failed/skipped and resume the batch.
  // Unsynced: sync all unsynced done items to the cloud (if configured).
  const retryable = c.failed + c.skipped;
  if (currentTab === "failed") {
    els.tabAction.classList.remove("hidden");
    els.tabAction.textContent = `Retry failed & resume (${retryable})`;
    els.tabAction.disabled = retryable === 0;
    els.tabAction.dataset.action = "retry-all";
  } else if (currentTab === "unsynced" && cloudReady) {
    els.tabAction.classList.remove("hidden");
    els.tabAction.textContent = `Sync all to cloud (${unsyncedCount})`;
    // Don't re-enable the button if a sync is still in flight.
    els.tabAction.disabled = syncAllInFlight || unsyncedCount === 0;
    els.tabAction.dataset.action = "sync-all";
  } else {
    els.tabAction.classList.add("hidden");
    els.tabAction.dataset.action = "";
  }

  renderWatchlist();
}

function renderWatchlist() {
  els.watchlist.innerHTML = "";
  for (const ch of watchlist) {
    const row = document.createElement("div");
    row.className = "wrow";

    const body = document.createElement("div");
    body.className = "body";
    const name = document.createElement("span");
    name.className = "title";
    name.textContent = ch.displayName || ch.handle || ch.channelId;
    name.title = ch.url || "";
    if (ch.url) name.addEventListener("click", () => chrome.tabs.create({ url: ch.url, active: true }));
    body.appendChild(name);
    row.appendChild(body);

    const actions = document.createElement("div");
    actions.className = "actions";

    const feedBtn = document.createElement("button");
    feedBtn.className = "icon";
    feedBtn.textContent = "\u{1F4C4}";  // 📄
    feedBtn.title = "View RSS feed (formatted)";
    feedBtn.addEventListener("click", () => {
      if (!ch.channelId) return;
      const url = chrome.runtime.getURL(`feed-viewer.html?channel_id=${encodeURIComponent(ch.channelId)}`);
      chrome.tabs.create({ url, active: true });
    });
    actions.appendChild(feedBtn);

    const rm = document.createElement("button");
    rm.className = "icon";
    rm.textContent = "\u00d7";
    rm.title = "Remove from watchlist";
    rm.addEventListener("click", async () => {
      rm.disabled = true;
      const res = await send({ type: "remove-watched", channelId: ch.channelId });
      if (res?.ok) {
        await loadWatchlist({ forceRefresh: true });
      } else {
        showWatchStatus(`Remove failed: ${res?.error || "unknown"}`, true);
        rm.disabled = false;
      }
    });
    actions.appendChild(rm);
    row.appendChild(actions);

    els.watchlist.appendChild(row);
  }
  els.checkWatchlist.classList.toggle("hidden", watchlist.length === 0);
  els.checkWatchlist.textContent =
    watchlist.length === 0 ? "Check channels for new videos" : `Check ${watchlist.length} channel${watchlist.length === 1 ? "" : "s"} for new videos`;
}

// Fetch the shared watchlist from the cloud and re-render. Silent by default —
// on error, writes the message to the status line and leaves the list empty.
async function loadWatchlist({ forceRefresh = false } = {}) {
  try {
    const res = await send({ type: "list-watchlist", forceRefresh });
    if (res?.ok) {
      watchlist = res.channels || [];
      scheduleRender();
    } else {
      watchlist = [];
      const err = res?.error || "unknown error";
      els.watchlistStatus.textContent = `Couldn't load watchlist — ${err}`;
      els.watchlistStatus.style.color = "#c0392b";
      scheduleRender();
    }
  } catch (e) {
    watchlist = [];
    els.watchlistStatus.textContent = `Couldn't load watchlist — ${String(e?.message || e)}`;
    els.watchlistStatus.style.color = "#c0392b";
    scheduleRender();
  }
}

function renderRow(it) {
  const row = document.createElement("div");
  row.className = "qrow";

  const badge = document.createElement("span");
  badge.className = `badge ${it.status || "pending"}`;
  badge.title = it.status;
  row.appendChild(badge);

  const body = document.createElement("div");
  body.className = "body";
  const titleLine = document.createElement("div");
  titleLine.className = "title-line";
  const title = document.createElement("span");
  title.className = "title";
  const localChannel = it.channel || it.channelHandle || "";
  const localTitle = it.title || it.url || it.videoId || "(untitled)";
  title.textContent = localChannel ? `${localChannel}: ${localTitle}` : localTitle;
  title.title = localTitle;
  if (it.url) {
    title.addEventListener("click", () => chrome.tabs.create({ url: it.url, active: true }));
  }
  titleLine.appendChild(title);
  if (it.source === "cloud") {
    const badge = document.createElement("span");
    badge.className = "origin-badge cloud";
    badge.textContent = "cloud";
    badge.title = "Claimed from the shared cloud queue";
    titleLine.appendChild(badge);
  }
  body.appendChild(titleLine);
  // Privacy: cloud-sourced items don't display who added them. The cloud
  // badge on the title line is enough signal that this came from the pool.
  if (it.status === "failed" && it.error) {
    const err = document.createElement("div");
    err.className = "err";
    err.textContent = it.error;
    body.appendChild(err);
  }
  row.appendChild(body);

  const actions = document.createElement("div");
  actions.className = "actions";
  if (it.status !== "running") {
    const startHere = document.createElement("button");
    startHere.className = "icon";
    startHere.textContent = "\u25B6";
    startHere.title = "Continue from here";
    startHere.addEventListener("click", () => send({ type: "start-from", id: it.id }));
    actions.appendChild(startHere);
  }
  if (it.status === "done") {
    const dl = document.createElement("button");
    dl.className = "icon";
    dl.textContent = "\u2B07";
    dl.title = "Download transcript";
    dl.addEventListener("click", () => send({ type: "download-one", id: it.id }));
    actions.appendChild(dl);

    // Cloud-sync button: icon-only, shows sync state via the title tooltip.
    const sync = document.createElement("button");
    sync.className = "icon icon-sync";
    sync.textContent = "\u27F3"; // ⟳ sync (distinct from ↻ retry used on failed rows)
    if (it.syncError) {
      sync.title = `Sync failed: ${it.syncError} — click to retry`;
      sync.classList.add("err");
    } else if (it.syncedAt) {
      sync.title = `Synced ${new Date(it.syncedAt).toLocaleString()} — click to re-sync`;
      sync.classList.add("ok");
    } else {
      sync.title = "Sync this transcript to cloud";
    }
    sync.addEventListener("click", async () => {
      const res = await flushSettingsThen(() => send({ type: "sync-one", id: it.id }));
      if (res && res.error) showSyncStatus(`Sync failed: ${res.error}`, true);
      else if (res && res.ok) showSyncStatus("Synced ✓");
    });
    actions.appendChild(sync);
  }
  if (it.status === "failed") {
    const retry = document.createElement("button");
    retry.className = "icon";
    retry.textContent = "\u21bb";
    retry.title = "Retry";
    retry.addEventListener("click", () => send({ type: "retry", id: it.id }));
    actions.appendChild(retry);
  }
  const rm = document.createElement("button");
  rm.className = "icon";
  rm.textContent = "\u00d7";
  rm.title = "Remove";
  rm.addEventListener("click", () => send({ type: "remove", id: it.id }));
  actions.appendChild(rm);
  row.appendChild(actions);

  return row;
}

els.detach.addEventListener("click", async () => {
  try {
    const win = await chrome.windows.getCurrent();
    await chrome.sidePanel.open({ windowId: win.id });
  } catch (e) {
    console.warn("sidePanel.open failed", e);
  }
  window.close();
});

els.addVideo.addEventListener("click", async () => {
  els.addVideo.disabled = true;
  els.addStatus.textContent = "Adding…";
  try {
    // Pass tabId so the SW can inject grabCurrentVideoInfo into the page and
    // detect shorts by duration before enqueueing.
    const res = await send({
      type: "add-video",
      url: activeTab.url,
      title: activeTab.title,
      tabId: activeTab.id,
    });
    els.addStatus.textContent = addStatusMessage(res);
  } catch (e) {
    els.addStatus.textContent = `Error: ${e.message}`;
  } finally {
    setTimeout(() => (els.addStatus.textContent = ""), 3000);
    updateAddButtons();
  }
});

// Map an add-video response to a status line. Distinguishes:
//   - shorts blocked ("Can't add — this is a short.")
//   - local dedup ("Already in queue")
//   - newly added + cloud already had it ("Added — already in cloud queue")
//   - newly added + cloud accepted it ("Added")
//   - newly added + cloud sync off ("Added")
function addStatusMessage(res) {
  if (!res) return "Added";
  if (res.isShort) return "Can't add — this is a short.";
  if (res.deduped) return "Already in queue";
  if (res.error) return `Error: ${res.error}`;
  if (res.cloud?.deduped) return "Added — already in cloud queue";
  return "Added";
}

// Status for batch adds (Add channel's videos, Check channels for new videos).
// Reports local count + cloud breakdown from the single batch POST. Appends
// "(N shorts skipped)" when the scraper filtered any short-form videos.
function batchAddStatusMessage(addedLocal, cloud, shortsSkipped) {
  const shorts = Number(shortsSkipped) || 0;
  const shortsTail = shorts > 0
    ? ` (${shorts} short${shorts === 1 ? "" : "s"} skipped)`
    : "";
  if (addedLocal === 0) {
    return shorts > 0 ? `No new videos${shortsTail}` : "No new videos";
  }
  const word = `video${addedLocal === 1 ? "" : "s"}`;
  if (!cloud) return `Added ${addedLocal} ${word}${shortsTail}`;
  if (cloud.error) return `Added ${addedLocal} ${word}${shortsTail} (cloud push failed: ${cloud.error})`;
  const c = cloud.added ?? 0;
  const d = cloud.deduped ?? 0;
  if (d === 0) return `Added ${addedLocal} ${word}${shortsTail}`;
  if (c === 0) return `Added ${addedLocal} ${word} — all already in cloud queue${shortsTail}`;
  return `Added ${addedLocal} ${word} (${c} new in cloud, ${d} already there)${shortsTail}`;
}

els.stopScrape.addEventListener("click", async () => {
  els.stopScrape.disabled = true;
  try { await chrome.runtime.sendMessage({ type: "scrape-stop" }); } catch {}
});

els.addChannel.addEventListener("click", async () => {
  els.addChannel.disabled = true;
  els.addStatus.textContent = "Scraping channel…";
  els.stopScrape.classList.remove("hidden");
  els.stopScrape.disabled = false;
  // Poll the SW on a timer instead of subscribing to broadcasts — avoids
  // parallel executeScript calls racing with the scraper's injection.
  const progressTimer = setInterval(async () => {
    try {
      const r = await chrome.runtime.sendMessage({ type: "get-scrape-progress" });
      if (r?.count != null) {
        els.addStatus.textContent = `Scraping channel… (${r.count} video${r.count === 1 ? "" : "s"})`;
      }
    } catch {}
  }, 700);
  try {
    const res = await chrome.runtime.sendMessage({ type: "scrape-and-add-channel", tabId: activeTab.id });
    if (res?.error) throw new Error(res.error);
    els.addStatus.textContent = batchAddStatusMessage(res?.added ?? 0, res?.cloud, res?.shortsSkipped);
  } catch (e) {
    els.addStatus.textContent = `Error: ${e.message}`;
  } finally {
    clearInterval(progressTimer);
    els.stopScrape.classList.add("hidden");
    setTimeout(() => (els.addStatus.textContent = ""), 2500);
    updateAddButtons();
  }
});

els.addUrlBtn.addEventListener("click", async () => {
  const raw = els.addUrl.value;
  const id = parseVideoId(raw);
  if (!id) {
    els.addStatus.textContent = "Invalid URL or video ID.";
    return;
  }
  const url = `https://www.youtube.com/watch?v=${id}`;
  els.addUrlBtn.disabled = true;
  els.addStatus.textContent = "Adding…";
  try {
    const res = await send({ type: "add-video", url, title: "" });
    els.addStatus.textContent = addStatusMessage(res);
    // Only clear the input on a true new-add; leave it so user can see
    // what they pasted if it was a dedup.
    if (res && !res.deduped && !res.error) els.addUrl.value = "";
  } catch (e) {
    els.addStatus.textContent = `Error: ${e.message}`;
  } finally {
    els.addUrlBtn.disabled = false;
    setTimeout(() => (els.addStatus.textContent = ""), 1500);
  }
});

els.addUrl.addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    e.preventDefault();
    els.addUrlBtn.click();
  }
});

els.start.addEventListener("click", () => {
  const bs = state.batch.state;
  if (bs === "running") {
    send({ type: "pause" });
    // Pause = batch stops, but user likely wants an up-to-date cloud view
    // since they just did some work. Fire one immediate stats/claim refresh
    // — normal 30s interval is about to stop.
    pollClaimFromCloud();
  } else if (bs === "paused") {
    send({ type: "resume" });
  } else {
    send({ type: els.start.dataset.action || "start" });
  }
});

els.tabAction.addEventListener("click", async () => {
  const action = els.tabAction.dataset.action;
  if (action === "retry-all") {
    send({ type: "retry-all-and-start" });
  } else if (action === "sync-all") {
    syncAllInFlight = true;
    els.tabAction.classList.add("loading");
    els.tabAction.disabled = true;
    showSyncStatus("Syncing…");
    try {
      const res = await flushSettingsThen(() => send({ type: "sync-all" }));
      if (res && res.error) showSyncStatus(`Sync failed: ${res.error}`, true);
      else if (res) showSyncStatus(`Synced ${res.synced ?? 0} ✓`);
    } finally {
      syncAllInFlight = false;
      els.tabAction.classList.remove("loading");
      // render() will compute the correct disabled state on next tick
      scheduleRender();
    }
  }
});

// Top-level tab switcher (Capture / Auto-Feeds / Library / Settings).
// Internal keys kept as the old names to minimise code churn — the user-
// facing labels live in popup.html, not here.
function selectTopTab(which) {
  const map = {
    transcripts: { tab: els.topTabTranscripts, panel: els.topPanelTranscripts },
    watched:     { tab: els.topTabWatched,     panel: els.topPanelWatched },
    library:     { tab: els.topTabLibrary,     panel: els.topPanelLibrary },
    admin:       { tab: els.topTabAdmin,       panel: els.topPanelAdmin },
    settings:    { tab: els.topTabSettings,    panel: els.topPanelSettings },
  };
  for (const [name, { tab, panel }] of Object.entries(map)) {
    const on = name === which;
    tab.classList.toggle("active", on);
    panel.classList.toggle("hidden", !on);
  }
}
els.topTabTranscripts.addEventListener("click", () => selectTopTab("transcripts"));
els.topTabWatched.addEventListener("click", () => {
  selectTopTab("watched");
  loadWatchlist();  // cloud fetch (cache hit if within TTL)
});
els.topTabLibrary.addEventListener("click", () => selectTopTab("library"));
els.topTabAdmin.addEventListener("click", () => {
  selectTopTab("admin");
  fetchAdminQueue();
  fetchAdminFailed();
});
els.topTabSettings.addEventListener("click", () => selectTopTab("settings"));

// Admin tab is UI-gated on the resolved X-API-Key name. This is not real
// auth (a curious user can un-hide the tab via devtools); any admin action
// still has to be enforced server-side. The gate just avoids cluttering
// the popup for non-admin users.
async function refreshAdminVisibility() {
  try {
    const res = await send({ type: "whoami" });
    const isAdmin = res?.ok && res.name === "Pat";
    els.topTabAdmin.classList.toggle("hidden", !isAdmin);
    // If the tab was active but we lost admin, fall back to Capture.
    if (!isAdmin && els.topTabAdmin.classList.contains("active")) {
      selectTopTab("transcripts");
    }
  } catch {
    els.topTabAdmin.classList.add("hidden");
  }
}
refreshAdminVisibility();

// ---------- Admin tab: cloud queue management ----------------------------
// Re-uses the existing `list-cloud-queue` message for the data fetch and
// layers its own search / delete affordances over the top. Keeps the Cloud
// Queue view in Capture read-only while giving admins destructive powers here.

let adminQueueItems = [];
let adminFetchInFlight = false;

async function fetchAdminQueue() {
  if (adminFetchInFlight) return;
  adminFetchInFlight = true;
  els.adminQueueHeader.textContent = "Loading…";
  try {
    const res = await send({ type: "list-cloud-queue" });
    if (!res?.ok) {
      els.adminQueueHeader.textContent = `Error: ${res?.error || "unknown"}`;
      adminQueueItems = [];
      els.adminQueueList.innerHTML = "";
      return;
    }
    adminQueueItems = res.items || [];
    renderAdminQueue();
  } finally {
    adminFetchInFlight = false;
  }
}

function filteredAdminItems() {
  const q = (els.adminQueueSearch.value || "").trim().toLowerCase();
  if (!q) return adminQueueItems;
  return adminQueueItems.filter((it) =>
    (it.title || "").toLowerCase().includes(q)
    || (it.channel || "").toLowerCase().includes(q)
    || (it.from_watchlist || "").toLowerCase().includes(q)
    || (it.video_id || "").toLowerCase().includes(q)
  );
}

function renderAdminQueue() {
  els.adminQueueList.innerHTML = "";
  const visible = filteredAdminItems();

  els.adminQueueHeader.textContent = adminQueueItems.length === 0
    ? "Cloud queue is empty"
    : `${visible.length} of ${adminQueueItems.length} shown`;

  const q = (els.adminQueueSearch.value || "").trim();
  if (q) {
    els.adminQueueSearchCount.textContent = String(visible.length);
    els.adminQueueSearchCount.classList.remove("hidden");
  } else {
    els.adminQueueSearchCount.classList.add("hidden");
  }

  els.adminDeleteFiltered.classList.toggle("hidden", visible.length === 0);
  els.adminDeleteFiltered.textContent =
    q ? `Delete all ${visible.length} filtered` : `Delete all ${visible.length}`;

  for (const it of visible) {
    els.adminQueueList.appendChild(renderAdminRow(it));
  }
}

// Shared row renderer for both admin sections — Cloud Queue and Failed Queue
// use identical layout / meta / delete affordance. Caller supplies the
// on-delete callback (so each section can splice its own module-level list)
// and the status line element to surface per-row errors.
function renderAdminRowGeneric(it, { onDeleted, statusEl, deleteTitle }) {
  const row = document.createElement("div");
  row.className = "qrow";

  // Same colour scheme as the Cloud Queue tab: claimed → "running"
  // (orange), available → "pending" (gray). Red reserved for dead-lettered
  // rows (fail_count >= 3) that the server won't re-claim.
  const badge = document.createElement("span");
  const isDead = (it.fail_count ?? 0) >= 3 || it.status === "failed";
  const cls = isDead ? "failed" : (it.status === "claimed" ? "running" : "pending");
  badge.className = `badge ${cls}`;
  badge.title = isDead
    ? `dead-lettered${it.fail_count ? ` (${it.fail_count} failed attempts)` : ""}`
    : (it.status || "");
  row.appendChild(badge);

  const body = document.createElement("div");
  body.className = "body";
  const titleLine = document.createElement("div");
  titleLine.className = "title-line";
  const title = document.createElement("span");
  title.className = "title";
  const ch = it.channel || it.from_watchlist || "";
  const t = it.title || it.url || it.video_id || "(untitled)";
  title.textContent = ch ? `${ch}: ${t}` : t;
  title.title = t;
  if (it.url) {
    title.addEventListener("click", () => chrome.tabs.create({ url: it.url, active: true }));
  }
  titleLine.appendChild(title);
  body.appendChild(titleLine);

  const meta = document.createElement("div");
  meta.className = "row-meta";
  const parts = [];
  if (it.status === "claimed") parts.push("being scraped");
  if (it.fail_count) {
    parts.push(
      isDead
        ? `dead-lettered (${it.fail_count} fails)`
        : `${it.fail_count} failed attempt${it.fail_count === 1 ? "" : "s"}`
    );
  }
  if (it.from_watchlist) parts.push(`from @${it.from_watchlist}`);
  meta.textContent = parts.join(" · ");
  if (parts.length) body.appendChild(meta);

  row.appendChild(body);

  const actions = document.createElement("div");
  actions.className = "actions";
  const rm = document.createElement("button");
  rm.className = "icon";
  rm.textContent = "\u00d7";
  rm.title = deleteTitle || "Delete from cloud queue";
  rm.addEventListener("click", async () => {
    rm.disabled = true;
    const res = await send({ type: "admin-delete-queue", videoIds: [it.video_id] });
    if (res?.ok) {
      onDeleted(it);
    } else {
      statusEl.textContent = `Error: ${res?.error || "unknown"}`;
      statusEl.style.color = "#c0392b";
      rm.disabled = false;
      setTimeout(() => { statusEl.textContent = ""; statusEl.style.color = ""; }, 5000);
    }
  });
  actions.appendChild(rm);
  row.appendChild(actions);

  return row;
}

function renderAdminRow(it) {
  return renderAdminRowGeneric(it, {
    onDeleted: (row) => {
      adminQueueItems = adminQueueItems.filter((x) => x.video_id !== row.video_id);
      renderAdminQueue();
    },
    statusEl: els.adminQueueStatus,
    deleteTitle: "Delete from cloud queue",
  });
}

els.adminQueueSearch.addEventListener("input", renderAdminQueue);
els.refreshAdminQueue.addEventListener("click", () => {
  els.refreshAdminQueue.disabled = true;
  fetchAdminQueue().finally(() => { els.refreshAdminQueue.disabled = false; });
});
els.adminDeleteFiltered.addEventListener("click", async () => {
  const visible = filteredAdminItems();
  if (!visible.length) return;
  if (!confirm(`Delete ${visible.length} item${visible.length === 1 ? "" : "s"} from the shared cloud queue? This can't be undone.`)) return;
  els.adminDeleteFiltered.disabled = true;
  try {
    const videoIds = visible.map((it) => it.video_id).filter(Boolean);
    const res = await send({ type: "admin-delete-queue", videoIds });
    if (res?.ok) {
      const deletedSet = new Set(videoIds);
      adminQueueItems = adminQueueItems.filter((x) => !deletedSet.has(x.video_id));
      els.adminQueueStatus.textContent = `Deleted ${res.deleted} row${res.deleted === 1 ? "" : "s"}.`;
      els.adminQueueStatus.style.color = "";
      setTimeout(() => { els.adminQueueStatus.textContent = ""; }, 5000);
      renderAdminQueue();
    } else {
      els.adminQueueStatus.textContent = `Error: ${res?.error || "unknown"}`;
      els.adminQueueStatus.style.color = "#c0392b";
    }
  } finally {
    els.adminDeleteFiltered.disabled = false;
  }
});

// ---------- Admin tab: failed queue (server-side dead letters) -----------
// Same UX as the Cloud Queue admin section, but pulls `status_filter=failed`
// from the server. Reuses the `admin-delete-queue` message because the
// server's POST /admin/queue/delete is status-agnostic (deletes by video_id).

let adminFailedItems = [];
let adminFailedFetchInFlight = false;

async function fetchAdminFailed() {
  if (adminFailedFetchInFlight) return;
  adminFailedFetchInFlight = true;
  els.adminFailedHeader.textContent = "Loading…";
  try {
    const res = await send({ type: "list-cloud-queue", statusFilter: "failed", includeFailed: true });
    if (!res?.ok) {
      els.adminFailedHeader.textContent = `Error: ${res?.error || "unknown"}`;
      adminFailedItems = [];
      els.adminFailedList.innerHTML = "";
      return;
    }
    adminFailedItems = res.items || [];
    renderAdminFailed();
  } finally {
    adminFailedFetchInFlight = false;
  }
}

function filteredAdminFailedItems() {
  const q = (els.adminFailedSearch.value || "").trim().toLowerCase();
  if (!q) return adminFailedItems;
  return adminFailedItems.filter((it) =>
    (it.title || "").toLowerCase().includes(q)
    || (it.channel || "").toLowerCase().includes(q)
    || (it.from_watchlist || "").toLowerCase().includes(q)
    || (it.video_id || "").toLowerCase().includes(q)
  );
}

function renderAdminFailed() {
  els.adminFailedList.innerHTML = "";
  const visible = filteredAdminFailedItems();

  els.adminFailedHeader.textContent = adminFailedItems.length === 0
    ? "Failed queue is empty"
    : `${visible.length} of ${adminFailedItems.length} shown`;

  const q = (els.adminFailedSearch.value || "").trim();
  if (q) {
    els.adminFailedSearchCount.textContent = String(visible.length);
    els.adminFailedSearchCount.classList.remove("hidden");
  } else {
    els.adminFailedSearchCount.classList.add("hidden");
  }

  els.adminDeleteFailedFiltered.classList.toggle("hidden", visible.length === 0);
  els.adminDeleteFailedFiltered.textContent =
    q ? `Delete all ${visible.length} filtered` : `Delete all ${visible.length}`;

  for (const it of visible) {
    els.adminFailedList.appendChild(renderAdminFailedRow(it));
  }
}

function renderAdminFailedRow(it) {
  return renderAdminRowGeneric(it, {
    onDeleted: (row) => {
      adminFailedItems = adminFailedItems.filter((x) => x.video_id !== row.video_id);
      renderAdminFailed();
    },
    statusEl: els.adminFailedStatus,
    deleteTitle: "Delete from failed queue",
  });
}

els.adminFailedSearch.addEventListener("input", renderAdminFailed);
els.refreshAdminFailed.addEventListener("click", () => {
  els.refreshAdminFailed.disabled = true;
  fetchAdminFailed().finally(() => { els.refreshAdminFailed.disabled = false; });
});
els.adminDeleteFailedFiltered.addEventListener("click", async () => {
  const visible = filteredAdminFailedItems();
  if (!visible.length) return;
  if (!confirm(`Delete ${visible.length} item${visible.length === 1 ? "" : "s"} from the failed queue? This can't be undone.`)) return;
  els.adminDeleteFailedFiltered.disabled = true;
  try {
    const videoIds = visible.map((it) => it.video_id).filter(Boolean);
    const res = await send({ type: "admin-delete-queue", videoIds });
    if (res?.ok) {
      const deletedSet = new Set(videoIds);
      adminFailedItems = adminFailedItems.filter((x) => !deletedSet.has(x.video_id));
      els.adminFailedStatus.textContent = `Deleted ${res.deleted} row${res.deleted === 1 ? "" : "s"}.`;
      els.adminFailedStatus.style.color = "";
      setTimeout(() => { els.adminFailedStatus.textContent = ""; }, 5000);
      renderAdminFailed();
    } else {
      els.adminFailedStatus.textContent = `Error: ${res?.error || "unknown"}`;
      els.adminFailedStatus.style.color = "#c0392b";
    }
  } finally {
    els.adminDeleteFailedFiltered.disabled = false;
  }
});

els.refreshWatchlist.addEventListener("click", () => {
  els.refreshWatchlist.disabled = true;
  loadWatchlist({ forceRefresh: true }).finally(() => {
    els.refreshWatchlist.disabled = false;
  });
});

function selectSettingsTab(which) {
  const general = which === "general";
  els.settingsTabGeneral.classList.toggle("active", general);
  els.settingsTabCloud.classList.toggle("active", !general);
  els.settingsPanelGeneral.classList.toggle("hidden", !general);
  els.settingsPanelCloud.classList.toggle("hidden", general);
}
els.settingsTabGeneral.addEventListener("click", () => selectSettingsTab("general"));
els.settingsTabCloud.addEventListener("click", () => selectSettingsTab("cloud"));

function selectAdminTab(which) {
  const isQueue = which === "queue";
  const isAutoupdate = which === "autoupdate";
  const isYtapi = which === "ytapi";
  els.adminSubtabQueue.classList.toggle("active", isQueue);
  els.adminSubtabAutoupdate.classList.toggle("active", isAutoupdate);
  els.adminSubtabYtapi.classList.toggle("active", isYtapi);
  els.adminSubpanelQueue.classList.toggle("hidden", !isQueue);
  els.adminSubpanelAutoupdate.classList.toggle("hidden", !isAutoupdate);
  els.adminSubpanelYtapi.classList.toggle("hidden", !isYtapi);
  if (isAutoupdate) populateAutoupdateChannels();
  if (isYtapi) loadYtApiUsage();
}
els.adminSubtabQueue.addEventListener("click", () => selectAdminTab("queue"));
els.adminSubtabAutoupdate.addEventListener("click", () => selectAdminTab("autoupdate"));
els.adminSubtabYtapi.addEventListener("click", () => selectAdminTab("ytapi"));


// ---------- Admin → YT API: show Cloud Monitoring usage ----------
function formatNum(n) {
  if (typeof n !== "number") return "—";
  return n.toLocaleString();
}

async function loadYtApiUsage() {
  els.ytapiStatus.textContent = "Loading…";
  els.ytapiStatus.style.color = "";
  try {
    const res = await send({ type: "fetch-yt-api-usage" });
    if (!res?.ok) {
      els.ytapiStatus.textContent = `Error — ${res?.error || "unknown error"}`;
      els.ytapiStatus.style.color = "#c0392b";
      return;
    }
    const d = res.data || {};
    const used = d.total_units_used ?? 0;
    const quota = d.daily_quota_limit ?? 0;
    const remaining = d.remaining ?? Math.max(0, quota - used);
    els.ytapiUsed.textContent = formatNum(used);
    els.ytapiRemaining.textContent = formatNum(remaining);
    els.ytapiQuota.textContent = formatNum(quota);
    const pct = quota > 0 ? Math.min(100, (used / quota) * 100) : 0;
    els.ytapiBar.style.width = pct + "%";
    els.ytapiBar.classList.remove("warn", "danger");
    if (pct >= 90) els.ytapiBar.classList.add("danger");
    else if (pct >= 70) els.ytapiBar.classList.add("warn");
    els.ytapiWindow.textContent = d.window_end_utc
      ? `Window: last ${d.window_hours || 24}h ending ${d.window_end_utc}`
      : "";
    els.ytapiStatus.textContent = d.note || "";
    els.ytapiStatus.style.color = "";
  } catch (e) {
    els.ytapiStatus.textContent = `Error — ${String(e?.message || e)}`;
    els.ytapiStatus.style.color = "#c0392b";
  }
}

els.ytapiRefresh?.addEventListener("click", () => loadYtApiUsage());


// ---------- Admin → Auto-Update: list missing videos for a watched channel --
async function populateAutoupdateChannels({ forceRefresh = false } = {}) {
  try {
    const res = await send({ type: "list-watchlist", forceRefresh });
    if (!res?.ok) {
      els.autoupdateStatus.textContent = `Couldn't load channels — ${res?.error || "unknown error"}`;
      els.autoupdateStatus.style.color = "#c0392b";
      return;
    }
    const channels = (res.channels || []).filter((c) => c.handle);
    const prev = els.autoupdateChannel.value;
    els.autoupdateChannel.innerHTML = "";
    if (!channels.length) {
      const opt = document.createElement("option");
      opt.value = "";
      opt.textContent = "No watched channels";
      els.autoupdateChannel.appendChild(opt);
      return;
    }
    channels.sort((a, b) =>
      (a.displayName || a.handle).localeCompare(b.displayName || b.handle),
    );
    for (const c of channels) {
      const opt = document.createElement("option");
      opt.value = c.handle;
      opt.textContent = `${c.displayName || c.handle} (@${c.handle})`;
      els.autoupdateChannel.appendChild(opt);
    }
    if (prev) els.autoupdateChannel.value = prev;
    els.autoupdateStatus.textContent = "";
    els.autoupdateStatus.style.color = "";
  } catch (e) {
    els.autoupdateStatus.textContent = `Couldn't load channels — ${String(e?.message || e)}`;
    els.autoupdateStatus.style.color = "#c0392b";
  }
}

let autoupdateCurrentItems = [];
let autoupdateCurrentHandle = "";

function renderAutoupdateMissing(items, handle) {
  els.autoupdateList.innerHTML = "";
  autoupdateCurrentItems = Array.isArray(items) ? items : [];
  autoupdateCurrentHandle = handle || "";
  if (!items.length) {
    els.autoupdateHeader.textContent = `No missing videos for @${handle} — corpus is up to date.`;
    els.autoupdateQueueAll?.classList.add("hidden");
    return;
  }
  els.autoupdateHeader.textContent = `${items.length} missing video${items.length === 1 ? "" : "s"} for @${handle}:`;
  els.autoupdateQueueAll?.classList.remove("hidden");
  for (const v of items) {
    const row = document.createElement("div");
    row.className = "qrow";
    const body = document.createElement("div");
    body.className = "body";
    const titleLine = document.createElement("div");
    titleLine.className = "title-line";
    const a = document.createElement("a");
    a.href = v.url;
    a.target = "_blank";
    a.rel = "noopener noreferrer";
    a.className = "title";
    a.textContent = v.title || v.video_id;
    titleLine.appendChild(a);
    body.appendChild(titleLine);
    const meta = document.createElement("div");
    meta.className = "row-meta";
    meta.textContent = `${v.published_at || "—"}  ·  ${v.video_id}`;
    body.appendChild(meta);
    row.appendChild(body);
    els.autoupdateList.appendChild(row);
  }
}

els.autoupdateRefreshChannels?.addEventListener("click", () =>
  populateAutoupdateChannels({ forceRefresh: true }),
);

els.autoupdateRun?.addEventListener("click", async () => {
  const handle = (els.autoupdateChannel.value || "").trim();
  if (!handle) {
    els.autoupdateStatus.textContent = "Pick a channel first.";
    els.autoupdateStatus.style.color = "#c0392b";
    return;
  }
  const limitNum = Math.max(1, Math.min(5000, parseInt(els.autoupdateLimit.value, 10) || 50));
  els.autoupdateRun.disabled = true;
  els.autoupdateStatus.textContent = "Checking…";
  els.autoupdateStatus.style.color = "";
  els.autoupdateHeader.textContent = "";
  els.autoupdateList.innerHTML = "";
  try {
    const res = await send({ type: "check-missing", handle, limit: limitNum });
    if (!res?.ok) {
      els.autoupdateStatus.textContent = `Error — ${res?.error || "unknown error"}`;
      els.autoupdateStatus.style.color = "#c0392b";
      return;
    }
    renderAutoupdateMissing(res.items || [], handle);
    els.autoupdateStatus.textContent = "";
  } catch (e) {
    els.autoupdateStatus.textContent = `Error — ${String(e?.message || e)}`;
    els.autoupdateStatus.style.color = "#c0392b";
  } finally {
    els.autoupdateRun.disabled = false;
  }
});

els.autoupdateQueueAll?.addEventListener("click", async () => {
  if (!autoupdateCurrentItems.length) return;
  els.autoupdateQueueAll.disabled = true;
  els.autoupdateStatus.textContent = "Adding to queue…";
  els.autoupdateStatus.style.color = "";
  try {
    const res = await send({
      type: "queue-add-missing",
      items: autoupdateCurrentItems,
      handle: autoupdateCurrentHandle,
    });
    if (!res?.ok) {
      els.autoupdateStatus.textContent = `Error — ${res?.error || "unknown error"}`;
      els.autoupdateStatus.style.color = "#c0392b";
      els.autoupdateQueueAll.disabled = false;
      return;
    }
    const added = res.added || 0;
    const deduped = res.deduped || 0;
    els.autoupdateStatus.textContent = `Queued ${added} video${added === 1 ? "" : "s"} (${deduped} were already in the queue).`;
    els.autoupdateStatus.style.color = "";
    els.autoupdateQueueAll.classList.add("hidden");
    els.autoupdateList.innerHTML = "";
    els.autoupdateHeader.textContent = "";
    autoupdateCurrentItems = [];
  } catch (e) {
    els.autoupdateStatus.textContent = `Error — ${String(e?.message || e)}`;
    els.autoupdateStatus.style.color = "#c0392b";
    els.autoupdateQueueAll.disabled = false;
  }
});

els.tabActive.addEventListener("click", () => {
  currentTab = "active";
  scheduleRender();
});
els.tabUnsynced.addEventListener("click", () => {
  currentTab = "unsynced";
  scheduleRender();
});
els.tabFailed.addEventListener("click", () => {
  currentTab = "failed";
  scheduleRender();
});
els.tabCloud.addEventListener("click", () => {
  currentTab = "cloud";
  cloudItems = null;           // always force a fresh list on tab activation
  pollClaimFromCloud();        // and refresh the stats immediately
  scheduleRender();
});

els.refreshCloud.addEventListener("click", async () => {
  els.refreshCloud.classList.add("spinning");
  els.refreshCloud.disabled = true;
  try {
    cloudItems = null;
    await Promise.all([fetchCloudItems(), pollClaimFromCloud()]);
  } finally {
    els.refreshCloud.classList.remove("spinning");
    els.refreshCloud.disabled = false;
  }
});

async function fetchCloudItems() {
  try {
    const res = await chrome.runtime.sendMessage({ type: "list-cloud-queue" });
    if (res?.ok) {
      cloudItems = res.items || [];
      cloudLastFetch = Date.now();
      scheduleRender();
    }
  } catch {
    // silent
  }
}

function renderCloudRow(it) {
  const row = document.createElement("div");
  row.className = "qrow";

  const badge = document.createElement("span");
  badge.className = `badge ${it.status === "claimed" ? "running" : "pending"}`;
  badge.title = it.status;
  row.appendChild(badge);

  const body = document.createElement("div");
  body.className = "body";
  const titleLine = document.createElement("div");
  titleLine.className = "title-line";
  const title = document.createElement("span");
  title.className = "title";
  const cloudChannel = it.channel || "";
  const cloudTitle = it.title || it.video_id || "(untitled)";
  title.textContent = cloudChannel ? `${cloudChannel}: ${cloudTitle}` : cloudTitle;
  title.title = cloudTitle;
  if (it.url) title.addEventListener("click", () => chrome.tabs.create({ url: it.url, active: true }));
  titleLine.appendChild(title);
  body.appendChild(titleLine);

  const meta = document.createElement("div");
  meta.className = "row-meta";
  const parts = [];
  // Privacy: no user names. Show status + failure count only.
  if (it.status === "claimed") parts.push("being scraped");
  if (it.fail_count) parts.push(`${it.fail_count} failed attempt${it.fail_count === 1 ? "" : "s"}`);
  if (it.from_watchlist) parts.push(`from @${it.from_watchlist}`);
  meta.textContent = parts.join(" · ");
  body.appendChild(meta);

  row.appendChild(body);
  return row;
}

els.clear.addEventListener("click", () => {
  setOverflowOpen(false);
  if (!state.queue.length) return;
  if (!confirm(`Clear all ${state.queue.length} items from the queue?`)) return;
  send({ type: "clear" });
});

els.menuRetryFailed.addEventListener("click", () => {
  setOverflowOpen(false);
  send({ type: "retry-all-and-start" });
});

els.downloadZip.addEventListener("click", () => send({ type: "download-results", mode: "zip" }));

// Overflow ⋯ menu: toggles on click, closes on outside click or after a
// menu-item click. Kept simple — no keyboard nav yet.
function setOverflowOpen(open) {
  els.overflowMenu.classList.toggle("hidden", !open);
  els.overflowToggle.setAttribute("aria-expanded", open ? "true" : "false");
}
els.overflowToggle.addEventListener("click", (e) => {
  e.stopPropagation();
  const isOpen = !els.overflowMenu.classList.contains("hidden");
  setOverflowOpen(!isOpen);
});
document.addEventListener("click", (e) => {
  if (els.overflowMenu.classList.contains("hidden")) return;
  if (els.overflowMenu.contains(e.target)) return;      // click inside menu
  if (e.target === els.overflowToggle) return;          // handled above
  setOverflowOpen(false);
});

function showSyncStatus(msg, isError = false) {
  els.syncStatus.textContent = msg;
  els.syncStatus.style.color = isError ? "#c0392b" : "";
  setTimeout(() => { els.syncStatus.textContent = ""; els.syncStatus.style.color = ""; }, 6000);
}

function pushSettings() {
  const secs = Number(els.delay.value) || 4;
  const next = {
    lang: (els.lang.value || "en").trim() || "en",
    includeTimestamps: els.timestamps.checked,
    delayMs: Math.max(2000, Math.min(20000, secs * 1000)),
    apiUrl: (els.apiUrl.value || "").trim(),
    apiKey: (els.apiKey.value || "").trim(),
    autoSyncCloud: els.autoSync.checked,
    syncDownloadQueue: els.syncDownloadQueue.checked,
  };
  state.settings = { ...state.settings, ...next };
  return send({ type: "update-settings", settings: next });
}

// Flush any pending debounced settings push before a sync, so we don't race
// "paste key -> click sync within 200ms -> sync uses stale apiKey".
async function flushSettingsThen(fn) {
  clearTimeout(settingsDebounce);
  await pushSettings();
  return fn();
}

let settingsDebounce = null;
function debouncedPushSettings() {
  clearTimeout(settingsDebounce);
  settingsDebounce = setTimeout(pushSettings, 200);
}

els.lang.addEventListener("input", debouncedPushSettings);
els.timestamps.addEventListener("change", pushSettings);
els.showOverlay.addEventListener("change", () => {
  chrome.storage.local.set({ uiHidden: !els.showOverlay.checked });
});
els.hideCompleted.addEventListener("change", () => {
  chrome.storage.local.set({ hideCompleted: els.hideCompleted.checked });
  scheduleRender();
});

els.queueSearch.addEventListener("input", scheduleRender);
els.delay.addEventListener("input", () => {
  els.delayVal.textContent = els.delay.value;
  debouncedPushSettings();
});
els.apiUrl.addEventListener("input", debouncedPushSettings);
els.apiKey.addEventListener("input", debouncedPushSettings);
els.autoSync.addEventListener("change", pushSettings);
els.syncDownloadQueue.addEventListener("change", pushSettings);

els.watchCurrent.addEventListener("click", async () => {
  if (!activeTab?.id) return;
  els.watchCurrent.disabled = true;
  showWatchStatus("Adding…");
  const res = await send({ type: "add-watched-from-tab", tabId: activeTab.id });
  if (res?.ok && res.deduped) showWatchStatus(`Already watching ${res.displayName || res.handle}`);
  else if (res?.ok) showWatchStatus(`Added ${res.displayName || res.handle}`);
  else showWatchStatus(`Error: ${res?.error || "unknown"}`, true);
  if (res?.ok) await loadWatchlist({ forceRefresh: true });
  updateAddButtons();
});

els.checkWatchlist.addEventListener("click", async () => {
  els.checkWatchlist.disabled = true;
  showWatchStatus("Checking channels…");
  try {
    const res = await send({ type: "check-watchlist" });
    if (res?.ok) {
      const errs = (res.errors || []).length;
      const base = batchAddStatusMessage(res.added, res.cloud);
      const msg = `${base} from ${res.checked} channel${res.checked === 1 ? "" : "s"}` + (errs ? ` (${errs} failed)` : "");
      showWatchStatus(msg, errs > 0);
      // New items were pushed to cloud server-side. Invalidate the local
      // Cloud Queue cache + refresh stats so the count badge and list
      // reflect reality without waiting for the next 30s poll.
      if ((res.added ?? 0) > 0) {
        cloudItems = null;
        pollClaimFromCloud();
      }
    } else {
      showWatchStatus(`Error: ${res?.error || "unknown"}`, true);
    }
  } finally {
    els.checkWatchlist.disabled = false;
  }
});

function showWatchStatus(msg, isError = false) {
  els.watchlistStatus.textContent = msg;
  els.watchlistStatus.style.color = isError ? "#c0392b" : "";
  setTimeout(() => { els.watchlistStatus.textContent = ""; els.watchlistStatus.style.color = ""; }, 5000);
}

init();

// Cloud-queue polling policy:
//   - one-shot on popup open (so the Cloud Queue badge reflects current state),
//   - every 30s while batch.state === "running" (feeds the claim loop),
//   - on Cloud Queue tab click (immediate refresh of items + stats).
// No continuous polling when idle — no work means no network waste.
const CLOUD_CLAIM_POLL_MS = 30000;
let cloudPollTimer = null;

async function pollClaimFromCloud() {
  try {
    const res = await chrome.runtime.sendMessage({ type: "claim-from-cloud" });
    if (!res?.ok) return;
    if (res.stats) { cloudStats = res.stats; scheduleRender(); }
    if ((res.claimed ?? 0) > 0) {
      showSyncStatus(`Claimed ${res.claimed} from cloud`);
    }
  } catch {
    // silent — popup might have died, or SW is asleep
  }
}

function syncCloudPollToBatch() {
  const running = state.batch.state === "running";
  if (running && !cloudPollTimer) {
    cloudPollTimer = setInterval(pollClaimFromCloud, CLOUD_CLAIM_POLL_MS);
  } else if (!running && cloudPollTimer) {
    clearInterval(cloudPollTimer);
    cloudPollTimer = null;
  }
}

// One-shot on popup open — gives the Cloud Queue badge real numbers and
// seeds a claim if the batch is about to resume.
setTimeout(pollClaimFromCloud, 1000);

// ---------- Library tab ---------------------------------------------------
// State is local to the Library tab. Items are paginated via offset + limit;
// filters and sort are applied server-side via /transcripts query params.

const LIBRARY_PAGE_SIZE = 100;
let libraryItems = [];
let libraryOffset = 0;
let libraryLoaded = false;          // first fetch done?
let libraryChannelsLoaded = false;  // channels dropdown populated?
let librarySearchDebounce = null;

function currentLibraryQuery() {
  const [sort, order] = (els.librarySort.value || "published_at|desc").split("|");
  return {
    search: els.librarySearch.value.trim(),
    channel: els.libraryChannel.value,
    sort, order,
    dateFrom: els.libraryDateFrom.value,
    dateTo: els.libraryDateTo.value,
  };
}

async function fetchLibraryChannels() {
  if (libraryChannelsLoaded) return;
  try {
    const res = await chrome.runtime.sendMessage({ type: "list-library-channels" });
    if (!res?.ok) return;
    for (const row of res.items || []) {
      const opt = document.createElement("option");
      opt.value = row.channel;
      opt.textContent = `${row.channel} (${row.n})`;
      els.libraryChannel.appendChild(opt);
    }
    libraryChannelsLoaded = true;
  } catch { /* silent */ }
}

async function fetchLibrary({ append = false } = {}) {
  if (!append) { libraryItems = []; libraryOffset = 0; }
  els.libraryHeader.textContent = append ? "Loading more…" : "Loading…";
  const q = currentLibraryQuery();
  const res = await chrome.runtime.sendMessage({
    type: "list-library",
    limit: LIBRARY_PAGE_SIZE,
    offset: libraryOffset,
    ...q,
  });
  if (!res?.ok) {
    els.libraryHeader.textContent = `Error: ${res?.error || "unknown"}`;
    return;
  }
  const items = res.items || [];
  libraryItems = append ? libraryItems.concat(items) : items;
  libraryOffset += items.length;
  libraryLoaded = true;

  // When a channel filter is active, auto-paginate until exhausted so the
  // user sees the full channel in one go (no "Load more" clicking).
  const channelSelected = !!q.channel;
  const hasMore = items.length >= LIBRARY_PAGE_SIZE;
  if (channelSelected && hasMore) {
    els.libraryHeader.textContent = `Loading ${libraryItems.length}… (fetching all for channel)`;
    renderLibraryList(append);
    return fetchLibrary({ append: true });
  }

  els.libraryHeader.textContent = libraryItems.length === 0
    ? "No transcripts found in the library matching criteria"
    : `Showing ${libraryItems.length} transcript${libraryItems.length === 1 ? "" : "s"}`;

  // Search count badge
  const qStr = q.search;
  if (qStr) {
    els.librarySearchCount.textContent = String(libraryItems.length);
    els.librarySearchCount.classList.remove("hidden");
  } else {
    els.librarySearchCount.classList.add("hidden");
  }

  // Hide "Load more" when channel is selected (we've already auto-loaded everything).
  els.libraryMore.classList.toggle("hidden", channelSelected || items.length < LIBRARY_PAGE_SIZE);
  renderLibraryList(append);
}

function renderLibraryList(append) {
  if (!append) els.libraryList.innerHTML = "";
  const startIdx = append ? libraryItems.length - (libraryItems.length - (libraryItems.length - LIBRARY_PAGE_SIZE)) : 0;
  // Simpler: always re-render everything when not appending; append only the new ones.
  if (!append) {
    for (const it of libraryItems) els.libraryList.appendChild(renderLibraryRow(it));
  } else {
    const renderedCount = els.libraryList.children.length;
    for (let i = renderedCount; i < libraryItems.length; i++) {
      els.libraryList.appendChild(renderLibraryRow(libraryItems[i]));
    }
  }
}

function formatNumber(n) {
  if (n == null) return null;
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1).replace(/\.0$/, "") + "M";
  if (n >= 1_000) return (n / 1_000).toFixed(1).replace(/\.0$/, "") + "K";
  return String(n);
}

function formatDuration(secs) {
  if (!secs) return null;
  const h = Math.floor(secs / 3600);
  const m = Math.floor((secs % 3600) / 60);
  return h > 0 ? `${h}h${m}m` : `${m}m`;
}

function renderLibraryRow(it) {
  const row = document.createElement("div");
  row.className = "qrow";

  const badge = document.createElement("span");
  badge.className = "badge done";
  row.appendChild(badge);

  const body = document.createElement("div");
  body.className = "body";

  const titleLine = document.createElement("div");
  titleLine.className = "title-line";
  const title = document.createElement("span");
  title.className = "title";
  const ch = it.channel_display_name || it.channel_handle || it.channel || "";
  const t = it.title || it.video_id || "(untitled)";
  title.textContent = ch ? `${ch}: ${t}` : t;
  title.title = t;
  if (it.url) title.addEventListener("click", () => chrome.tabs.create({ url: it.url, active: true }));
  titleLine.appendChild(title);
  body.appendChild(titleLine);

  const meta = document.createElement("div");
  meta.className = "row-meta";
  const parts = [];
  if (it.published_at) parts.push(it.published_at);
  const views = formatNumber(it.view_count);
  if (views) parts.push(`${views} views`);
  const dur = formatDuration(it.duration_seconds);
  if (dur) parts.push(dur);
  const chars = formatNumber(it.char_count);
  if (chars) parts.push(`${chars} chars`);
  meta.textContent = parts.join(" · ");
  body.appendChild(meta);

  row.appendChild(body);

  const actions = document.createElement("div");
  actions.className = "actions";

  const info = document.createElement("button");
  info.className = "icon";
  info.textContent = "\u2139"; // ℹ
  info.title = "View details";
  info.addEventListener("click", () => openLibraryDetail(it.video_id));
  actions.appendChild(info);

  // Download: fetch + build .txt with YAML frontmatter, save via chrome.downloads.
  const dl = document.createElement("button");
  dl.className = "icon";
  dl.textContent = "\u2B07"; // ⬇
  dl.title = "Download transcript as .txt";
  dl.addEventListener("click", async () => {
    dl.disabled = true;
    try {
      const res = await chrome.runtime.sendMessage({
        type: "download-library-transcript",
        video_id: it.video_id,
      });
      if (res?.ok) {
        dl.classList.add("ok");
        setTimeout(() => dl.classList.remove("ok"), 1200);
      } else {
        dl.classList.add("err");
        dl.title = `Error: ${res?.error || "unknown"}`;
        setTimeout(() => dl.classList.remove("err"), 2000);
      }
    } finally {
      dl.disabled = false;
    }
  });
  actions.appendChild(dl);

  row.appendChild(actions);
  return row;
}

els.librarySearch.addEventListener("input", () => {
  clearTimeout(librarySearchDebounce);
  librarySearchDebounce = setTimeout(() => fetchLibrary(), 300);
});
els.libraryChannel.addEventListener("change", () => fetchLibrary());
els.librarySort.addEventListener("change", () => fetchLibrary());
els.libraryDateFrom.addEventListener("change", () => fetchLibrary());
els.libraryDateTo.addEventListener("change", () => fetchLibrary());
els.libraryMore.addEventListener("click", () => fetchLibrary({ append: true }));
els.refreshLibrary.addEventListener("click", () => {
  els.refreshLibrary.disabled = true;
  libraryChannelsLoaded = false;  // re-pull the channel dropdown too
  // Clear the cached channel list so the dropdown reflects fresh counts.
  els.libraryChannel.innerHTML = '<option value="">All channels</option>';
  Promise.all([fetchLibraryChannels(), fetchLibrary()])
    .finally(() => { els.refreshLibrary.disabled = false; });
});

// Library detail modal. The field order matches the on-screen ordering spec;
// any unknown keys from future schema bumps fall through to a generic render.
// Strip audit-only identity fields defensively; the API already omits them,
// but future server versions shouldn't be able to leak them here by accident.
const DETAIL_STRIP_KEYS = new Set([
  "synced_by",
  "added_by",
  "claimed_by",
  "created_by",
  "email",
]);

const DETAIL_FIELD_ORDER = [
  "url",
  "video_id",
  "channel_display_name",
  "channel_handle",
  "channel",
  "published_at",
  "view_count",
  "duration_seconds",
  "char_count",
  "lang",
  "has_timestamps",
  "source",
  "category",
  "keywords",
  "scraped_at",
  "synced_at",
  "channel_id",
  "category_id",
  "topic_categories",
  "audio_language",
  "like_count",
  "comment_count",
  "has_captions",
  "made_for_kids",
  "published_at_timestamp",
  "metadata_verified_at",
];

function formatDetailValue(key, value) {
  if (value == null || value === "") return "—";
  if (key === "view_count" || key === "char_count" || key === "like_count" || key === "comment_count") {
    const n = Number(value);
    if (Number.isFinite(n)) return n.toLocaleString("en-US");
  }
  if (key === "duration_seconds") {
    const n = Number(value);
    if (Number.isFinite(n)) return formatDuration(n) || String(value);
  }
  if (key === "has_timestamps") {
    return value ? "\u2713" : "—";
  }
  if (key === "topic_categories" && Array.isArray(value)) {
    return value.length ? value.join("\n") : "—";
  }
  if (typeof value === "boolean") return value ? "\u2713" : "—";
  if (key === "keywords" && Array.isArray(value)) {
    return value.length ? value.join(", ") : "—";
  }
  if (typeof value === "object") {
    try { return JSON.stringify(value); } catch { return String(value); }
  }
  return String(value);
}

function renderDetailRow(dl, key, value) {
  const dt = document.createElement("dt");
  dt.textContent = key;
  const dd = document.createElement("dd");
  if (key === "url" && typeof value === "string" && value) {
    const a = document.createElement("a");
    a.href = value;
    a.target = "_blank";
    a.rel = "noreferrer noopener";
    a.textContent = value;
    a.addEventListener("click", (ev) => {
      ev.preventDefault();
      chrome.tabs.create({ url: value, active: true });
    });
    dd.appendChild(a);
  } else {
    dd.textContent = formatDetailValue(key, value);
  }
  dl.appendChild(dt);
  dl.appendChild(dd);
}

function renderLibraryDetail(item) {
  els.detailBody.textContent = "";

  const title = item.title || item.video_id || "(untitled)";
  els.detailTitle.textContent = title;
  els.detailTitle.title = title;

  const dl = document.createElement("dl");
  dl.className = "detail-list";

  const rendered = new Set();
  for (const key of DETAIL_FIELD_ORDER) {
    if (DETAIL_STRIP_KEYS.has(key)) continue;
    if (!(key in item)) continue;
    renderDetailRow(dl, key, item[key]);
    rendered.add(key);
  }
  for (const key of Object.keys(item)) {
    if (rendered.has(key)) continue;
    if (key === "title" || key === "body" || key === "description") continue;
    if (DETAIL_STRIP_KEYS.has(key)) continue;
    renderDetailRow(dl, key, item[key]);
  }
  els.detailBody.appendChild(dl);

  if (typeof item.description === "string" && item.description) {
    const label = document.createElement("div");
    label.className = "detail-body-label";
    label.textContent = "description";
    els.detailBody.appendChild(label);
    const pre = document.createElement("pre");
    pre.className = "detail-body-text";
    pre.textContent = item.description;
    els.detailBody.appendChild(pre);
  }

  if (typeof item.body === "string" && item.body) {
    const label = document.createElement("div");
    label.className = "detail-body-label";
    label.textContent = "body";
    els.detailBody.appendChild(label);
    const pre = document.createElement("pre");
    pre.className = "detail-body-text";
    pre.textContent = item.body;
    els.detailBody.appendChild(pre);
  }
}

async function openLibraryDetail(videoId) {
  els.detailTitle.textContent = "Transcript details";
  els.detailTitle.removeAttribute("title");
  els.detailBody.textContent = "";
  const loading = document.createElement("div");
  loading.className = "detail-loading";
  loading.textContent = "Loading…";
  els.detailBody.appendChild(loading);
  els.detailModal.classList.remove("hidden");

  try {
    const res = await chrome.runtime.sendMessage({
      type: "fetch-transcript",
      video_id: videoId,
    });
    if (!res?.ok) throw new Error(res?.error || "unknown error");
    const raw = res.item || {};
    const item = {};
    for (const [k, v] of Object.entries(raw)) {
      if (!DETAIL_STRIP_KEYS.has(k)) item[k] = v;
    }
    renderLibraryDetail(item);
  } catch (e) {
    els.detailBody.textContent = "";
    const err = document.createElement("div");
    err.className = "detail-error";
    err.textContent = `Failed to load: ${String(e?.message || e)}`;
    els.detailBody.appendChild(err);
  }
}

function closeDetailModal() {
  els.detailModal.classList.add("hidden");
}

els.detailModal.addEventListener("click", (ev) => {
  const t = ev.target;
  if (t instanceof Element && t.hasAttribute("data-modal-close")) {
    closeDetailModal();
  }
});

document.addEventListener("keydown", (ev) => {
  if (ev.key === "Escape" && !els.detailModal.classList.contains("hidden")) {
    closeDetailModal();
  }
});

// Lazy-load the Library the first time the user opens the tab.
els.topTabLibrary.addEventListener("click", () => {
  if (!libraryLoaded) {
    fetchLibraryChannels();
    fetchLibrary();
  }
}, { once: false });
