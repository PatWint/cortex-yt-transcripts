// New message type added to protocol (coordinate with Worker A):
//   {type:'scrape-and-add-channel', tabId}
// SW injects scrapers.js, invokes grabChannelVideos(), dedupes, enqueues.

const WATCH_RE = /youtube\.com\/watch\?v=/;
const CHANNEL_RE = /youtube\.com\/(@[^/]+|channel\/[^/]+|c\/[^/]+|user\/[^/]+)(\/videos)?\/?/;
const VIDEO_ID_RE = /^[A-Za-z0-9_-]{11}$/;

function parseVideoId(input) {
  const s = (input || "").trim();
  if (!s) return null;
  if (VIDEO_ID_RE.test(s)) return s;
  let u;
  try {
    u = new URL(s.includes("://") ? s : `https://${s}`);
  } catch {
    return null;
  }
  const host = u.hostname.replace(/^www\./, "");
  if (host === "youtu.be") {
    const id = u.pathname.slice(1).split("/")[0];
    return VIDEO_ID_RE.test(id) ? id : null;
  }
  if (host === "youtube.com" || host === "m.youtube.com") {
    if (u.pathname === "/watch") {
      const id = u.searchParams.get("v");
      return id && VIDEO_ID_RE.test(id) ? id : null;
    }
    const m = u.pathname.match(/^\/(?:shorts|embed|v|live)\/([^/]+)/);
    if (m && VIDEO_ID_RE.test(m[1])) return m[1];
  }
  return null;
}

const els = {
  detach: document.getElementById("detach"),
  addVideo: document.getElementById("add-video"),
  addChannel: document.getElementById("add-channel"),
  addUrl: document.getElementById("add-url"),
  addUrlBtn: document.getElementById("add-url-btn"),
  addStatus: document.getElementById("add-status"),
  stopScrape: document.getElementById("stop-scrape"),
  tabActive: document.getElementById("tab-active"),
  tabUnsynced: document.getElementById("tab-unsynced"),
  tabFailed: document.getElementById("tab-failed"),
  tabCloud: document.getElementById("tab-cloud"),
  queueHeader: document.getElementById("queue-header"),
  refreshCloud: document.getElementById("refresh-cloud"),
  queueSearch: document.getElementById("queue-search"),
  queueSearchWrap: document.getElementById("queue-search-wrap"),
  queueSearchCount: document.getElementById("queue-search-count"),
  syncStatus: document.getElementById("sync-status"),
  hideCompleted: document.getElementById("hide-completed"),
  hideCompletedRow: document.getElementById("hide-completed-row"),
  queueList: document.getElementById("queue-list"),
  start: document.getElementById("start"),
  tabAction: document.getElementById("tab-action"),
  clear: document.getElementById("clear"),
  downloadZip: document.getElementById("download-zip"),
  overflowToggle: document.getElementById("overflow-toggle"),
  overflowMenu: document.getElementById("overflow-menu"),
  menuRetryFailed: document.getElementById("menu-retry-failed"),
  lang: document.getElementById("lang"),
  timestamps: document.getElementById("timestamps"),
  delay: document.getElementById("delay"),
  delayVal: document.getElementById("delay-val"),
  showOverlay: document.getElementById("show-overlay"),
  apiUrl: document.getElementById("api-url"),
  apiKey: document.getElementById("api-key"),
  autoSync: document.getElementById("auto-sync"),
  syncDownloadQueue: document.getElementById("sync-download-queue"),
  watchCurrent: document.getElementById("watch-current"),
  watchlist: document.getElementById("watchlist"),
  watchlistStatus: document.getElementById("watchlist-status"),
  checkWatchlist: document.getElementById("check-watchlist"),
  refreshWatchlist: document.getElementById("refresh-watchlist"),
  settingsTabGeneral: document.getElementById("settings-tab-general"),
  settingsTabCloud: document.getElementById("settings-tab-cloud"),
  settingsPanelGeneral: document.getElementById("settings-panel-general"),
  settingsPanelCloud: document.getElementById("settings-panel-cloud"),
  syncDlSpinner: document.getElementById("sync-dl-spinner"),
  autoSyncSpinner: document.getElementById("auto-sync-spinner"),
  librarySearch: document.getElementById("library-search"),
  librarySearchCount: document.getElementById("library-search-count"),
  libraryChannel: document.getElementById("library-channel"),
  librarySort: document.getElementById("library-sort"),
  libraryDateFrom: document.getElementById("library-date-from"),
  libraryDateTo: document.getElementById("library-date-to"),
  libraryHeader: document.getElementById("library-header"),
  libraryList: document.getElementById("library-list"),
  libraryMore: document.getElementById("library-more"),
  refreshLibrary: document.getElementById("refresh-library"),
  adminQueueSearch: document.getElementById("admin-queue-search"),
  adminQueueSearchCount: document.getElementById("admin-queue-search-count"),
  adminQueueHeader: document.getElementById("admin-queue-header"),
  adminQueueList: document.getElementById("admin-queue-list"),
  adminDeleteFiltered: document.getElementById("admin-delete-filtered"),
  adminQueueStatus: document.getElementById("admin-queue-status"),
  refreshAdminQueue: document.getElementById("refresh-admin-queue"),
  adminFailedSearch: document.getElementById("admin-failed-search"),
  adminFailedSearchCount: document.getElementById("admin-failed-search-count"),
  adminFailedHeader: document.getElementById("admin-failed-header"),
  adminFailedList: document.getElementById("admin-failed-list"),
  adminDeleteFailedFiltered: document.getElementById("admin-delete-failed-filtered"),
  adminFailedStatus: document.getElementById("admin-failed-status"),
  refreshAdminFailed: document.getElementById("refresh-admin-failed"),
  adminSubtabQueue: document.getElementById("admin-subtab-queue"),
  adminSubtabAutoupdate: document.getElementById("admin-subtab-autoupdate"),
  adminSubtabYtapi: document.getElementById("admin-subtab-ytapi"),
  adminSubpanelQueue: document.getElementById("admin-subpanel-queue"),
  adminSubpanelAutoupdate: document.getElementById("admin-subpanel-autoupdate"),
  adminSubpanelYtapi: document.getElementById("admin-subpanel-ytapi"),
  autoupdateChannel: document.getElementById("autoupdate-channel"),
  autoupdateLimit: document.getElementById("autoupdate-limit"),
  autoupdateRun: document.getElementById("autoupdate-run"),
  autoupdateRefreshChannels: document.getElementById("autoupdate-refresh-channels"),
  autoupdateHeader: document.getElementById("autoupdate-header"),
  autoupdateList: document.getElementById("autoupdate-list"),
  autoupdateQueueAll: document.getElementById("autoupdate-queue-all"),
  autoupdateStatus: document.getElementById("autoupdate-status"),
  ytapiRefresh: document.getElementById("ytapi-refresh"),
  ytapiUsed: document.getElementById("ytapi-used"),
  ytapiRemaining: document.getElementById("ytapi-remaining"),
  ytapiQuota: document.getElementById("ytapi-quota"),
  ytapiBar: document.getElementById("ytapi-bar"),
  ytapiWindow: document.getElementById("ytapi-window"),
  ytapiStatus: document.getElementById("ytapi-status"),
  topTabTranscripts: document.getElementById("top-tab-transcripts"),
  topTabWatched: document.getElementById("top-tab-watched"),
  topTabLibrary: document.getElementById("top-tab-library"),
  topTabAdmin: document.getElementById("top-tab-admin"),
  topTabSettings: document.getElementById("top-tab-settings"),
  topPanelTranscripts: document.getElementById("top-panel-transcripts"),
  topPanelWatched: document.getElementById("top-panel-watched"),
  topPanelLibrary: document.getElementById("top-panel-library"),
  topPanelAdmin: document.getElementById("top-panel-admin"),
  topPanelSettings: document.getElementById("top-panel-settings"),
  detailModal: document.getElementById("detail-modal"),
  detailTitle: document.getElementById("detail-title"),
  detailBody: document.getElementById("detail-body"),
  detailClose: document.getElementById("detail-close"),
  // Sync-all-local-fails button (Failed tab, Capture panel).
  syncAllFails: document.getElementById("sync-all-fails"),
  syncAllFailsCount: document.getElementById("sync-all-fails-count"),
  syncAllFailsStatus: document.getElementById("sync-all-fails-status"),
  // Server-error banner (Admin panel top).
  serverErrorBanner: document.getElementById("server-error-banner"),
  serverErrorBannerMessage: document.getElementById("server-error-banner-message"),
  serverErrorBannerDismiss: document.getElementById("server-error-banner-dismiss"),
  // Admin Failed subtab.
  adminSubtabFailqueue: document.getElementById("admin-subtab-failqueue"),
  adminPanelFailqueue: document.getElementById("admin-panel-failqueue"),
  adminFailqueueRefresh: document.getElementById("admin-failqueue-refresh"),
  adminFailqueueCounters: document.getElementById("admin-failqueue-counters"),
  adminFailqueueChannel: document.getElementById("admin-failqueue-channel"),
  adminFailqueueUser: document.getElementById("admin-failqueue-user"),
  adminFailqueueReason: document.getElementById("admin-failqueue-reason"),
  adminFailqueueState: document.getElementById("admin-failqueue-state"),
  adminFailqueueSearch: document.getElementById("admin-failqueue-search"),
  adminFailqueueSelectAll: document.getElementById("admin-failqueue-select-all"),
  adminFailqueueTerminateSelected: document.getElementById("admin-failqueue-terminate-selected"),
  adminFailqueueTerminateFiltered: document.getElementById("admin-failqueue-terminate-filtered"),
  adminFailqueueForceYtCheckSelected: document.getElementById("admin-failqueue-force-yt-check-selected"),
  adminFailqueueStatus: document.getElementById("admin-failqueue-status"),
  adminFailqueueTable: document.getElementById("admin-failqueue-table"),
  adminFailqueueTbody: document.getElementById("admin-failqueue-tbody"),
  adminFailqueuePrev: document.getElementById("admin-failqueue-prev"),
  adminFailqueueNext: document.getElementById("admin-failqueue-next"),
  adminFailqueuePageLabel: document.getElementById("admin-failqueue-page-label"),
  adminFailqueuePagesize: document.getElementById("admin-failqueue-pagesize"),
  adminFailqueueModal: document.getElementById("admin-failqueue-modal"),
  adminFailqueueModalTitle: document.getElementById("admin-failqueue-modal-title"),
  adminFailqueueModalSummary: document.getElementById("admin-failqueue-modal-summary"),
  adminFailqueueModalReason: document.getElementById("admin-failqueue-modal-reason"),
  adminFailqueueModalNote: document.getElementById("admin-failqueue-modal-note"),
  adminFailqueueModalConfirm: document.getElementById("admin-failqueue-modal-confirm"),
  adminFailqueueModalCancel: document.getElementById("admin-failqueue-modal-cancel"),
  adminFailqueueModalClose: document.getElementById("admin-failqueue-modal-close"),
};

let watchlist = [];
let cloudStats = null;   // {available, claimed, total} or null; updated by claim-poll
let syncAllInFlight = false;

let state = { queue: [], settings: defaultSettings(), batch: { state: "idle", currentId: null } };
let activeTab = null;
let renderPending = false;
let currentTab = "active"; // "active" | "unsynced" | "failed" | "cloud"
let cloudItems = null;     // cached items from GET /queue when on Cloud tab
let cloudLastFetch = 0;

function defaultSettings() {
  return {
    lang: "en",
    includeTimestamps: false,
    downloadMode: "individual",
    delayMs: 4000,
    apiUrl: "",
    apiKey: "",
    autoSyncCloud: false,
    syncDownloadQueue: false,
  };
}

function send(msg) {
  return chrome.runtime.sendMessage(msg).catch((e) => console.warn("sendMessage", msg, e));
}

async function init() {
  const stored = await chrome.storage.local.get(["queue", "settings", "batch", "uiHidden", "hideCompleted", "cloudQueueBackfillInProgress", "transcriptBackfillInProgress"]);
  state.queue = stored.queue || [];
  state.settings = { ...defaultSettings(), ...(stored.settings || {}) };
  state.batch = stored.batch || { state: "idle", currentId: null };
  applyBackfillSpinner(!!stored.cloudQueueBackfillInProgress);
  applyAutoSyncSpinner(!!stored.transcriptBackfillInProgress);
  els.showOverlay.checked = !stored.uiHidden;
  els.hideCompleted.checked = !!stored.hideCompleted;
  applySettingsToUi();

  // The pin button only makes sense in the transient toolbar popup —
  // hide it when we're already running inside the side panel.
  const inPanel = new URLSearchParams(location.search).get("panel") === "1";
  if (inPanel) els.detach.classList.add("hidden");

  await refreshActiveTab();
  syncCloudPollToBatch();  // pick up any batch that was already running
  scheduleRender();

  // Keep activeTab in sync when the user switches tabs in the main window,
  // since this UI may live in a detached popup window.
  chrome.tabs.onActivated.addListener(refreshActiveTab);
  chrome.tabs.onUpdated.addListener((_id, info) => { if (info.url) refreshActiveTab(); });
  chrome.windows.onFocusChanged.addListener(refreshActiveTab);

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes.queue) state.queue = changes.queue.newValue || [];
    if (changes.settings) state.settings = { ...defaultSettings(), ...(changes.settings.newValue || {}) };
    if (changes.batch) {
      state.batch = changes.batch.newValue || { state: "idle", currentId: null };
      syncCloudPollToBatch();  // start/stop 30s poll when batch starts/stops
    }
    if (changes.uiHidden) els.showOverlay.checked = !changes.uiHidden.newValue;
    if (changes.hideCompleted) els.hideCompleted.checked = !!changes.hideCompleted.newValue;
    if (changes.cloudQueueBackfillInProgress) {
      applyBackfillSpinner(!!changes.cloudQueueBackfillInProgress.newValue);
    }
    if (changes.transcriptBackfillInProgress) {
      applyAutoSyncSpinner(!!changes.transcriptBackfillInProgress.newValue);
    }
    if (changes.settings) {
      applySettingsToUi();
      refreshAdminVisibility();  // re-check whoami when apiKey/apiUrl change
    }
    scheduleRender();
  });
}

function applyBackfillSpinner(on) {
  els.syncDlSpinner.classList.toggle("hidden", !on);
}

function applyAutoSyncSpinner(on) {
  els.autoSyncSpinner.classList.toggle("hidden", !on);
}

function updateAddButtons() {
  const url = activeTab?.url || "";
  els.addVideo.disabled = !WATCH_RE.test(url);
  els.addChannel.disabled = !CHANNEL_RE.test(url);
  els.watchCurrent.disabled = !CHANNEL_RE.test(url);
}

async function refreshActiveTab() {
  // Prefer the active tab in the CURRENT window (the one hosting this
  // popup / side panel) over any-window scans — otherwise with multiple
  // Chrome windows open we'd pick an arbitrary one and the add-channel
  // button would stay disabled when the user is actually on a channel page.
  let tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  let tab = tabs.find((t) => t.url && !t.url.startsWith(chrome.runtime.getURL("")));
  if (!tab) {
    // Fallback: last-focused normal window (handles the case where the
    // popup itself is the "current" window, e.g. side panel opened from
    // a non-browser context).
    tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    tab = tabs.find((t) => t.url && !t.url.startsWith(chrome.runtime.getURL("")));
  }
  activeTab = tab || null;
  updateAddButtons();
}

function applySettingsToUi() {
  const s = state.settings;
  els.lang.value = s.lang ?? "en";
  els.timestamps.checked = !!s.includeTimestamps;
  const secs = Math.max(2, Math.min(20, Math.round((s.delayMs ?? 4000) / 1000)));
  els.delay.value = String(secs);
  els.delayVal.textContent = String(secs);
  els.apiUrl.value = s.apiUrl ?? "";
  els.apiKey.value = s.apiKey ?? "";
  els.autoSync.checked = !!s.autoSyncCloud;
  els.syncDownloadQueue.checked = !!s.syncDownloadQueue;
}

function scheduleRender() {
  if (renderPending) return;
  renderPending = true;
  setTimeout(() => { renderPending = false; render(); }, 80);
}

function counts() {
  const c = { pending: 0, running: 0, done: 0, failed: 0, skipped: 0 };
  for (const it of state.queue) if (c[it.status] != null) c[it.status]++;
  return c;
}

function render() {
  const c = counts();
  const unsyncedCount = state.queue.filter(
    (it) => it.status === "done" && !it.syncedAt
  ).length;

  // Tab chrome: reflect which tab is selected + label counts (Bootstrap
  // nav-tabs uses `.active` on the `.nav-link`).
  els.tabActive.classList.toggle("active", currentTab === "active");
  els.tabUnsynced.classList.toggle("active", currentTab === "unsynced");
  els.tabFailed.classList.toggle("active", currentTab === "failed");
  els.tabCloud.classList.toggle("active", currentTab === "cloud");
  els.tabActive.textContent = "Active";
  els.tabUnsynced.textContent = unsyncedCount > 0 ? `Unsynced (${unsyncedCount})` : "Unsynced";
  els.tabFailed.textContent = c.failed > 0 ? `Failed (${c.failed})` : "Failed";
  const cloudTotal = cloudStats?.total ?? null;
  els.tabCloud.textContent = cloudTotal != null ? `Cloud Queue (${cloudTotal})` : "Cloud Queue";

  // If user lands on Unsynced but cloud sync isn't configured, show a hint
  // in the tab via its title. (Tab itself stays visible as a navigation aid.)
  const cloudReady = !!(state.settings.apiUrl && state.settings.apiKey);
  els.tabUnsynced.title = cloudReady
    ? "Transcripts done locally but not yet posted to the cloud API"
    : "Configure API URL + key in Settings to enable cloud sync";

  // Refresh button is only meaningful on the Cloud Queue tab. Hide by
  // default; the cloud branch re-shows it below.
  els.refreshCloud.classList.add("hidden");
  // Search field shows on Active and Cloud Queue tabs (the two list views).
  // Wrapper is what we hide so the absolutely-positioned count badge
  // disappears with it.
  const searchable = currentTab === "active" || currentTab === "cloud";
  els.queueSearchWrap.classList.toggle("hidden", !searchable);

  // Header + list contents depend on the selected tab.
  els.queueList.innerHTML = "";
  let visible;
  if (currentTab === "failed") {
    els.hideCompletedRow.classList.add("hidden");
    visible = state.queue.filter((it) => it.status === "failed");
    els.queueHeader.textContent = visible.length
      ? `Failed: ${visible.length} item${visible.length === 1 ? "" : "s"}`
      : "Failed: none";
  } else if (currentTab === "unsynced") {
    els.hideCompletedRow.classList.add("hidden");
    visible = state.queue.filter((it) => it.status === "done" && !it.syncedAt);
    els.queueHeader.textContent = visible.length
      ? `Unsynced: ${visible.length} item${visible.length === 1 ? "" : "s"}` +
        (cloudReady ? "" : " — cloud sync not configured")
      : "Unsynced: none — all done items have been synced";
  } else if (currentTab === "cloud") {
    els.hideCompletedRow.classList.add("hidden");
    els.refreshCloud.classList.remove("hidden");
    if (!cloudReady) {
      els.queueList.innerHTML = "";
      els.queueHeader.textContent = "Cloud Queue — configure API URL + key in Settings";
      renderWatchlist();
      return;
    }
    els.queueList.innerHTML = "";
    if (!cloudItems) {
      els.queueHeader.textContent = "Cloud Queue — loading…";
      fetchCloudItems();
      renderWatchlist();
      return;
    }
    const a = cloudStats?.available ?? 0, cl = cloudStats?.claimed ?? 0;
    els.queueHeader.textContent = `Cloud Queue: ${a} available · ${cl} claimed`;
    // Apply the shared search filter to cloud rows, matching title /
    // channel / from_watchlist. Badge count is set below the main render.
    const qCloud = (els.queueSearch.value || "").trim().toLowerCase();
    const cloudVisible = qCloud
      ? cloudItems.filter((it) =>
          (it.title || "").toLowerCase().includes(qCloud)
          || (it.channel || "").toLowerCase().includes(qCloud)
          || (it.from_watchlist || "").toLowerCase().includes(qCloud)
        )
      : cloudItems;
    for (const it of cloudVisible) els.queueList.appendChild(renderCloudRow(it));
    if (qCloud) {
      els.queueSearchCount.textContent = String(cloudVisible.length);
      els.queueSearchCount.classList.remove("hidden");
    } else {
      els.queueSearchCount.classList.add("hidden");
    }
    renderWatchlist();
    return;
  } else {
    els.hideCompletedRow.classList.remove("hidden");
    const parts = [`${c.pending} pending`, `${c.running} running`, `${c.done} done`];
    if (c.skipped) parts.push(`${c.skipped} skipped`);
    if (state.settings.syncDownloadQueue && cloudStats?.available != null) {
      parts.push(`${cloudStats.available} in cloud`);
    }
    els.queueHeader.textContent = `Queue: ${parts.join(" · ")}`;
    // Match count rendered as a badge inside the search input. Counts
    // items that would actually be visible — so when "Hide completed" is
    // on, done items don't inflate the count.
    const qNow = (els.queueSearch.value || "").trim();
    if (qNow) {
      const hideDone = els.hideCompleted.checked;
      const matchCount = state.queue.filter((it) => {
        if (it.status === "failed") return false;
        if (hideDone && it.status === "done") return false;
        const needle = qNow.toLowerCase();
        return (it.title || "").toLowerCase().includes(needle)
          || (it.channel || "").toLowerCase().includes(needle)
          || (it.channelHandle || "").toLowerCase().includes(needle);
      }).length;
      els.queueSearchCount.textContent = String(matchCount);
      els.queueSearchCount.classList.remove("hidden");
    } else {
      els.queueSearchCount.classList.add("hidden");
    }

    // Active tab excludes failed items (they live in the Failed tab).
    // Sort by addedAt ascending so cloud-claimed and local-added items
    // interleave in predictable FIFO order regardless of source.
    const q = (els.queueSearch.value || "").trim().toLowerCase();
    const matchesSearch = (it) => {
      if (!q) return true;
      return (it.title || "").toLowerCase().includes(q)
        || (it.channel || "").toLowerCase().includes(q)
        || (it.channelHandle || "").toLowerCase().includes(q);
    };
    const base = state.queue
      .filter((it) => it.status !== "failed")
      .filter(matchesSearch)
      .slice()
      .sort((a, b) => (a.addedAt ?? 0) - (b.addedAt ?? 0));
    if (els.hideCompleted.checked) {
      const notDone = base.filter((it) => it.status !== "done");
      const running = notDone.filter((it) => it.status === "running");
      const rest = notDone.filter((it) => it.status !== "running");
      // When the queue is fully drained (no pending/running), drop the
      // last-done row too so the list ends up empty instead of leaving
      // a stale "just completed" item hanging around.
      if (notDone.length === 0) {
        visible = [];
      } else {
        const done = base.filter((it) => it.status === "done");
        const lastDone = done.reduce(
          (a, b) => (a && (a.completedAt ?? 0) >= (b.completedAt ?? 0) ? a : b),
          null
        );
        visible = lastDone ? [lastDone, ...running, ...rest] : [...running, ...rest];
      }
    } else {
      visible = base;
    }
  }
  for (const it of visible) els.queueList.appendChild(renderRow(it));

  const bs = state.batch.state;
  if (bs === "running") {
    els.start.textContent = "Pause";
    els.start.classList.add("paused");
    els.start.disabled = false;
  } else if (bs === "paused") {
    els.start.textContent = "Resume";
    els.start.classList.add("paused");
    els.start.disabled = false;
  } else {
    els.start.classList.remove("paused");
    const retryable = c.failed + c.skipped;
    if (c.pending > 0) {
      els.start.textContent = "Start";
      els.start.disabled = false;
      els.start.dataset.action = "start";
    } else if (retryable > 0) {
      els.start.textContent = `Retry failed / skipped (${retryable})`;
      els.start.disabled = false;
      els.start.dataset.action = "retry-all-and-start";
    } else {
      els.start.textContent = "Start";
      els.start.disabled = true;
      els.start.dataset.action = "start";
    }
  }
  els.clear.disabled = bs === "running" || state.queue.length === 0;

  // Start/Pause/Resume only makes sense on the Active tab — the other tabs
  // have their own tab-action button (Retry failed, Sync all to cloud).
  els.start.classList.toggle("hidden", currentTab !== "active");

  // Download only belongs on the Active tab. Failed has nothing downloadable;
  // Unsynced's action is to push to the cloud, not save locally.
  if (c.done > 0 && currentTab === "active") {
    els.downloadZip.classList.remove("hidden");
    els.downloadZip.textContent = `Download transcripts (${c.done})`;
  } else {
    els.downloadZip.classList.add("hidden");
  }

  // Overflow menu item: "Retry failed & resume" is only useful on the Active
  // tab (Failed tab already has it as the primary tab-action). Hide otherwise.
  const retryableCount = c.failed + c.skipped;
  if (currentTab === "active" && retryableCount > 0) {
    els.menuRetryFailed.classList.remove("hidden");
    els.menuRetryFailed.textContent = `Retry failed & resume (${retryableCount})`;
  } else {
    els.menuRetryFailed.classList.add("hidden");
  }

  // Contextual action button — its label + handler depend on the active tab.
  // Active: nothing (Start is already the primary action).
  // Failed: retry failed/skipped and resume the batch.
  // Unsynced: sync all unsynced done items to the cloud (if configured).
  const retryable = c.failed + c.skipped;
  if (currentTab === "failed") {
    els.tabAction.classList.remove("hidden");
    els.tabAction.textContent = `Retry failed & resume (${retryable})`;
    els.tabAction.disabled = retryable === 0;
    els.tabAction.dataset.action = "retry-all";
  } else if (currentTab === "unsynced" && cloudReady) {
    els.tabAction.classList.remove("hidden");
    els.tabAction.textContent = `Sync all to cloud (${unsyncedCount})`;
    // Don't re-enable the button if a sync is still in flight.
    els.tabAction.disabled = syncAllInFlight || unsyncedCount === 0;
    els.tabAction.dataset.action = "sync-all";
  } else {
    els.tabAction.classList.add("hidden");
    els.tabAction.dataset.action = "";
  }

  renderWatchlist();
}

function renderWatchlist() {
  els.watchlist.innerHTML = "";
  for (const ch of watchlist) {
    const row = document.createElement("div");
    row.className = "wrow";

    const body = document.createElement("div");
    body.className = "body";
    const name = document.createElement("span");
    name.className = "title";
    name.textContent = ch.displayName || ch.handle || ch.channelId;
    name.title = ch.url || "";
    if (ch.url) name.addEventListener("click", () => chrome.tabs.create({ url: ch.url, active: true }));
    body.appendChild(name);
    row.appendChild(body);

    const actions = document.createElement("div");
    actions.className = "actions";

    const feedBtn = document.createElement("button");
    feedBtn.className = "icon";
    feedBtn.textContent = "\u{1F4C4}";  // 📄
    feedBtn.title = "View RSS feed (formatted)";
    feedBtn.addEventListener("click", () => {
      if (!ch.channelId) return;
      const url = chrome.runtime.getURL(`feed-viewer.html?channel_id=${encodeURIComponent(ch.channelId)}`);
      chrome.tabs.create({ url, active: true });
    });
    actions.appendChild(feedBtn);

    const rm = document.createElement("button");
    rm.className = "icon";
    rm.textContent = "\u00d7";
    rm.title = "Remove from watchlist";
    rm.addEventListener("click", async () => {
      rm.disabled = true;
      const res = await send({ type: "remove-watched", channelId: ch.channelId });
      if (res?.ok) {
        await loadWatchlist({ forceRefresh: true });
      } else {
        showWatchStatus(`Remove failed: ${res?.error || "unknown"}`, true);
        rm.disabled = false;
      }
    });
    actions.appendChild(rm);
    row.appendChild(actions);

    els.watchlist.appendChild(row);
  }
  els.checkWatchlist.classList.toggle("hidden", watchlist.length === 0);
  els.checkWatchlist.textContent =
    watchlist.length === 0 ? "Check channels for new videos" : `Check ${watchlist.length} channel${watchlist.length === 1 ? "" : "s"} for new videos`;
}

// Fetch the shared watchlist from the cloud and re-render. Silent by default —
// on error, writes the message to the status line and leaves the list empty.
async function loadWatchlist({ forceRefresh = false } = {}) {
  try {
    const res = await send({ type: "list-watchlist", forceRefresh });
    if (res?.ok) {
      watchlist = res.channels || [];
      scheduleRender();
    } else {
      watchlist = [];
      const err = res?.error || "unknown error";
      els.watchlistStatus.textContent = `Couldn't load watchlist — ${err}`;
      els.watchlistStatus.style.color = "#c0392b";
      scheduleRender();
    }
  } catch (e) {
    watchlist = [];
    els.watchlistStatus.textContent = `Couldn't load watchlist — ${String(e?.message || e)}`;
    els.watchlistStatus.style.color = "#c0392b";
    scheduleRender();
  }
}

function renderRow(it) {
  const row = document.createElement("div");
  row.className = "qrow";

  const badge = document.createElement("span");
  badge.className = `badge ${it.status || "pending"}`;
  badge.title = it.status;
  row.appendChild(badge);

  const body = document.createElement("div");
  body.className = "body";
  const titleLine = document.createElement("div");
  titleLine.className = "title-line";
  const title = document.createElement("span");
  title.className = "title";
  const localChannel = it.channel || it.channelHandle || "";
  const localTitle = it.title || it.url || it.videoId || "(untitled)";
  title.textContent = localChannel ? `${localChannel}: ${localTitle}` : localTitle;
  title.title = localTitle;
  if (it.url) {
    title.addEventListener("click", () => chrome.tabs.create({ url: it.url, active: true }));
  }
  titleLine.appendChild(title);
  if (it.source === "cloud") {
    const badge = document.createElement("span");
    badge.className = "origin-badge cloud";
    badge.textContent = "cloud";
    badge.title = "Claimed from the shared cloud queue";
    titleLine.appendChild(badge);
  }
  body.appendChild(titleLine);
  // Privacy: cloud-sourced items don't display who added them. The cloud
  // badge on the title line is enough signal that this came from the pool.
  if (it.status === "failed" && it.error) {
    const err = document.createElement("div");
    err.className = "err";
    err.textContent = it.error;
    body.appendChild(err);
  }
  row.appendChild(body);

  const actions = document.createElement("div");
  actions.className = "actions";
  if (it.status !== "running") {
    const startHere = document.createElement("button");
    startHere.className = "icon";
    startHere.textContent = "\u25B6";
    startHere.title = "Continue from here";
    startHere.addEventListener("click", () => send({ type: "start-from", id: it.id }));
    actions.appendChild(startHere);
  }
  if (it.status === "done") {
    const dl = document.createElement("button");
    dl.className = "icon";
    dl.textContent = "\u2B07";
    dl.title = "Download transcript";
    dl.addEventListener("click", () => send({ type: "download-one", id: it.id }));
    actions.appendChild(dl);

    // Cloud-sync button: icon-only, shows sync state via the title tooltip.
    const sync = document.createElement("button");
    sync.className = "icon icon-sync";
    sync.textContent = "\u27F3"; // ⟳ sync (distinct from ↻ retry used on failed rows)
    if (it.syncError) {
      sync.title = `Sync failed: ${it.syncError} — click to retry`;
      sync.classList.add("err");
    } else if (it.syncedAt) {
      sync.title = `Synced ${new Date(it.syncedAt).toLocaleString()} — click to re-sync`;
      sync.classList.add("ok");
    } else {
      sync.title = "Sync this transcript to cloud";
    }
    sync.addEventListener("click", async () => {
      const res = await flushSettingsThen(() => send({ type: "sync-one", id: it.id }));
      if (res && res.error) showSyncStatus(`Sync failed: ${res.error}`, true);
      else if (res && res.ok) showSyncStatus("Synced ✓");
    });
    actions.appendChild(sync);
  }
  if (it.status === "failed") {
    const retry = document.createElement("button");
    retry.className = "icon";
    retry.textContent = "\u21bb";
    retry.title = "Retry";
    retry.addEventListener("click", () => send({ type: "retry", id: it.id }));
    actions.appendChild(retry);
  }
  const rm = document.createElement("button");
  rm.className = "icon";
  rm.textContent = "\u00d7";
  rm.title = "Remove";
  rm.addEventListener("click", () => send({ type: "remove", id: it.id }));
  actions.appendChild(rm);
  row.appendChild(actions);

  return row;
}

els.detach.addEventListener("click", async () => {
  try {
    const win = await chrome.windows.getCurrent();
    await chrome.sidePanel.open({ windowId: win.id });
  } catch (e) {
    console.warn("sidePanel.open failed", e);
  }
  window.close();
});

els.addVideo.addEventListener("click", async () => {
  els.addVideo.disabled = true;
  els.addStatus.textContent = "Adding…";
  try {
    // Pass tabId so the SW can inject grabCurrentVideoInfo into the page and
    // detect shorts by duration before enqueueing.
    const res = await send({
      type: "add-video",
      url: activeTab.url,
      title: activeTab.title,
      tabId: activeTab.id,
    });
    els.addStatus.textContent = addStatusMessage(res);
  } catch (e) {
    els.addStatus.textContent = `Error: ${e.message}`;
  } finally {
    setTimeout(() => (els.addStatus.textContent = ""), 3000);
    updateAddButtons();
  }
});

// Map an add-video response to a status line. Distinguishes:
//   - shorts blocked ("Can't add — this is a short.")
//   - local dedup ("Already in queue")
//   - newly added + cloud already had it ("Added — already in cloud queue")
//   - newly added + cloud accepted it ("Added")
//   - newly added + cloud sync off ("Added")
function addStatusMessage(res) {
  if (!res) return "Added";
  if (res.isShort) return "Can't add — this is a short.";
  if (res.deduped) return "Already in queue";
  if (res.error) return `Error: ${res.error}`;
  if (res.cloud?.deduped) return "Added — already in cloud queue";
  return "Added";
}

// Status for batch adds (Add channel's videos, Check channels for new videos).
// Reports local count + cloud breakdown from the single batch POST. Appends
// "(N shorts skipped)" when the scraper filtered any short-form videos.
function batchAddStatusMessage(addedLocal, cloud, shortsSkipped) {
  const shorts = Number(shortsSkipped) || 0;
  const shortsTail = shorts > 0
    ? ` (${shorts} short${shorts === 1 ? "" : "s"} skipped)`
    : "";
  if (addedLocal === 0) {
    return shorts > 0 ? `No new videos${shortsTail}` : "No new videos";
  }
  const word = `video${addedLocal === 1 ? "" : "s"}`;
  if (!cloud) return `Added ${addedLocal} ${word}${shortsTail}`;
  if (cloud.error) return `Added ${addedLocal} ${word}${shortsTail} (cloud push failed: ${cloud.error})`;
  const c = cloud.added ?? 0;
  const d = cloud.deduped ?? 0;
  if (d === 0) return `Added ${addedLocal} ${word}${shortsTail}`;
  if (c === 0) return `Added ${addedLocal} ${word} — all already in cloud queue${shortsTail}`;
  return `Added ${addedLocal} ${word} (${c} new in cloud, ${d} already there)${shortsTail}`;
}

els.stopScrape.addEventListener("click", async () => {
  els.stopScrape.disabled = true;
  try { await chrome.runtime.sendMessage({ type: "scrape-stop" }); } catch {}
});

els.addChannel.addEventListener("click", async () => {
  els.addChannel.disabled = true;
  els.addStatus.textContent = "Scraping channel…";
  els.stopScrape.classList.remove("hidden");
  els.stopScrape.disabled = false;
  // Poll the SW on a timer instead of subscribing to broadcasts — avoids
  // parallel executeScript calls racing with the scraper's injection.
  const progressTimer = setInterval(async () => {
    try {
      const r = await chrome.runtime.sendMessage({ type: "get-scrape-progress" });
      if (r?.count != null) {
        els.addStatus.textContent = `Scraping channel… (${r.count} video${r.count === 1 ? "" : "s"})`;
      }
    } catch {}
  }, 700);
  try {
    const res = await chrome.runtime.sendMessage({ type: "scrape-and-add-channel", tabId: activeTab.id });
    if (res?.error) throw new Error(res.error);
    els.addStatus.textContent = batchAddStatusMessage(res?.added ?? 0, res?.cloud, res?.shortsSkipped);
  } catch (e) {
    els.addStatus.textContent = `Error: ${e.message}`;
  } finally {
    clearInterval(progressTimer);
    els.stopScrape.classList.add("hidden");
    setTimeout(() => (els.addStatus.textContent = ""), 2500);
    updateAddButtons();
  }
});

els.addUrlBtn.addEventListener("click", async () => {
  const raw = els.addUrl.value;
  const id = parseVideoId(raw);
  if (!id) {
    els.addStatus.textContent = "Invalid URL or video ID.";
    return;
  }
  const url = `https://www.youtube.com/watch?v=${id}`;
  els.addUrlBtn.disabled = true;
  els.addStatus.textContent = "Adding…";
  try {
    const res = await send({ type: "add-video", url, title: "" });
    els.addStatus.textContent = addStatusMessage(res);
    // Only clear the input on a true new-add; leave it so user can see
    // what they pasted if it was a dedup.
    if (res && !res.deduped && !res.error) els.addUrl.value = "";
  } catch (e) {
    els.addStatus.textContent = `Error: ${e.message}`;
  } finally {
    els.addUrlBtn.disabled = false;
    setTimeout(() => (els.addStatus.textContent = ""), 1500);
  }
});

els.addUrl.addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    e.preventDefault();
    els.addUrlBtn.click();
  }
});

els.start.addEventListener("click", () => {
  const bs = state.batch.state;
  if (bs === "running") {
    send({ type: "pause" });
    // Pause = batch stops, but user likely wants an up-to-date cloud view
    // since they just did some work. Fire one immediate stats/claim refresh
    // — normal 30s interval is about to stop.
    pollClaimFromCloud();
  } else if (bs === "paused") {
    send({ type: "resume" });
  } else {
    send({ type: els.start.dataset.action || "start" });
  }
});

els.tabAction.addEventListener("click", async () => {
  const action = els.tabAction.dataset.action;
  if (action === "retry-all") {
    send({ type: "retry-all-and-start" });
  } else if (action === "sync-all") {
    syncAllInFlight = true;
    els.tabAction.classList.add("loading");
    els.tabAction.disabled = true;
    showSyncStatus("Syncing…");
    try {
      const res = await flushSettingsThen(() => send({ type: "sync-all" }));
      if (res && res.error) showSyncStatus(`Sync failed: ${res.error}`, true);
      else if (res) showSyncStatus(`Synced ${res.synced ?? 0} ✓`);
    } finally {
      syncAllInFlight = false;
      els.tabAction.classList.remove("loading");
      // render() will compute the correct disabled state on next tick
      scheduleRender();
    }
  }
});

// Top-level tab switcher (Capture / Auto-Feeds / Library / Settings).
// Internal keys kept as the old names to minimise code churn — the user-
// facing labels live in popup.html, not here.
function selectTopTab(which) {
  const map = {
    transcripts: { tab: els.topTabTranscripts, panel: els.topPanelTranscripts },
    watched:     { tab: els.topTabWatched,     panel: els.topPanelWatched },
    library:     { tab: els.topTabLibrary,     panel: els.topPanelLibrary },
    admin:       { tab: els.topTabAdmin,       panel: els.topPanelAdmin },
    settings:    { tab: els.topTabSettings,    panel: els.topPanelSettings },
  };
  for (const [name, { tab, panel }] of Object.entries(map)) {
    const on = name === which;
    tab.classList.toggle("active", on);
    panel.classList.toggle("hidden", !on);
  }
}
els.topTabTranscripts.addEventListener("click", () => selectTopTab("transcripts"));
els.topTabWatched.addEventListener("click", () => {
  selectTopTab("watched");
  loadWatchlist();  // cloud fetch (cache hit if within TTL)
});
els.topTabLibrary.addEventListener("click", () => selectTopTab("library"));
els.topTabAdmin.addEventListener("click", () => {
  selectTopTab("admin");
  fetchAdminQueue();
  fetchAdminFailed();
});
els.topTabSettings.addEventListener("click", () => selectTopTab("settings"));

// Admin tab is UI-gated on the server-supplied `is_admin` flag. This is not
// real auth (a curious user can un-hide the tab via devtools); any admin
// action still has to be enforced server-side. The gate just avoids
// cluttering the popup for non-admin users.
//
// Note: until the server consistently returns `is_admin`, we also accept the
// legacy `name === "Pat"` signal as a transitional fallback. Admin-only
// fetches still won't fire until `/whoami` answers — per the plan we must
// NOT speculatively hit `/admin/*` before confirming admin status.
let isAdminResolved = false;

async function refreshAdminVisibility() {
  try {
    const res = await send({ type: "whoami" });
    const isAdmin = !!(res?.ok && (res.is_admin === true || res.name === "Pat"));
    isAdminResolved = isAdmin;
    els.topTabAdmin.classList.toggle("hidden", !isAdmin);
    els.adminSubtabFailqueue.classList.toggle("hidden", !isAdmin);
    // If the tab was active but we lost admin, fall back to Capture.
    if (!isAdmin && els.topTabAdmin.classList.contains("active")) {
      selectTopTab("transcripts");
    }
    if (!isAdmin) {
      els.adminPanelFailqueue.classList.add("hidden");
    }
  } catch {
    isAdminResolved = false;
    els.topTabAdmin.classList.add("hidden");
    els.adminSubtabFailqueue.classList.add("hidden");
  }
}
refreshAdminVisibility();

// ---------- Admin tab: cloud queue management ----------------------------
// Re-uses the existing `list-cloud-queue` message for the data fetch and
// layers its own search / delete affordances over the top. Keeps the Cloud
// Queue view in Capture read-only while giving admins destructive powers here.

let adminQueueItems = [];
let adminFetchInFlight = false;

async function fetchAdminQueue() {
  if (adminFetchInFlight) return;
  adminFetchInFlight = true;
  els.adminQueueHeader.textContent = "Loading…";
  try {
    const res = await send({ type: "list-cloud-queue" });
    if (!res?.ok) {
      els.adminQueueHeader.textContent = `Error: ${res?.error || "unknown"}`;
      adminQueueItems = [];
      els.adminQueueList.innerHTML = "";
      return;
    }
    adminQueueItems = res.items || [];
    renderAdminQueue();
  } finally {
    adminFetchInFlight = false;
  }
}

function filteredAdminItems() {
  const q = (els.adminQueueSearch.value || "").trim().toLowerCase();
  if (!q) return adminQueueItems;
  return adminQueueItems.filter((it) =>
    (it.title || "").toLowerCase().includes(q)
    || (it.channel || "").toLowerCase().includes(q)
    || (it.from_watchlist || "").toLowerCase().includes(q)
    || (it.video_id || "").toLowerCase().includes(q)
  );
}

function renderAdminQueue() {
  els.adminQueueList.innerHTML = "";
  const visible = filteredAdminItems();

  els.adminQueueHeader.textContent = adminQueueItems.length === 0
    ? "Cloud queue is empty"
    : `${visible.length} of ${adminQueueItems.length} shown`;

  const q = (els.adminQueueSearch.value || "").trim();
  if (q) {
    els.adminQueueSearchCount.textContent = String(visible.length);
    els.adminQueueSearchCount.classList.remove("hidden");
  } else {
    els.adminQueueSearchCount.classList.add("hidden");
  }

  els.adminDeleteFiltered.classList.toggle("hidden", visible.length === 0);
  els.adminDeleteFiltered.textContent =
    q ? `Delete all ${visible.length} filtered` : `Delete all ${visible.length}`;

  for (const it of visible) {
    els.adminQueueList.appendChild(renderAdminRow(it));
  }
}

// Shared row renderer for both admin sections — Cloud Queue and Failed Queue
// use identical layout / meta / delete affordance. Caller supplies the
// on-delete callback (so each section can splice its own module-level list)
// and the status line element to surface per-row errors.
function renderAdminRowGeneric(it, { onDeleted, statusEl, deleteTitle }) {
  const row = document.createElement("div");
  row.className = "qrow";

  // Same colour scheme as the Cloud Queue tab: claimed → "running"
  // (orange), available → "pending" (gray). Red reserved for dead-lettered
  // rows (fail_count >= 3) that the server won't re-claim.
  const badge = document.createElement("span");
  const isDead = (it.fail_count ?? 0) >= 3 || it.status === "failed";
  const cls = isDead ? "failed" : (it.status === "claimed" ? "running" : "pending");
  badge.className = `badge ${cls}`;
  badge.title = isDead
    ? `dead-lettered${it.fail_count ? ` (${it.fail_count} failed attempts)` : ""}`
    : (it.status || "");
  row.appendChild(badge);

  const body = document.createElement("div");
  body.className = "body";
  const titleLine = document.createElement("div");
  titleLine.className = "title-line";
  const title = document.createElement("span");
  title.className = "title";
  const ch = it.channel || it.from_watchlist || "";
  const t = it.title || it.url || it.video_id || "(untitled)";
  title.textContent = ch ? `${ch}: ${t}` : t;
  title.title = t;
  if (it.url) {
    title.addEventListener("click", () => chrome.tabs.create({ url: it.url, active: true }));
  }
  titleLine.appendChild(title);
  body.appendChild(titleLine);

  const meta = document.createElement("div");
  meta.className = "row-meta";
  const parts = [];
  if (it.status === "claimed") parts.push("being scraped");
  if (it.fail_count) {
    parts.push(
      isDead
        ? `dead-lettered (${it.fail_count} fails)`
        : `${it.fail_count} failed attempt${it.fail_count === 1 ? "" : "s"}`
    );
  }
  if (it.from_watchlist) parts.push(`from @${it.from_watchlist}`);
  meta.textContent = parts.join(" · ");
  if (parts.length) body.appendChild(meta);

  row.appendChild(body);

  const actions = document.createElement("div");
  actions.className = "actions";
  const rm = document.createElement("button");
  rm.className = "icon";
  rm.textContent = "\u00d7";
  rm.title = deleteTitle || "Delete from cloud queue";
  rm.addEventListener("click", async () => {
    rm.disabled = true;
    const res = await send({ type: "admin-delete-queue", videoIds: [it.video_id] });
    if (res?.ok) {
      onDeleted(it);
    } else {
      statusEl.textContent = `Error: ${res?.error || "unknown"}`;
      statusEl.style.color = "#c0392b";
      rm.disabled = false;
      setTimeout(() => { statusEl.textContent = ""; statusEl.style.color = ""; }, 5000);
    }
  });
  actions.appendChild(rm);
  row.appendChild(actions);

  return row;
}

function renderAdminRow(it) {
  return renderAdminRowGeneric(it, {
    onDeleted: (row) => {
      adminQueueItems = adminQueueItems.filter((x) => x.video_id !== row.video_id);
      renderAdminQueue();
    },
    statusEl: els.adminQueueStatus,
    deleteTitle: "Delete from cloud queue",
  });
}

els.adminQueueSearch.addEventListener("input", renderAdminQueue);
els.refreshAdminQueue.addEventListener("click", () => {
  els.refreshAdminQueue.disabled = true;
  fetchAdminQueue().finally(() => { els.refreshAdminQueue.disabled = false; });
});
els.adminDeleteFiltered.addEventListener("click", async () => {
  const visible = filteredAdminItems();
  if (!visible.length) return;
  if (!confirm(`Delete ${visible.length} item${visible.length === 1 ? "" : "s"} from the shared cloud queue? This can't be undone.`)) return;
  els.adminDeleteFiltered.disabled = true;
  try {
    const videoIds = visible.map((it) => it.video_id).filter(Boolean);
    const res = await send({ type: "admin-delete-queue", videoIds });
    if (res?.ok) {
      const deletedSet = new Set(videoIds);
      adminQueueItems = adminQueueItems.filter((x) => !deletedSet.has(x.video_id));
      els.adminQueueStatus.textContent = `Deleted ${res.deleted} row${res.deleted === 1 ? "" : "s"}.`;
      els.adminQueueStatus.style.color = "";
      setTimeout(() => { els.adminQueueStatus.textContent = ""; }, 5000);
      renderAdminQueue();
    } else {
      els.adminQueueStatus.textContent = `Error: ${res?.error || "unknown"}`;
      els.adminQueueStatus.style.color = "#c0392b";
    }
  } finally {
    els.adminDeleteFiltered.disabled = false;
  }
});

// ---------- Admin tab: failed queue (server-side dead letters) -----------
// Same UX as the Cloud Queue admin section, but pulls `status_filter=failed`
// from the server. Reuses the `admin-delete-queue` message because the
// server's POST /admin/queue/delete is status-agnostic (deletes by video_id).

let adminFailedItems = [];
let adminFailedFetchInFlight = false;

async function fetchAdminFailed() {
  if (adminFailedFetchInFlight) return;
  adminFailedFetchInFlight = true;
  els.adminFailedHeader.textContent = "Loading…";
  try {
    const res = await send({ type: "list-cloud-queue", statusFilter: "failed", includeFailed: true });
    if (!res?.ok) {
      els.adminFailedHeader.textContent = `Error: ${res?.error || "unknown"}`;
      adminFailedItems = [];
      els.adminFailedList.innerHTML = "";
      return;
    }
    adminFailedItems = res.items || [];
    renderAdminFailed();
  } finally {
    adminFailedFetchInFlight = false;
  }
}

function filteredAdminFailedItems() {
  const q = (els.adminFailedSearch.value || "").trim().toLowerCase();
  if (!q) return adminFailedItems;
  return adminFailedItems.filter((it) =>
    (it.title || "").toLowerCase().includes(q)
    || (it.channel || "").toLowerCase().includes(q)
    || (it.from_watchlist || "").toLowerCase().includes(q)
    || (it.video_id || "").toLowerCase().includes(q)
  );
}

function renderAdminFailed() {
  els.adminFailedList.innerHTML = "";
  const visible = filteredAdminFailedItems();

  els.adminFailedHeader.textContent = adminFailedItems.length === 0
    ? "Failed queue is empty"
    : `${visible.length} of ${adminFailedItems.length} shown`;

  const q = (els.adminFailedSearch.value || "").trim();
  if (q) {
    els.adminFailedSearchCount.textContent = String(visible.length);
    els.adminFailedSearchCount.classList.remove("hidden");
  } else {
    els.adminFailedSearchCount.classList.add("hidden");
  }

  els.adminDeleteFailedFiltered.classList.toggle("hidden", visible.length === 0);
  els.adminDeleteFailedFiltered.textContent =
    q ? `Delete all ${visible.length} filtered` : `Delete all ${visible.length}`;

  for (const it of visible) {
    els.adminFailedList.appendChild(renderAdminFailedRow(it));
  }
}

function renderAdminFailedRow(it) {
  return renderAdminRowGeneric(it, {
    onDeleted: (row) => {
      adminFailedItems = adminFailedItems.filter((x) => x.video_id !== row.video_id);
      renderAdminFailed();
    },
    statusEl: els.adminFailedStatus,
    deleteTitle: "Delete from failed queue",
  });
}

els.adminFailedSearch.addEventListener("input", renderAdminFailed);
els.refreshAdminFailed.addEventListener("click", () => {
  els.refreshAdminFailed.disabled = true;
  fetchAdminFailed().finally(() => { els.refreshAdminFailed.disabled = false; });
});
els.adminDeleteFailedFiltered.addEventListener("click", async () => {
  const visible = filteredAdminFailedItems();
  if (!visible.length) return;
  if (!confirm(`Delete ${visible.length} item${visible.length === 1 ? "" : "s"} from the failed queue? This can't be undone.`)) return;
  els.adminDeleteFailedFiltered.disabled = true;
  try {
    const videoIds = visible.map((it) => it.video_id).filter(Boolean);
    const res = await send({ type: "admin-delete-queue", videoIds });
    if (res?.ok) {
      const deletedSet = new Set(videoIds);
      adminFailedItems = adminFailedItems.filter((x) => !deletedSet.has(x.video_id));
      els.adminFailedStatus.textContent = `Deleted ${res.deleted} row${res.deleted === 1 ? "" : "s"}.`;
      els.adminFailedStatus.style.color = "";
      setTimeout(() => { els.adminFailedStatus.textContent = ""; }, 5000);
      renderAdminFailed();
    } else {
      els.adminFailedStatus.textContent = `Error: ${res?.error || "unknown"}`;
      els.adminFailedStatus.style.color = "#c0392b";
    }
  } finally {
    els.adminDeleteFailedFiltered.disabled = false;
  }
});

els.refreshWatchlist.addEventListener("click", () => {
  els.refreshWatchlist.disabled = true;
  loadWatchlist({ forceRefresh: true }).finally(() => {
    els.refreshWatchlist.disabled = false;
  });
});

function selectSettingsTab(which) {
  const general = which === "general";
  els.settingsTabGeneral.classList.toggle("active", general);
  els.settingsTabCloud.classList.toggle("active", !general);
  els.settingsPanelGeneral.classList.toggle("hidden", !general);
  els.settingsPanelCloud.classList.toggle("hidden", general);
}
els.settingsTabGeneral.addEventListener("click", () => selectSettingsTab("general"));
els.settingsTabCloud.addEventListener("click", () => selectSettingsTab("cloud"));

function selectAdminTab(which) {
  const isQueue = which === "queue";
  const isFailqueue = which === "failqueue";
  const isAutoupdate = which === "autoupdate";
  const isYtapi = which === "ytapi";
  els.adminSubtabQueue.classList.toggle("active", isQueue);
  els.adminSubtabFailqueue.classList.toggle("active", isFailqueue);
  els.adminSubtabAutoupdate.classList.toggle("active", isAutoupdate);
  els.adminSubtabYtapi.classList.toggle("active", isYtapi);
  els.adminSubpanelQueue.classList.toggle("hidden", !isQueue);
  els.adminPanelFailqueue.classList.toggle("hidden", !isFailqueue);
  els.adminSubpanelAutoupdate.classList.toggle("hidden", !isAutoupdate);
  els.adminSubpanelYtapi.classList.toggle("hidden", !isYtapi);
  if (isFailqueue && isAdminResolved) {
    ensureFailqueueDistinctValues();
    fetchAdminFailqueue();
  }
  if (isAutoupdate) populateAutoupdateChannels();
  if (isYtapi) loadYtApiUsage();
}
els.adminSubtabQueue.addEventListener("click", () => selectAdminTab("queue"));
els.adminSubtabFailqueue.addEventListener("click", () => selectAdminTab("failqueue"));
els.adminSubtabAutoupdate.addEventListener("click", () => selectAdminTab("autoupdate"));
els.adminSubtabYtapi.addEventListener("click", () => selectAdminTab("ytapi"));


// ---------- Admin → YT API: show Cloud Monitoring usage ----------
function formatNum(n) {
  if (typeof n !== "number") return "—";
  return n.toLocaleString();
}

async function loadYtApiUsage() {
  els.ytapiStatus.textContent = "Loading…";
  els.ytapiStatus.style.color = "";
  try {
    const res = await send({ type: "fetch-yt-api-usage" });
    if (!res?.ok) {
      els.ytapiStatus.textContent = `Error — ${res?.error || "unknown error"}`;
      els.ytapiStatus.style.color = "#c0392b";
      return;
    }
    const d = res.data || {};
    const used = d.total_units_used ?? 0;
    const quota = d.daily_quota_limit ?? 0;
    const remaining = d.remaining ?? Math.max(0, quota - used);
    els.ytapiUsed.textContent = formatNum(used);
    els.ytapiRemaining.textContent = formatNum(remaining);
    els.ytapiQuota.textContent = formatNum(quota);
    const pct = quota > 0 ? Math.min(100, (used / quota) * 100) : 0;
    els.ytapiBar.style.width = pct + "%";
    els.ytapiBar.classList.remove("warn", "danger");
    if (pct >= 90) els.ytapiBar.classList.add("danger");
    else if (pct >= 70) els.ytapiBar.classList.add("warn");
    els.ytapiWindow.textContent = d.window_end_utc
      ? `Window: last ${d.window_hours || 24}h ending ${d.window_end_utc}`
      : "";
    els.ytapiStatus.textContent = d.note || "";
    els.ytapiStatus.style.color = "";
  } catch (e) {
    els.ytapiStatus.textContent = `Error — ${String(e?.message || e)}`;
    els.ytapiStatus.style.color = "#c0392b";
  }
}

els.ytapiRefresh?.addEventListener("click", () => loadYtApiUsage());


// ---------- Admin → Auto-Update: list missing videos for a watched channel --
async function populateAutoupdateChannels({ forceRefresh = false } = {}) {
  try {
    const res = await send({ type: "list-watchlist", forceRefresh });
    if (!res?.ok) {
      els.autoupdateStatus.textContent = `Couldn't load channels — ${res?.error || "unknown error"}`;
      els.autoupdateStatus.style.color = "#c0392b";
      return;
    }
    const channels = (res.channels || []).filter((c) => c.handle);
    const prev = els.autoupdateChannel.value;
    els.autoupdateChannel.innerHTML = "";
    if (!channels.length) {
      const opt = document.createElement("option");
      opt.value = "";
      opt.textContent = "No watched channels";
      els.autoupdateChannel.appendChild(opt);
      return;
    }
    channels.sort((a, b) =>
      (a.displayName || a.handle).localeCompare(b.displayName || b.handle),
    );
    for (const c of channels) {
      const opt = document.createElement("option");
      opt.value = c.handle;
      opt.textContent = `${c.displayName || c.handle} (@${c.handle})`;
      els.autoupdateChannel.appendChild(opt);
    }
    if (prev) els.autoupdateChannel.value = prev;
    els.autoupdateStatus.textContent = "";
    els.autoupdateStatus.style.color = "";
  } catch (e) {
    els.autoupdateStatus.textContent = `Couldn't load channels — ${String(e?.message || e)}`;
    els.autoupdateStatus.style.color = "#c0392b";
  }
}

let autoupdateCurrentItems = [];
let autoupdateCurrentHandle = "";

function renderAutoupdateMissing(items, handle) {
  els.autoupdateList.innerHTML = "";
  autoupdateCurrentItems = Array.isArray(items) ? items : [];
  autoupdateCurrentHandle = handle || "";
  if (!items.length) {
    els.autoupdateHeader.textContent = `No missing videos for @${handle} — corpus is up to date.`;
    els.autoupdateQueueAll?.classList.add("hidden");
    return;
  }
  els.autoupdateHeader.textContent = `${items.length} missing video${items.length === 1 ? "" : "s"} for @${handle}:`;
  els.autoupdateQueueAll?.classList.remove("hidden");
  for (const v of items) {
    const row = document.createElement("div");
    row.className = "qrow";
    const body = document.createElement("div");
    body.className = "body";
    const titleLine = document.createElement("div");
    titleLine.className = "title-line";
    const a = document.createElement("a");
    a.href = v.url;
    a.target = "_blank";
    a.rel = "noopener noreferrer";
    a.className = "title";
    a.textContent = v.title || v.video_id;
    titleLine.appendChild(a);
    body.appendChild(titleLine);
    const meta = document.createElement("div");
    meta.className = "row-meta";
    meta.textContent = `${v.published_at || "—"}  ·  ${v.video_id}`;
    body.appendChild(meta);
    row.appendChild(body);
    els.autoupdateList.appendChild(row);
  }
}

els.autoupdateRefreshChannels?.addEventListener("click", () =>
  populateAutoupdateChannels({ forceRefresh: true }),
);

els.autoupdateRun?.addEventListener("click", async () => {
  const handle = (els.autoupdateChannel.value || "").trim();
  if (!handle) {
    els.autoupdateStatus.textContent = "Pick a channel first.";
    els.autoupdateStatus.style.color = "#c0392b";
    return;
  }
  const limitNum = Math.max(1, Math.min(5000, parseInt(els.autoupdateLimit.value, 10) || 50));
  els.autoupdateRun.disabled = true;
  els.autoupdateStatus.textContent = "Checking…";
  els.autoupdateStatus.style.color = "";
  els.autoupdateHeader.textContent = "";
  els.autoupdateList.innerHTML = "";
  try {
    const res = await send({ type: "check-missing", handle, limit: limitNum });
    if (!res?.ok) {
      els.autoupdateStatus.textContent = `Error — ${res?.error || "unknown error"}`;
      els.autoupdateStatus.style.color = "#c0392b";
      return;
    }
    renderAutoupdateMissing(res.items || [], handle);
    els.autoupdateStatus.textContent = "";
  } catch (e) {
    els.autoupdateStatus.textContent = `Error — ${String(e?.message || e)}`;
    els.autoupdateStatus.style.color = "#c0392b";
  } finally {
    els.autoupdateRun.disabled = false;
  }
});

els.autoupdateQueueAll?.addEventListener("click", async () => {
  if (!autoupdateCurrentItems.length) return;
  els.autoupdateQueueAll.disabled = true;
  els.autoupdateStatus.textContent = "Adding to queue…";
  els.autoupdateStatus.style.color = "";
  try {
    const res = await send({
      type: "queue-add-missing",
      items: autoupdateCurrentItems,
      handle: autoupdateCurrentHandle,
    });
    if (!res?.ok) {
      els.autoupdateStatus.textContent = `Error — ${res?.error || "unknown error"}`;
      els.autoupdateStatus.style.color = "#c0392b";
      els.autoupdateQueueAll.disabled = false;
      return;
    }
    const added = res.added || 0;
    const deduped = res.deduped || 0;
    els.autoupdateStatus.textContent = `Queued ${added} video${added === 1 ? "" : "s"} (${deduped} were already in the queue).`;
    els.autoupdateStatus.style.color = "";
    els.autoupdateQueueAll.classList.add("hidden");
    els.autoupdateList.innerHTML = "";
    els.autoupdateHeader.textContent = "";
    autoupdateCurrentItems = [];
  } catch (e) {
    els.autoupdateStatus.textContent = `Error — ${String(e?.message || e)}`;
    els.autoupdateStatus.style.color = "#c0392b";
    els.autoupdateQueueAll.disabled = false;
  }
});

els.tabActive.addEventListener("click", () => {
  currentTab = "active";
  scheduleRender();
});
els.tabUnsynced.addEventListener("click", () => {
  currentTab = "unsynced";
  scheduleRender();
});
els.tabFailed.addEventListener("click", () => {
  currentTab = "failed";
  scheduleRender();
});
els.tabCloud.addEventListener("click", () => {
  currentTab = "cloud";
  cloudItems = null;           // always force a fresh list on tab activation
  pollClaimFromCloud();        // and refresh the stats immediately
  scheduleRender();
});

els.refreshCloud.addEventListener("click", async () => {
  els.refreshCloud.classList.add("spinning");
  els.refreshCloud.disabled = true;
  try {
    cloudItems = null;
    await Promise.all([fetchCloudItems(), pollClaimFromCloud()]);
  } finally {
    els.refreshCloud.classList.remove("spinning");
    els.refreshCloud.disabled = false;
  }
});

async function fetchCloudItems() {
  try {
    const res = await chrome.runtime.sendMessage({ type: "list-cloud-queue" });
    if (res?.ok) {
      cloudItems = res.items || [];
      cloudLastFetch = Date.now();
      scheduleRender();
    }
  } catch {
    // silent
  }
}

function renderCloudRow(it) {
  const row = document.createElement("div");
  row.className = "qrow";

  const badge = document.createElement("span");
  badge.className = `badge ${it.status === "claimed" ? "running" : "pending"}`;
  badge.title = it.status;
  row.appendChild(badge);

  const body = document.createElement("div");
  body.className = "body";
  const titleLine = document.createElement("div");
  titleLine.className = "title-line";
  const title = document.createElement("span");
  title.className = "title";
  const cloudChannel = it.channel || "";
  const cloudTitle = it.title || it.video_id || "(untitled)";
  title.textContent = cloudChannel ? `${cloudChannel}: ${cloudTitle}` : cloudTitle;
  title.title = cloudTitle;
  if (it.url) title.addEventListener("click", () => chrome.tabs.create({ url: it.url, active: true }));
  titleLine.appendChild(title);
  body.appendChild(titleLine);

  const meta = document.createElement("div");
  meta.className = "row-meta";
  const parts = [];
  // Privacy: no user names. Show status + failure count only.
  if (it.status === "claimed") parts.push("being scraped");
  if (it.fail_count) parts.push(`${it.fail_count} failed attempt${it.fail_count === 1 ? "" : "s"}`);
  if (it.from_watchlist) parts.push(`from @${it.from_watchlist}`);
  meta.textContent = parts.join(" · ");
  body.appendChild(meta);

  row.appendChild(body);
  return row;
}

els.clear.addEventListener("click", () => {
  setOverflowOpen(false);
  if (!state.queue.length) return;
  if (!confirm(`Clear all ${state.queue.length} items from the queue?`)) return;
  send({ type: "clear" });
});

els.menuRetryFailed.addEventListener("click", () => {
  setOverflowOpen(false);
  send({ type: "retry-all-and-start" });
});

els.downloadZip.addEventListener("click", () => send({ type: "download-results", mode: "zip" }));

// Overflow ⋯ menu: toggles on click, closes on outside click or after a
// menu-item click. Kept simple — no keyboard nav yet.
function setOverflowOpen(open) {
  els.overflowMenu.classList.toggle("hidden", !open);
  els.overflowToggle.setAttribute("aria-expanded", open ? "true" : "false");
}
els.overflowToggle.addEventListener("click", (e) => {
  e.stopPropagation();
  const isOpen = !els.overflowMenu.classList.contains("hidden");
  setOverflowOpen(!isOpen);
});
document.addEventListener("click", (e) => {
  if (els.overflowMenu.classList.contains("hidden")) return;
  if (els.overflowMenu.contains(e.target)) return;      // click inside menu
  if (e.target === els.overflowToggle) return;          // handled above
  setOverflowOpen(false);
});

function showSyncStatus(msg, isError = false) {
  els.syncStatus.textContent = msg;
  els.syncStatus.style.color = isError ? "#c0392b" : "";
  setTimeout(() => { els.syncStatus.textContent = ""; els.syncStatus.style.color = ""; }, 6000);
}

function pushSettings() {
  const secs = Number(els.delay.value) || 4;
  const next = {
    lang: (els.lang.value || "en").trim() || "en",
    includeTimestamps: els.timestamps.checked,
    delayMs: Math.max(2000, Math.min(20000, secs * 1000)),
    apiUrl: (els.apiUrl.value || "").trim(),
    apiKey: (els.apiKey.value || "").trim(),
    autoSyncCloud: els.autoSync.checked,
    syncDownloadQueue: els.syncDownloadQueue.checked,
  };
  state.settings = { ...state.settings, ...next };
  return send({ type: "update-settings", settings: next });
}

// Flush any pending debounced settings push before a sync, so we don't race
// "paste key -> click sync within 200ms -> sync uses stale apiKey".
async function flushSettingsThen(fn) {
  clearTimeout(settingsDebounce);
  await pushSettings();
  return fn();
}

let settingsDebounce = null;
function debouncedPushSettings() {
  clearTimeout(settingsDebounce);
  settingsDebounce = setTimeout(pushSettings, 200);
}

els.lang.addEventListener("input", debouncedPushSettings);
els.timestamps.addEventListener("change", pushSettings);
els.showOverlay.addEventListener("change", () => {
  chrome.storage.local.set({ uiHidden: !els.showOverlay.checked });
});
els.hideCompleted.addEventListener("change", () => {
  chrome.storage.local.set({ hideCompleted: els.hideCompleted.checked });
  scheduleRender();
});

els.queueSearch.addEventListener("input", scheduleRender);
els.delay.addEventListener("input", () => {
  els.delayVal.textContent = els.delay.value;
  debouncedPushSettings();
});
els.apiUrl.addEventListener("input", debouncedPushSettings);
els.apiKey.addEventListener("input", debouncedPushSettings);
els.autoSync.addEventListener("change", pushSettings);
els.syncDownloadQueue.addEventListener("change", pushSettings);

els.watchCurrent.addEventListener("click", async () => {
  if (!activeTab?.id) return;
  els.watchCurrent.disabled = true;
  showWatchStatus("Adding…");
  const res = await send({ type: "add-watched-from-tab", tabId: activeTab.id });
  if (res?.ok && res.deduped) showWatchStatus(`Already watching ${res.displayName || res.handle}`);
  else if (res?.ok) showWatchStatus(`Added ${res.displayName || res.handle}`);
  else showWatchStatus(`Error: ${res?.error || "unknown"}`, true);
  if (res?.ok) await loadWatchlist({ forceRefresh: true });
  updateAddButtons();
});

els.checkWatchlist.addEventListener("click", async () => {
  els.checkWatchlist.disabled = true;
  showWatchStatus("Checking channels…");
  try {
    const res = await send({ type: "check-watchlist" });
    if (res?.ok) {
      const errs = (res.errors || []).length;
      const base = batchAddStatusMessage(res.added, res.cloud);
      const msg = `${base} from ${res.checked} channel${res.checked === 1 ? "" : "s"}` + (errs ? ` (${errs} failed)` : "");
      showWatchStatus(msg, errs > 0);
      // New items were pushed to cloud server-side. Invalidate the local
      // Cloud Queue cache + refresh stats so the count badge and list
      // reflect reality without waiting for the next 30s poll.
      if ((res.added ?? 0) > 0) {
        cloudItems = null;
        pollClaimFromCloud();
      }
    } else {
      showWatchStatus(`Error: ${res?.error || "unknown"}`, true);
    }
  } finally {
    els.checkWatchlist.disabled = false;
  }
});

function showWatchStatus(msg, isError = false) {
  els.watchlistStatus.textContent = msg;
  els.watchlistStatus.style.color = isError ? "#c0392b" : "";
  setTimeout(() => { els.watchlistStatus.textContent = ""; els.watchlistStatus.style.color = ""; }, 5000);
}

init();

// Cloud-queue polling policy:
//   - one-shot on popup open (so the Cloud Queue badge reflects current state),
//   - every 30s while batch.state === "running" (feeds the claim loop),
//   - on Cloud Queue tab click (immediate refresh of items + stats).
// No continuous polling when idle — no work means no network waste.
const CLOUD_CLAIM_POLL_MS = 30000;
let cloudPollTimer = null;

async function pollClaimFromCloud() {
  try {
    const res = await chrome.runtime.sendMessage({ type: "claim-from-cloud" });
    if (!res?.ok) return;
    if (res.stats) { cloudStats = res.stats; scheduleRender(); }
    if ((res.claimed ?? 0) > 0) {
      showSyncStatus(`Claimed ${res.claimed} from cloud`);
    }
  } catch {
    // silent — popup might have died, or SW is asleep
  }
}

function syncCloudPollToBatch() {
  const running = state.batch.state === "running";
  if (running && !cloudPollTimer) {
    cloudPollTimer = setInterval(pollClaimFromCloud, CLOUD_CLAIM_POLL_MS);
  } else if (!running && cloudPollTimer) {
    clearInterval(cloudPollTimer);
    cloudPollTimer = null;
  }
}

// One-shot on popup open — gives the Cloud Queue badge real numbers and
// seeds a claim if the batch is about to resume.
setTimeout(pollClaimFromCloud, 1000);

// ---------- Library tab ---------------------------------------------------
// State is local to the Library tab. Items are paginated via offset + limit;
// filters and sort are applied server-side via /transcripts query params.

const LIBRARY_PAGE_SIZE = 100;
let libraryItems = [];
let libraryOffset = 0;
let libraryLoaded = false;          // first fetch done?
let libraryChannelsLoaded = false;  // channels dropdown populated?
let librarySearchDebounce = null;

function currentLibraryQuery() {
  const [sort, order] = (els.librarySort.value || "published_at|desc").split("|");
  return {
    search: els.librarySearch.value.trim(),
    channel: els.libraryChannel.value,
    sort, order,
    dateFrom: els.libraryDateFrom.value,
    dateTo: els.libraryDateTo.value,
  };
}

async function fetchLibraryChannels() {
  if (libraryChannelsLoaded) return;
  try {
    const res = await chrome.runtime.sendMessage({ type: "list-library-channels" });
    if (!res?.ok) return;
    for (const row of res.items || []) {
      const opt = document.createElement("option");
      opt.value = row.channel;
      opt.textContent = `${row.channel} (${row.n})`;
      els.libraryChannel.appendChild(opt);
    }
    libraryChannelsLoaded = true;
  } catch { /* silent */ }
}

async function fetchLibrary({ append = false } = {}) {
  if (!append) { libraryItems = []; libraryOffset = 0; }
  els.libraryHeader.textContent = append ? "Loading more…" : "Loading…";
  const q = currentLibraryQuery();
  const res = await chrome.runtime.sendMessage({
    type: "list-library",
    limit: LIBRARY_PAGE_SIZE,
    offset: libraryOffset,
    ...q,
  });
  if (!res?.ok) {
    els.libraryHeader.textContent = `Error: ${res?.error || "unknown"}`;
    return;
  }
  const items = res.items || [];
  libraryItems = append ? libraryItems.concat(items) : items;
  libraryOffset += items.length;
  libraryLoaded = true;

  // When a channel filter is active, auto-paginate until exhausted so the
  // user sees the full channel in one go (no "Load more" clicking).
  const channelSelected = !!q.channel;
  const hasMore = items.length >= LIBRARY_PAGE_SIZE;
  if (channelSelected && hasMore) {
    els.libraryHeader.textContent = `Loading ${libraryItems.length}… (fetching all for channel)`;
    renderLibraryList(append);
    return fetchLibrary({ append: true });
  }

  els.libraryHeader.textContent = libraryItems.length === 0
    ? "No transcripts found in the library matching criteria"
    : `Showing ${libraryItems.length} transcript${libraryItems.length === 1 ? "" : "s"}`;

  // Search count badge
  const qStr = q.search;
  if (qStr) {
    els.librarySearchCount.textContent = String(libraryItems.length);
    els.librarySearchCount.classList.remove("hidden");
  } else {
    els.librarySearchCount.classList.add("hidden");
  }

  // Hide "Load more" when channel is selected (we've already auto-loaded everything).
  els.libraryMore.classList.toggle("hidden", channelSelected || items.length < LIBRARY_PAGE_SIZE);
  renderLibraryList(append);
}

function renderLibraryList(append) {
  if (!append) els.libraryList.innerHTML = "";
  const startIdx = append ? libraryItems.length - (libraryItems.length - (libraryItems.length - LIBRARY_PAGE_SIZE)) : 0;
  // Simpler: always re-render everything when not appending; append only the new ones.
  if (!append) {
    for (const it of libraryItems) els.libraryList.appendChild(renderLibraryRow(it));
  } else {
    const renderedCount = els.libraryList.children.length;
    for (let i = renderedCount; i < libraryItems.length; i++) {
      els.libraryList.appendChild(renderLibraryRow(libraryItems[i]));
    }
  }
}

function formatNumber(n) {
  if (n == null) return null;
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1).replace(/\.0$/, "") + "M";
  if (n >= 1_000) return (n / 1_000).toFixed(1).replace(/\.0$/, "") + "K";
  return String(n);
}

function formatDuration(secs) {
  if (!secs) return null;
  const h = Math.floor(secs / 3600);
  const m = Math.floor((secs % 3600) / 60);
  return h > 0 ? `${h}h${m}m` : `${m}m`;
}

function renderLibraryRow(it) {
  const row = document.createElement("div");
  row.className = "qrow";

  const badge = document.createElement("span");
  badge.className = "badge done";
  row.appendChild(badge);

  const body = document.createElement("div");
  body.className = "body";

  const titleLine = document.createElement("div");
  titleLine.className = "title-line";
  const title = document.createElement("span");
  title.className = "title";
  const ch = it.channel_display_name || it.channel_handle || it.channel || "";
  const t = it.title || it.video_id || "(untitled)";
  title.textContent = ch ? `${ch}: ${t}` : t;
  title.title = t;
  if (it.url) title.addEventListener("click", () => chrome.tabs.create({ url: it.url, active: true }));
  titleLine.appendChild(title);
  body.appendChild(titleLine);

  const meta = document.createElement("div");
  meta.className = "row-meta";
  const parts = [];
  if (it.published_at) parts.push(it.published_at);
  const views = formatNumber(it.view_count);
  if (views) parts.push(`${views} views`);
  const dur = formatDuration(it.duration_seconds);
  if (dur) parts.push(dur);
  const chars = formatNumber(it.char_count);
  if (chars) parts.push(`${chars} chars`);
  meta.textContent = parts.join(" · ");
  body.appendChild(meta);

  row.appendChild(body);

  const actions = document.createElement("div");
  actions.className = "actions";

  const info = document.createElement("button");
  info.className = "icon";
  info.textContent = "\u2139"; // ℹ
  info.title = "View details";
  info.addEventListener("click", () => openLibraryDetail(it.video_id));
  actions.appendChild(info);

  // Download: fetch + build .txt with YAML frontmatter, save via chrome.downloads.
  const dl = document.createElement("button");
  dl.className = "icon";
  dl.textContent = "\u2B07"; // ⬇
  dl.title = "Download transcript as .txt";
  dl.addEventListener("click", async () => {
    dl.disabled = true;
    try {
      const res = await chrome.runtime.sendMessage({
        type: "download-library-transcript",
        video_id: it.video_id,
      });
      if (res?.ok) {
        dl.classList.add("ok");
        setTimeout(() => dl.classList.remove("ok"), 1200);
      } else {
        dl.classList.add("err");
        dl.title = `Error: ${res?.error || "unknown"}`;
        setTimeout(() => dl.classList.remove("err"), 2000);
      }
    } finally {
      dl.disabled = false;
    }
  });
  actions.appendChild(dl);

  row.appendChild(actions);
  return row;
}

els.librarySearch.addEventListener("input", () => {
  clearTimeout(librarySearchDebounce);
  librarySearchDebounce = setTimeout(() => fetchLibrary(), 300);
});
els.libraryChannel.addEventListener("change", () => fetchLibrary());
els.librarySort.addEventListener("change", () => fetchLibrary());
els.libraryDateFrom.addEventListener("change", () => fetchLibrary());
els.libraryDateTo.addEventListener("change", () => fetchLibrary());
els.libraryMore.addEventListener("click", () => fetchLibrary({ append: true }));
els.refreshLibrary.addEventListener("click", () => {
  els.refreshLibrary.disabled = true;
  libraryChannelsLoaded = false;  // re-pull the channel dropdown too
  // Clear the cached channel list so the dropdown reflects fresh counts.
  els.libraryChannel.innerHTML = '<option value="">All channels</option>';
  Promise.all([fetchLibraryChannels(), fetchLibrary()])
    .finally(() => { els.refreshLibrary.disabled = false; });
});

// Library detail modal. The field order matches the on-screen ordering spec;
// any unknown keys from future schema bumps fall through to a generic render.
// Strip audit-only identity fields defensively; the API already omits them,
// but future server versions shouldn't be able to leak them here by accident.
const DETAIL_STRIP_KEYS = new Set([
  "synced_by",
  "added_by",
  "claimed_by",
  "created_by",
  "email",
]);

const DETAIL_FIELD_ORDER = [
  "url",
  "video_id",
  "channel_display_name",
  "channel_handle",
  "channel",
  "published_at",
  "view_count",
  "duration_seconds",
  "char_count",
  "lang",
  "has_timestamps",
  "source",
  "category",
  "keywords",
  "scraped_at",
  "synced_at",
  "channel_id",
  "category_id",
  "topic_categories",
  "audio_language",
  "like_count",
  "comment_count",
  "has_captions",
  "made_for_kids",
  "published_at_timestamp",
  "metadata_verified_at",
];

function formatDetailValue(key, value) {
  if (value == null || value === "") return "—";
  if (key === "view_count" || key === "char_count" || key === "like_count" || key === "comment_count") {
    const n = Number(value);
    if (Number.isFinite(n)) return n.toLocaleString("en-US");
  }
  if (key === "duration_seconds") {
    const n = Number(value);
    if (Number.isFinite(n)) return formatDuration(n) || String(value);
  }
  if (key === "has_timestamps") {
    return value ? "\u2713" : "—";
  }
  if (key === "topic_categories" && Array.isArray(value)) {
    return value.length ? value.join("\n") : "—";
  }
  if (typeof value === "boolean") return value ? "\u2713" : "—";
  if (key === "keywords" && Array.isArray(value)) {
    return value.length ? value.join(", ") : "—";
  }
  if (typeof value === "object") {
    try { return JSON.stringify(value); } catch { return String(value); }
  }
  return String(value);
}

function renderDetailRow(dl, key, value) {
  const dt = document.createElement("dt");
  dt.textContent = key;
  const dd = document.createElement("dd");
  if (key === "url" && typeof value === "string" && value) {
    const a = document.createElement("a");
    a.href = value;
    a.target = "_blank";
    a.rel = "noreferrer noopener";
    a.textContent = value;
    a.addEventListener("click", (ev) => {
      ev.preventDefault();
      chrome.tabs.create({ url: value, active: true });
    });
    dd.appendChild(a);
  } else {
    dd.textContent = formatDetailValue(key, value);
  }
  dl.appendChild(dt);
  dl.appendChild(dd);
}

function renderLibraryDetail(item) {
  els.detailBody.textContent = "";

  const title = item.title || item.video_id || "(untitled)";
  els.detailTitle.textContent = title;
  els.detailTitle.title = title;

  const dl = document.createElement("dl");
  dl.className = "detail-list";

  const rendered = new Set();
  for (const key of DETAIL_FIELD_ORDER) {
    if (DETAIL_STRIP_KEYS.has(key)) continue;
    if (!(key in item)) continue;
    renderDetailRow(dl, key, item[key]);
    rendered.add(key);
  }
  for (const key of Object.keys(item)) {
    if (rendered.has(key)) continue;
    if (key === "title" || key === "body" || key === "description") continue;
    if (DETAIL_STRIP_KEYS.has(key)) continue;
    renderDetailRow(dl, key, item[key]);
  }
  els.detailBody.appendChild(dl);

  if (typeof item.description === "string" && item.description) {
    const label = document.createElement("div");
    label.className = "detail-body-label";
    label.textContent = "description";
    els.detailBody.appendChild(label);
    const pre = document.createElement("pre");
    pre.className = "detail-body-text";
    pre.textContent = item.description;
    els.detailBody.appendChild(pre);
  }

  if (typeof item.body === "string" && item.body) {
    const label = document.createElement("div");
    label.className = "detail-body-label";
    label.textContent = "body";
    els.detailBody.appendChild(label);
    const pre = document.createElement("pre");
    pre.className = "detail-body-text";
    pre.textContent = item.body;
    els.detailBody.appendChild(pre);
  }
}

async function openLibraryDetail(videoId) {
  els.detailTitle.textContent = "Transcript details";
  els.detailTitle.removeAttribute("title");
  els.detailBody.textContent = "";
  const loading = document.createElement("div");
  loading.className = "detail-loading";
  loading.textContent = "Loading…";
  els.detailBody.appendChild(loading);
  els.detailModal.classList.remove("hidden");

  try {
    const res = await chrome.runtime.sendMessage({
      type: "fetch-transcript",
      video_id: videoId,
    });
    if (!res?.ok) throw new Error(res?.error || "unknown error");
    const raw = res.item || {};
    const item = {};
    for (const [k, v] of Object.entries(raw)) {
      if (!DETAIL_STRIP_KEYS.has(k)) item[k] = v;
    }
    renderLibraryDetail(item);
  } catch (e) {
    els.detailBody.textContent = "";
    const err = document.createElement("div");
    err.className = "detail-error";
    err.textContent = `Failed to load: ${String(e?.message || e)}`;
    els.detailBody.appendChild(err);
  }
}

function closeDetailModal() {
  els.detailModal.classList.add("hidden");
}

els.detailModal.addEventListener("click", (ev) => {
  const t = ev.target;
  if (t instanceof Element && t.hasAttribute("data-modal-close")) {
    closeDetailModal();
  }
});

document.addEventListener("keydown", (ev) => {
  if (ev.key === "Escape" && !els.detailModal.classList.contains("hidden")) {
    closeDetailModal();
  }
});

// Lazy-load the Library the first time the user opens the tab.
els.topTabLibrary.addEventListener("click", () => {
  if (!libraryLoaded) {
    fetchLibraryChannels();
    fetchLibrary();
  }
}, { once: false });

// ---------- Sync-all-local-fails button (Failed tab) ----------------------
// Counts locally-unsynced failed items (status === "failed" && !cloudSynced)
// and exposes a one-shot migration button. The SW handles the POSTing; we
// just wire the UI. Hidden entirely when count === 0.

function countLocalUnsyncedFails() {
  return state.queue.filter((it) =>
    it.status === "failed" && !it.cloudSynced
  ).length;
}

function updateSyncAllFailsButton() {
  const n = countLocalUnsyncedFails();
  els.syncAllFailsCount.textContent = String(n);
  // Only meaningful on the Failed tab of the Capture panel. Hide elsewhere.
  const onFailed = currentTab === "failed";
  const cloudReady = !!(state.settings.apiUrl && state.settings.apiKey);
  if (!onFailed || !cloudReady || n === 0) {
    els.syncAllFails.classList.add("hidden");
  } else {
    els.syncAllFails.classList.remove("hidden");
  }
}

els.syncAllFails?.addEventListener("click", async () => {
  els.syncAllFails.disabled = true;
  els.syncAllFailsStatus.classList.remove("hidden");
  els.syncAllFailsStatus.textContent = "Starting…";
  els.syncAllFailsStatus.style.color = "";
  try {
    const res = await send({ type: "sync-all-local-fails" });
    if (!res?.ok && res?.error) {
      els.syncAllFailsStatus.textContent = `Sync error: ${res.error}`;
      els.syncAllFailsStatus.style.color = "#c0392b";
      return;
    }
    const pushed = res?.pushed ?? 0;
    const total = res?.total ?? 0;
    const errs = (res?.errors && res.errors.length) || 0;
    if (errs > 0) {
      els.syncAllFailsStatus.textContent =
        `Synced ${pushed} / ${total} · ${errs} error${errs === 1 ? "" : "s"}`;
      els.syncAllFailsStatus.style.color = "#c0392b";
    } else {
      els.syncAllFailsStatus.textContent = `Synced ${pushed} / ${total} ✓`;
      els.syncAllFailsStatus.style.color = "";
    }
    updateSyncAllFailsButton();
  } catch (e) {
    els.syncAllFailsStatus.textContent = `Sync error: ${String(e?.message || e)}`;
    els.syncAllFailsStatus.style.color = "#c0392b";
  } finally {
    els.syncAllFails.disabled = false;
  }
});

// Also refresh the button count whenever the queue or tab changes.
const originalScheduleRender = scheduleRender;
// Monkey-patch-free: hook a wrapper without shadowing. We can't reassign a
// const; instead, piggyback on the storage.onChange path plus the tab
// click handlers added above. Call updateSyncAllFailsButton() on init and
// after every tab switch.
els.tabFailed.addEventListener("click", updateSyncAllFailsButton);
els.tabActive.addEventListener("click", updateSyncAllFailsButton);
els.tabUnsynced.addEventListener("click", updateSyncAllFailsButton);
els.tabCloud.addEventListener("click", updateSyncAllFailsButton);
// Also re-evaluate when the queue state changes (covers failures that land
// asynchronously while the popup is open).
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (changes.queue || changes.settings) updateSyncAllFailsButton();
});

// ---------- Runtime message listeners (from background.js) ----------------
//
// - failure-sync-progress: periodic updates from the one-shot migration.
// - server-error-banner: server returned an unexpected 5xx / misconfig.
// - queue-state-updated: existing pattern — not handled here, but kept so the
//   listener survives co-existence.
chrome.runtime.onMessage.addListener((msg) => {
  if (!msg || typeof msg !== "object") return;
  if (msg.type === "failure-sync-progress") {
    const p = Number(msg.pushed) || 0;
    const t = Number(msg.total) || 0;
    if (els.syncAllFails && !els.syncAllFails.classList.contains("hidden")) {
      // Update the button label live, e.g. "Syncing 432 / 1,047…".
      // Keep the count-span in sync so that if we hide and re-show, the
      // static "Sync N local fails to cloud" copy reflects the remaining N.
      els.syncAllFails.textContent = `Syncing ${p.toLocaleString()} / ${t.toLocaleString()}…`;
    }
    if (els.syncAllFailsStatus) {
      els.syncAllFailsStatus.classList.remove("hidden");
      els.syncAllFailsStatus.textContent = `Syncing ${p} / ${t}…`;
      els.syncAllFailsStatus.style.color = "";
    }
    if (p >= t && t > 0) {
      // Completion: hide the button (the count will be 0 next tick).
      if (els.syncAllFails) {
        els.syncAllFails.classList.add("hidden");
        // Restore the default label so the next activation reads right.
        els.syncAllFails.innerHTML =
          `Sync <span id="sync-all-fails-count">0</span> local fails to cloud`;
        // Rebind the count span reference (innerHTML replaced the node).
        els.syncAllFailsCount = document.getElementById("sync-all-fails-count");
      }
      if (els.syncAllFailsStatus) {
        els.syncAllFailsStatus.textContent = `Synced ${p} ✓`;
        els.syncAllFailsStatus.style.color = "";
      }
    }
  } else if (msg.type === "server-error-banner") {
    showServerErrorBanner(msg.message || "Server error — contact admin");
  }
});

function showServerErrorBanner(message) {
  if (!els.serverErrorBanner) return;
  els.serverErrorBannerMessage.textContent = message;
  els.serverErrorBanner.classList.remove("hidden");
}

function hideServerErrorBanner() {
  if (!els.serverErrorBanner) return;
  els.serverErrorBanner.classList.add("hidden");
}

els.serverErrorBannerDismiss?.addEventListener("click", hideServerErrorBanner);

// One-shot on popup open to set the initial state of the sync-all-fails button.
setTimeout(updateSyncAllFailsButton, 400);

// ---------- Admin Failed subtab -------------------------------------------
//
// State shape:
//   adminFailqueueState: current query + pagination
//   adminFailqueueResult: last fetched payload { items, total, counts }
//   adminFailqueueDistinctLoaded: have we pulled the distinct-values lists?
//
// Security: every admin action first confirms `isAdminResolved`. We do NOT
// speculatively fire `/admin/*` fetches before /whoami says is_admin=true.
// Selection is cleared on any filter change (off-page selections must not
// survive — server also enforces guardrails, but UX must not tempt it).

let adminFailqueueState = {
  channel: "",
  userId: "",
  reason: "",
  state: "active",
  search: "",
  sort: "last_failed_at",
  order: "desc",
  limit: 50,
  offset: 0,
  selected: new Set(),
  total: 0,
};

let adminFailqueueResult = { items: [], total: 0, counts: {} };
let adminFailqueueFetchInFlight = false;
let adminFailqueueDistinctLoaded = false;
let adminFailqueueSearchDebounce = null;

function failqueueStatus(msg, isError = false) {
  els.adminFailqueueStatus.textContent = msg || "";
  els.adminFailqueueStatus.style.color = isError ? "#c0392b" : "";
}

function failqueueQueryString() {
  const s = adminFailqueueState;
  const qs = new URLSearchParams();
  if (s.channel) qs.set("channel", s.channel);
  if (s.userId) qs.set("user_id", s.userId);
  if (s.reason) qs.set("reason", s.reason);
  if (s.state) qs.set("state", s.state);
  if (s.search) qs.set("search", s.search);
  if (s.sort) qs.set("sort", s.sort);
  if (s.order) qs.set("order", s.order);
  qs.set("limit", String(s.limit));
  qs.set("offset", String(s.offset));
  qs.set("with_total", "true");
  return qs.toString();
}

async function ensureFailqueueDistinctValues() {
  if (!isAdminResolved) return;
  if (adminFailqueueDistinctLoaded) return;
  try {
    const res = await send({ type: "admin-queue-failed-distinct" });
    if (!res?.ok) return; // silent; dropdowns stay empty
    // channels: [{value,label,count}]
    if (Array.isArray(res.channels)) {
      for (const c of res.channels) {
        const opt = document.createElement("option");
        opt.value = c.value;
        opt.textContent = c.count != null ? `${c.label || c.value} (${c.count})` : (c.label || c.value);
        els.adminFailqueueChannel.appendChild(opt);
      }
    }
    // users: [{user_id, name, count}]
    if (Array.isArray(res.users)) {
      for (const u of res.users) {
        const opt = document.createElement("option");
        opt.value = u.user_id;
        opt.textContent = u.count != null ? `${u.name || u.user_id} (${u.count})` : (u.name || u.user_id);
        opt.title = u.user_id;
        els.adminFailqueueUser.appendChild(opt);
      }
    }
    // reasons: [{value, count}]
    if (Array.isArray(res.reasons)) {
      for (const r of res.reasons) {
        const opt = document.createElement("option");
        opt.value = r.value;
        opt.textContent = r.count != null ? `${r.value} (${r.count})` : r.value;
        els.adminFailqueueReason.appendChild(opt);
      }
    }
    adminFailqueueDistinctLoaded = true;
  } catch { /* silent */ }
}

async function fetchAdminFailqueue() {
  if (!isAdminResolved) return;
  if (adminFailqueueFetchInFlight) return;
  adminFailqueueFetchInFlight = true;
  failqueueStatus("Loading…");
  try {
    const qs = failqueueQueryString();
    const res = await send({ type: "admin-queue-failed", qs });
    if (!res?.ok) {
      if (res?.status === 403) {
        // Admin access denied — hide the subtab and surface the banner.
        els.adminSubtabFailqueue.classList.add("hidden");
        els.adminPanelFailqueue.classList.add("hidden");
        showServerErrorBanner("Admin access required");
        return;
      }
      failqueueStatus(`Error: ${res?.error || "unknown"}`, true);
      return;
    }
    adminFailqueueResult = {
      items: Array.isArray(res.items) ? res.items : [],
      total: Number(res.total_matching ?? res.total ?? 0),
      counts: res.counts || {},
    };
    adminFailqueueState.total = adminFailqueueResult.total;
    // Clamp offset if server now reports fewer rows than we paged into.
    if (adminFailqueueState.offset >= adminFailqueueResult.total) {
      adminFailqueueState.offset = 0;
    }
    renderAdminFailqueue();
    failqueueStatus("");
  } catch (e) {
    failqueueStatus(`Error: ${String(e?.message || e)}`, true);
  } finally {
    adminFailqueueFetchInFlight = false;
  }
}

function renderFailqueueCounters() {
  const c = adminFailqueueResult.counts || {};
  const total = adminFailqueueResult.total;
  const parts = [];
  parts.push(`Total: ${total.toLocaleString()}`);
  if (c.active != null) parts.push(`Active: ${c.active}`);
  if (c.admin_review != null) parts.push(`Admin review: ${c.admin_review}`);
  if (c.terminal != null) parts.push(`Terminal: ${c.terminal}`);
  els.adminFailqueueCounters.textContent = parts.join(" · ");
}

function renderFailqueuePagination() {
  const s = adminFailqueueState;
  const total = adminFailqueueResult.total;
  const pageSize = s.limit || 50;
  const page = Math.floor(s.offset / pageSize) + 1;
  const pages = Math.max(1, Math.ceil(total / pageSize));
  els.adminFailqueuePageLabel.textContent = `Page ${page} of ${pages}`;
  els.adminFailqueuePrev.disabled = s.offset <= 0;
  els.adminFailqueueNext.disabled = s.offset + pageSize >= total;
}

function statePillClass(stateValue) {
  if (stateValue === "terminal") return "pill pill-gray";
  if (stateValue === "admin_review") return "pill pill-purple";
  if (stateValue === "awaiting_next_user") return "pill pill-amber";
  return "pill pill-amber"; // active
}

function renderAdminFailqueueRow(item) {
  const tr = document.createElement("tr");
  tr.dataset.videoId = item.video_id || "";

  const stateVal = item.state || "active";
  const isTerminal = stateVal === "terminal";

  // Checkbox cell — omitted for terminal rows (nothing to terminate).
  const checkTd = document.createElement("td");
  if (!isTerminal) {
    const cb = document.createElement("input");
    cb.type = "checkbox";
    cb.checked = adminFailqueueState.selected.has(item.video_id);
    cb.addEventListener("change", () => {
      if (cb.checked) adminFailqueueState.selected.add(item.video_id);
      else adminFailqueueState.selected.delete(item.video_id);
      updateBulkButtonsState();
    });
    checkTd.appendChild(cb);
  }
  tr.appendChild(checkTd);

  // Title cell with thumbnail.
  const videoTd = document.createElement("td");
  const wrap = document.createElement("div");
  wrap.className = "failqueue-title-cell";
  if (item.video_id) {
    const img = document.createElement("img");
    img.className = "failqueue-thumb";
    img.src = `https://i.ytimg.com/vi/${item.video_id}/default.jpg`;
    img.loading = "lazy";
    img.alt = "";
    wrap.appendChild(img);
  }
  const titleSpan = document.createElement("span");
  titleSpan.className = "title";
  const title = item.title || item.video_id || "(untitled)";
  titleSpan.textContent = title;
  titleSpan.title = title;
  if (item.url) {
    titleSpan.style.cursor = "pointer";
    titleSpan.addEventListener("click", () => chrome.tabs.create({ url: item.url, active: true }));
  }
  wrap.appendChild(titleSpan);
  videoTd.appendChild(wrap);
  tr.appendChild(videoTd);

  // Channel cell.
  const channelTd = document.createElement("td");
  channelTd.textContent = item.channel_display_name || item.channel || item.channel_handle || "—";
  tr.appendChild(channelTd);

  // Video ID cell.
  const vidTd = document.createElement("td");
  vidTd.className = "mono";
  vidTd.textContent = item.video_id || "";
  tr.appendChild(vidTd);

  // Reason cell.
  const reasonTd = document.createElement("td");
  reasonTd.textContent = item.terminal_reason || item.fail_reason || "—";
  tr.appendChild(reasonTd);

  // Failed-by-users chips.
  const usersTd = document.createElement("td");
  const resolved = Array.isArray(item.failed_by_users_resolved)
    ? item.failed_by_users_resolved
    : [];
  const maxChips = 3;
  for (let i = 0; i < Math.min(resolved.length, maxChips); i++) {
    const u = resolved[i];
    const chip = document.createElement("span");
    chip.className = "chip";
    chip.textContent = u?.name || u?.user_id || "?";
    chip.title = u?.user_id || "";
    usersTd.appendChild(chip);
  }
  if (resolved.length > maxChips) {
    const more = document.createElement("span");
    more.className = "chip chip-more";
    more.textContent = `+${resolved.length - maxChips}`;
    more.title = resolved.slice(maxChips).map((u) => u?.name || u?.user_id).join(", ");
    usersTd.appendChild(more);
  }
  if (resolved.length === 0) {
    const n = item.failed_by_users_count;
    usersTd.textContent = n != null ? String(n) : "—";
  }
  tr.appendChild(usersTd);

  // YT API status.
  const ytTd = document.createElement("td");
  if (item.yt_api_has_captions === true) {
    ytTd.textContent = "✓";
    ytTd.title = item.yt_api_checked_at ? `captions advertised · ${item.yt_api_checked_at}` : "captions advertised";
  } else if (item.yt_api_has_captions === false) {
    ytTd.textContent = "✗";
    ytTd.title = item.yt_api_checked_at ? `no captions · ${item.yt_api_checked_at}` : "no captions";
  } else {
    ytTd.textContent = "—";
    ytTd.title = "not yet checked";
  }
  tr.appendChild(ytTd);

  // State pill.
  const stateTd = document.createElement("td");
  const pill = document.createElement("span");
  pill.className = statePillClass(stateVal);
  pill.textContent = stateVal;
  stateTd.appendChild(pill);
  tr.appendChild(stateTd);

  // Last failed.
  const lastTd = document.createElement("td");
  lastTd.textContent = item.last_failed_at || item.terminal_at || "—";
  tr.appendChild(lastTd);

  // Actions kebab.
  const actionsTd = document.createElement("td");
  if (isTerminal) {
    const unterm = document.createElement("button");
    unterm.type = "button";
    unterm.className = "icon";
    unterm.textContent = "↺";
    unterm.title = "Unterminate";
    unterm.addEventListener("click", async () => {
      unterm.disabled = true;
      try {
        const res = await send({
          type: "admin-queue-unterminate",
          video_ids: [item.video_id],
        });
        if (res?.ok) {
          await fetchAdminFailqueue();
        } else {
          failqueueStatus(`Unterminate failed: ${res?.error || "unknown"}`, true);
        }
      } finally {
        unterm.disabled = false;
      }
    });
    actionsTd.appendChild(unterm);
  } else {
    const term = document.createElement("button");
    term.type = "button";
    term.className = "icon";
    term.textContent = "✕";
    term.title = "Terminate this row";
    term.addEventListener("click", () => {
      openTerminateModal({
        summary: `Terminate this row? (${item.video_id})`,
        affected: 1,
        onConfirm: ({ reason, note }) => terminateByIds([item.video_id], reason, note),
      });
    });
    actionsTd.appendChild(term);

    const yt = document.createElement("button");
    yt.type = "button";
    yt.className = "icon";
    yt.textContent = "⟳";
    yt.title = "Force YT API check";
    yt.addEventListener("click", async () => {
      yt.disabled = true;
      try {
        const res = await send({
          type: "admin-yt-captions-check",
          video_ids: [item.video_id],
        });
        if (res?.ok) await fetchAdminFailqueue();
        else failqueueStatus(`YT check failed: ${res?.error || "unknown"}`, true);
      } finally {
        yt.disabled = false;
      }
    });
    actionsTd.appendChild(yt);
  }
  tr.appendChild(actionsTd);

  return tr;
}

function renderAdminFailqueue() {
  renderFailqueueCounters();
  renderFailqueuePagination();
  const tbody = els.adminFailqueueTbody;
  tbody.textContent = "";
  const items = adminFailqueueResult.items || [];
  if (items.length === 0) {
    const tr = document.createElement("tr");
    const td = document.createElement("td");
    td.colSpan = 10;
    td.className = "muted";
    const s = adminFailqueueState;
    const anyFilter = s.channel || s.userId || s.reason || s.search ||
                      (s.state && s.state !== "all");
    td.textContent = anyFilter
      ? "No failed items match. Try removing a filter."
      : "No failed items.";
    tr.appendChild(td);
    tbody.appendChild(tr);
  } else {
    for (const it of items) tbody.appendChild(renderAdminFailqueueRow(it));
  }
  updateBulkButtonsState();
  // "Select visible" reflects only whether every visible non-terminal row is
  // selected; don't force a state if nothing is visible.
  const selectable = items.filter((i) => (i.state || "active") !== "terminal");
  const allChecked = selectable.length > 0 &&
    selectable.every((i) => adminFailqueueState.selected.has(i.video_id));
  els.adminFailqueueSelectAll.checked = allChecked;
}

function updateBulkButtonsState() {
  const n = adminFailqueueState.selected.size;
  const label = n > 0 ? ` (${n})` : "";
  els.adminFailqueueTerminateSelected.textContent = `Terminate selected${label}`;
  els.adminFailqueueTerminateSelected.disabled = n === 0;
  els.adminFailqueueForceYtCheckSelected.textContent = `Force YT API check${label}`;
  els.adminFailqueueForceYtCheckSelected.disabled = n === 0;
}

// ---------- Filter wiring -------------------------------------------------
// Any filter change: reset selection + offset, then refetch.
function onFailqueueFilterChange(nextPartial) {
  Object.assign(adminFailqueueState, nextPartial);
  adminFailqueueState.offset = 0;
  adminFailqueueState.selected = new Set();
  fetchAdminFailqueue();
}

els.adminFailqueueChannel?.addEventListener("change", () => {
  onFailqueueFilterChange({ channel: els.adminFailqueueChannel.value });
});
els.adminFailqueueUser?.addEventListener("change", () => {
  onFailqueueFilterChange({ userId: els.adminFailqueueUser.value });
});
els.adminFailqueueReason?.addEventListener("change", () => {
  onFailqueueFilterChange({ reason: els.adminFailqueueReason.value });
});
els.adminFailqueueState?.addEventListener("change", () => {
  onFailqueueFilterChange({ state: els.adminFailqueueState.value });
});
els.adminFailqueueSearch?.addEventListener("input", () => {
  clearTimeout(adminFailqueueSearchDebounce);
  adminFailqueueSearchDebounce = setTimeout(() => {
    onFailqueueFilterChange({ search: els.adminFailqueueSearch.value.trim() });
  }, 300);
});

els.adminFailqueueRefresh?.addEventListener("click", () => {
  els.adminFailqueueRefresh.disabled = true;
  fetchAdminFailqueue().finally(() => {
    els.adminFailqueueRefresh.disabled = false;
  });
});

// ---------- Select-visible checkbox --------------------------------------
els.adminFailqueueSelectAll?.addEventListener("change", () => {
  const check = els.adminFailqueueSelectAll.checked;
  const items = adminFailqueueResult.items || [];
  for (const it of items) {
    if ((it.state || "active") === "terminal") continue;
    if (check) adminFailqueueState.selected.add(it.video_id);
    else adminFailqueueState.selected.delete(it.video_id);
  }
  renderAdminFailqueue();
});

// ---------- Pagination ----------------------------------------------------
els.adminFailqueuePrev?.addEventListener("click", () => {
  adminFailqueueState.offset = Math.max(0, adminFailqueueState.offset - adminFailqueueState.limit);
  adminFailqueueState.selected = new Set();  // selections don't cross pages
  fetchAdminFailqueue();
});
els.adminFailqueueNext?.addEventListener("click", () => {
  adminFailqueueState.offset += adminFailqueueState.limit;
  adminFailqueueState.selected = new Set();
  fetchAdminFailqueue();
});
els.adminFailqueuePagesize?.addEventListener("change", () => {
  const n = parseInt(els.adminFailqueuePagesize.value, 10);
  if (Number.isFinite(n) && n > 0) {
    adminFailqueueState.limit = n;
    adminFailqueueState.offset = 0;
    adminFailqueueState.selected = new Set();
    fetchAdminFailqueue();
  }
});

// ---------- Bulk actions --------------------------------------------------
els.adminFailqueueTerminateSelected?.addEventListener("click", () => {
  const ids = [...adminFailqueueState.selected];
  if (!ids.length) return;
  openTerminateModal({
    summary: `Terminate ${ids.length} selected row${ids.length === 1 ? "" : "s"}?`,
    affected: ids.length,
    onConfirm: ({ reason, note }) => terminateByIds(ids, reason, note),
  });
});

els.adminFailqueueTerminateFiltered?.addEventListener("click", () => {
  const s = adminFailqueueState;
  // Server guardrail: at least one of channel/user_id/reason must be set.
  // Preempt with a client-side check so the admin gets an immediate message.
  if (!(s.channel || s.userId || s.reason)) {
    failqueueStatus(
      "Terminate filtered requires at least one of channel / user / reason — set a filter first.",
      true,
    );
    return;
  }
  const affected = adminFailqueueResult.total || 0;
  const filterParts = [];
  if (s.channel) filterParts.push(`channel=${s.channel}`);
  if (s.userId) filterParts.push(`user=${s.userId}`);
  if (s.reason) filterParts.push(`reason=${s.reason}`);
  if (s.state && s.state !== "all") filterParts.push(`state=${s.state}`);
  openTerminateModal({
    summary: `Terminate ${affected.toLocaleString()} row${affected === 1 ? "" : "s"} matching ${filterParts.join(", ") || "current filters"}?`,
    affected,
    onConfirm: ({ reason, note }) => terminateFiltered(reason, note),
  });
});

els.adminFailqueueForceYtCheckSelected?.addEventListener("click", async () => {
  const ids = [...adminFailqueueState.selected];
  if (!ids.length) return;
  els.adminFailqueueForceYtCheckSelected.disabled = true;
  try {
    const res = await send({ type: "admin-yt-captions-check", video_ids: ids });
    if (!res?.ok) {
      failqueueStatus(`YT check failed: ${res?.error || "unknown"}`, true);
      return;
    }
    failqueueStatus(`Checked ${res.checked ?? ids.length} video${ids.length === 1 ? "" : "s"}.`);
    await fetchAdminFailqueue();
  } finally {
    updateBulkButtonsState();
  }
});

async function terminateByIds(videoIds, reason, note) {
  try {
    const res = await send({
      type: "admin-queue-terminate",
      video_ids: videoIds,
      reason,
      note,
    });
    if (!res?.ok) {
      failqueueStatus(`Terminate failed: ${res?.error || "unknown"}`, true);
      return;
    }
    failqueueStatus(`Terminated ${res.terminated ?? videoIds.length} row(s).`);
    adminFailqueueState.selected = new Set();
    await fetchAdminFailqueue();
  } catch (e) {
    failqueueStatus(`Terminate failed: ${String(e?.message || e)}`, true);
  }
}

async function terminateFiltered(reason, note) {
  const s = adminFailqueueState;
  const filters = {};
  if (s.channel) filters.channel = s.channel;
  if (s.userId) filters.user_id = s.userId;
  if (s.reason) filters.reason = s.reason;
  if (s.state && s.state !== "all") filters.state = s.state;
  try {
    const res = await send({
      type: "admin-queue-terminate-filtered",
      filters,
      reason,
      note,
    });
    if (!res?.ok) {
      failqueueStatus(`Terminate filtered failed: ${res?.error || "unknown"}`, true);
      return;
    }
    failqueueStatus(`Terminated ${res.terminated ?? 0} row(s) matching filter.`);
    adminFailqueueState.selected = new Set();
    await fetchAdminFailqueue();
  } catch (e) {
    failqueueStatus(`Terminate filtered failed: ${String(e?.message || e)}`, true);
  }
}

// ---------- Shared terminate modal ----------------------------------------
// Dismissible via Cancel, backdrop click, × button, and ESC. Listener is
// rebound per-open so different call sites get their own onConfirm.
let terminateModalConfirmHandler = null;

function openTerminateModal({ summary, affected, onConfirm }) {
  els.adminFailqueueModalSummary.textContent = summary;
  els.adminFailqueueModalReason.value = "admin_terminated";
  els.adminFailqueueModalNote.value = "";
  const label = affected && affected > 1
    ? `Terminate ${affected.toLocaleString()} rows`
    : "Terminate";
  els.adminFailqueueModalConfirm.textContent = label;
  els.adminFailqueueModal.classList.remove("hidden");

  // Remove any stale handler before attaching a new one.
  if (terminateModalConfirmHandler) {
    els.adminFailqueueModalConfirm.removeEventListener("click", terminateModalConfirmHandler);
  }
  terminateModalConfirmHandler = () => {
    const reason = els.adminFailqueueModalReason.value;
    const note = els.adminFailqueueModalNote.value.trim() || null;
    closeTerminateModal();
    if (typeof onConfirm === "function") onConfirm({ reason, note });
  };
  els.adminFailqueueModalConfirm.addEventListener("click", terminateModalConfirmHandler);
}

function closeTerminateModal() {
  els.adminFailqueueModal.classList.add("hidden");
  if (terminateModalConfirmHandler) {
    els.adminFailqueueModalConfirm.removeEventListener("click", terminateModalConfirmHandler);
    terminateModalConfirmHandler = null;
  }
}

els.adminFailqueueModal?.addEventListener("click", (ev) => {
  const t = ev.target;
  if (t instanceof Element && t.hasAttribute("data-modal-close")) {
    closeTerminateModal();
  }
});

document.addEventListener("keydown", (ev) => {
  if (ev.key === "Escape" && els.adminFailqueueModal &&
      !els.adminFailqueueModal.classList.contains("hidden")) {
    closeTerminateModal();
  }
});
