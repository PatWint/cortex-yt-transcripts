from pathlib import Path

from PIL import Image, ImageDraw

RED = (220, 38, 38, 255)      # #dc2626
GRAY = (156, 163, 175, 255)   # #9ca3af
WHITE = (255, 255, 255, 255)

def make_icon(size, bg, path):
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    r = max(2, size // 6)
    d.rounded_rectangle((0, 0, size - 1, size - 1), radius=r, fill=bg)

    cx = size / 2
    bar_w = max(2, size * 0.16)
    bar_top = size * 0.18
    bar_bot = size * 0.58
    d.rectangle((cx - bar_w / 2, bar_top, cx + bar_w / 2, bar_bot), fill=WHITE)

    tri_half = size * 0.26
    tri_top = bar_bot - size * 0.03
    tri_bot = size * 0.86
    d.polygon(
        [(cx - tri_half, tri_top), (cx + tri_half, tri_top), (cx, tri_bot)],
        fill=WHITE,
    )

    img.save(path, format="PNG")

BASE = Path(__file__).resolve().parent
for s in (16, 32, 48, 128):
    make_icon(s, RED, str(BASE / f"icon{s}.png"))
    make_icon(s, GRAY, str(BASE / f"icon{s}_gray.png"))
print("ok")
