// Lightweight bridge: lets external callers (e.g. browser_inspect.py) read
// the plugin's queue/batch state and update settings without opening the
// extension popup. Loaded via manifest content_scripts on <all_urls>.
//
// Read:
//   caller posts:  {type:"PRIMEAI_QUEUE_REQUEST"}
//   we reply with: {type:"PRIMEAI_QUEUE_RESPONSE", data:{queue,batch,settings}}
//
// Write settings (merge-patch):
//   caller posts:  {type:"PRIMEAI_SETTINGS_UPDATE", patch:{...}}
//   we reply with: {type:"PRIMEAI_SETTINGS_UPDATED", data:{ok:true}}

window.addEventListener("message", (e) => {
  if (e.source !== window) return;
  const msg = e.data;
  if (!msg) return;
  if (msg.type === "PRIMEAI_QUEUE_REQUEST") {
    chrome.runtime.sendMessage({ type: "get-queue-state" }, (resp) => {
      window.postMessage({ type: "PRIMEAI_QUEUE_RESPONSE", data: resp || null }, "*");
    });
  } else if (msg.type === "PRIMEAI_SETTINGS_UPDATE") {
    chrome.runtime.sendMessage(
      { type: "update-settings", settings: msg.patch || {} },
      (resp) => {
        window.postMessage({ type: "PRIMEAI_SETTINGS_UPDATED", data: resp || null }, "*");
      }
    );
  }
});
