// Injected into youtube.com pages: floating widget that shows queue status
// and lets the user add the current video and start/pause the batch without
// opening the extension popup.

const ROOT_ID = "__ytq_widget";
const ALERT_ID = "__ytq_alert";

// After the extension reloads, old content scripts in already-open tabs
// become "zombies" — their chrome.* references are invalidated and any
// call throws "Extension context invalidated". Guard every entry point.
function extensionAlive() {
  try { return !!chrome?.runtime?.id; } catch { return false; }
}

function fmt(state) {
  const c = { pending: 0, running: 0, done: 0, failed: 0, skipped: 0 };
  for (const it of state.queue || []) if (c[it.status] != null) c[it.status]++;
  const parts = [`${c.pending}p`, `${c.running}r`, `${c.done}d`];
  if (c.failed) parts.push(`${c.failed}f`);
  if (c.skipped) parts.push(`${c.skipped}s`);
  return { c, label: parts.join(" · ") };
}

function onWatch() {
  return /\/watch\?/.test(location.href);
}

function currentVideoUrl() {
  try {
    const u = new URL(location.href);
    const v = u.searchParams.get("v");
    return v ? `https://www.youtube.com/watch?v=${v}` : null;
  } catch { return null; }
}

function mount() {
  if (document.getElementById(ROOT_ID)) return;
  const el = document.createElement("div");
  el.id = ROOT_ID;
  el.innerHTML = `
    <div class="ytq-head">
      <span class="ytq-title">Transcript queue</span>
      <button class="ytq-x" title="Hide plugin UI (re-enable from extension popup)">×</button>
    </div>
    <div class="ytq-counts">—</div>
    <div class="ytq-row">
      <button class="ytq-add" disabled>+ Add this video</button>
    </div>
    <div class="ytq-row">
      <button class="ytq-start ytq-primary" disabled>Start</button>
    </div>
  `;
  document.body.appendChild(el);

  el.querySelector(".ytq-x").addEventListener("click", async () => {
    await chrome.storage.local.set({ uiHidden: true });
  });
  el.querySelector(".ytq-add").addEventListener("click", async () => {
    const url = currentVideoUrl();
    if (!url) return;
    const title = document.querySelector("h1.ytd-watch-metadata yt-formatted-string, h1.title yt-formatted-string")?.textContent?.trim() || document.title.replace(/ - YouTube$/, "");
    await chrome.runtime.sendMessage({ type: "add-video", url, title });
  });
  el.querySelector(".ytq-start").addEventListener("click", async () => {
    const state = await chrome.storage.local.get(["batch"]);
    const s = state.batch?.state || "idle";
    const type = s === "running" ? "pause" : s === "paused" ? "resume" : "start";
    await chrome.runtime.sendMessage({ type });
  });

  refresh();
}

function removeAllInjected() {
  document.getElementById(ROOT_ID)?.remove();
  document.getElementById(ALERT_ID)?.remove();
}

async function refresh() {
  if (!extensionAlive()) return;
  const s = await chrome.storage.local.get(["queue", "batch", "uiHidden"]);
  if (s.uiHidden) { removeAllInjected(); return; }
  const state = { queue: s.queue || [], batch: s.batch || { state: "idle" } };

  const el = document.getElementById(ROOT_ID);
  if (el) {
    const { c, label } = fmt(state);
    el.querySelector(".ytq-counts").textContent = label;
    const add = el.querySelector(".ytq-add");
    add.disabled = !onWatch();
    const start = el.querySelector(".ytq-start");
    const bs = state.batch.state;
    if (bs === "running") { start.textContent = "Pause"; start.disabled = false; start.classList.add("ytq-paused"); }
    else if (bs === "paused") { start.textContent = "Resume"; start.disabled = false; start.classList.add("ytq-paused"); }
    else { start.textContent = "Start"; start.disabled = fmt(state).c.pending === 0; start.classList.remove("ytq-paused"); }
  }
  refreshAlert(state);
}

function currentItem(state) {
  const id = state.batch?.currentId;
  if (id) {
    const it = state.queue.find((q) => q.id === id);
    if (it) return it;
  }
  return state.queue.find((q) => q.status === "running") || null;
}

function findPrimaryInner() {
  return (
    document.querySelector("ytd-watch-flexy #primary-inner") ||
    document.querySelector("#primary-inner") ||
    null
  );
}

function mountAlert() {
  if (!onWatch()) return null;
  const host = findPrimaryInner();
  if (!host) return null;

  let a = document.getElementById(ALERT_ID);
  if (a && a.parentElement === host && host.firstElementChild === a) return a;

  if (!a) {
    a = document.createElement("div");
    a.id = ALERT_ID;
    a.innerHTML = `
      <div class="ytqa-body">
        <span class="ytqa-dot"></span>
        <div class="ytqa-text">
          <div class="ytqa-label">Downloading transcript</div>
          <div class="ytqa-title">—</div>
        </div>
        <button class="ytqa-btn ytqa-toggle">Pause</button>
        <button class="ytqa-btn ytqa-close" title="Dismiss">×</button>
      </div>
    `;
    a.querySelector(".ytqa-toggle").addEventListener("click", async () => {
      const s = await chrome.storage.local.get(["batch"]);
      const bs = s.batch?.state || "idle";
      await chrome.runtime.sendMessage({ type: bs === "running" ? "pause" : "resume" });
    });
    a.querySelector(".ytqa-close").addEventListener("click", () => { a.remove(); });
  }
  host.insertBefore(a, host.firstElementChild);
  return a;
}

function refreshAlert(state) {
  const bs = state.batch?.state || "idle";
  const item = currentItem(state);
  const active = (bs === "running" || bs === "paused") && !!item;

  if (!active) {
    const existing = document.getElementById(ALERT_ID);
    if (existing) existing.remove();
    return;
  }
  const a = mountAlert();
  if (!a) return; // non-watch page or container not ready; widget still shown
  a.classList.toggle("ytqa-paused", bs === "paused");
  a.querySelector(".ytqa-label").textContent =
    bs === "paused" ? "Paused — transcript download" : "Downloading transcript";
  a.querySelector(".ytqa-title").textContent = item.title || item.url || item.videoId || "(untitled)";
  a.querySelector(".ytqa-toggle").textContent = bs === "running" ? "Pause" : "Resume";
}

// The floating corner widget is intentionally never mounted — users preferred
// to interact with the queue only via the extension popup and the banner
// above the video. Keeping `mount()` around in case we bring it back behind a
// setting later.
async function tryMount() {
  if (!extensionAlive()) return;
  const { uiHidden } = await chrome.storage.local.get("uiHidden");
  if (uiHidden) removeAllInjected();
}

tryMount();
chrome.storage.onChanged.addListener((changes, area) => {
  if (!extensionAlive()) return;
  if (area !== "local") return;
  if (changes.uiHidden) {
    if (changes.uiHidden.newValue) removeAllInjected();
    else tryMount();
  }
  if (changes.queue || changes.batch) refresh();
});
// YouTube is an SPA; re-apply on route changes (in case the widget was removed
// by a page swap or needs button state refresh for the new video).
document.addEventListener("yt-navigate-finish", () => {
  if (!extensionAlive()) return;
  tryMount().then(refresh);
});
